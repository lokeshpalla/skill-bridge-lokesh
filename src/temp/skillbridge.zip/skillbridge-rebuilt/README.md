# SkillBridge Nexus v2.0

> AI-powered learning platform — rebuilt with HTML5, CSS3, JavaScript, Node.js/Express, MySQL, Python (Pandas/NumPy), and n8n/Make.com automation.

---

## 🏗️ Architecture Overview

```
skillbridge-nexus/
├── public/                      # Frontend (HTML5 + CSS3 + Vanilla JS SPA)
│   ├── index.html               # Single HTML entry point
│   ├── css/
│   │   ├── main.css             # Design system, tokens, layout, typography
│   │   └── components.css       # AI widget, cards, editor, video, modals
│   └── js/
│       ├── api.js               # Centralized API client + streaming
│       ├── auth.js              # Client-side auth state
│       ├── router.js            # SPA client-side router
│       ├── ai-assistant.js      # AI chat widget (streaming)
│       ├── navbar.js + app.js   # Navbar + app bootstrap
│       └── pages/
│           ├── home.js          # Landing page
│           ├── auth.js          # Login/signup/forgot
│           ├── dashboard.js     # User dashboard
│           ├── coding.js        # LeetCode-style editor + problems
│           ├── courses.js       # Course catalog
│           ├── mentors.js       # Mentor listing + booking
│           ├── leaderboard.js   # XP rankings
│           ├── internships.js   # Opportunities + tracker
│           ├── portfolio.js     # Portfolio builder
│           └── video.js         # WebRTC video room
│
├── server/                      # Backend (Node.js + Express)
│   ├── index.js                 # Server entry + Socket.IO setup
│   ├── routes/
│   │   ├── auth.js              # JWT auth (register/login/refresh/reset)
│   │   ├── users.js             # User profile CRUD
│   │   ├── courses.js           # Courses + enrollments
│   │   ├── coding.js            # Problems + code runner + submissions
│   │   ├── mentors.js           # Mentor listing + booking
│   │   ├── leaderboard.js       # Leaderboard + rank computation
│   │   ├── internships.js       # Internships + applications
│   │   ├── portfolio.js         # Portfolio CRUD
│   │   ├── ai.js                # AI chat (OpenAI/Anthropic streaming)
│   │   ├── analytics.js         # Calls Python service
│   │   └── webhooks.js          # n8n + Make.com integration
│   ├── middleware/
│   │   └── auth.js              # JWT middleware
│   ├── utils/
│   │   ├── db.js                # MySQL connection pool + helpers
│   │   └── socketSignalling.js  # WebRTC room signalling
│   └── python/
│       ├── analytics_service.py # Flask API with pandas/numpy/sklearn
│       └── requirements.txt
│
├── database/
│   ├── schema.sql               # Full MySQL schema (16 tables)
│   └── seed.js                  # Sample data seeder
│
├── automation/
│   └── n8n/                     # n8n workflow JSON exports
│       ├── welcome-email.json
│       ├── daily-challenge.json
│       ├── booking-notification.json
│       ├── leaderboard-refresh.json
│       ├── internship-alerts.json
│       ├── streak-alert.json
│       └── certification.json
│
├── package.json
├── .env.example
└── README.md
```

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- MySQL 8.0+
- Python 3.10+
- (Optional) n8n or Make.com account

### 1. Install Node dependencies
```bash
npm install
```

### 2. Set up the database
```bash
# Create database
mysql -u root -p -e "CREATE DATABASE skillbridge;"

# Run schema
npm run db:migrate

# (Optional) Seed sample data
npm run db:seed
```

### 3. Set up Python service
```bash
cd server/python
pip install -r requirements.txt
python3 analytics_service.py   # Runs on :5001
```

### 4. Configure environment
```bash
cp .env.example .env
# Edit .env with your DB credentials, API keys, etc.
```

### 5. Start the server
```bash
npm run dev    # Development (nodemon)
npm start      # Production
```

Open `http://localhost:3000`

---

## 🔑 Key Technologies

| Layer | Technology | Purpose |
|-------|-----------|---------|
| Frontend | HTML5 + CSS3 + Vanilla JS | SPA with client-side routing |
| Backend | Node.js + Express.js | REST API + WebSocket server |
| Database | MySQL 8 | Relational data store |
| Real-time | Socket.IO | WebRTC signalling + live code sync |
| AI | OpenAI GPT-4o-mini or Claude Haiku | Streaming AI assistant |
| Analytics | Python + Pandas + NumPy | Data analytics microservice |
| ML | scikit-learn | Internship matching (TF-IDF cosine) |
| Automation | n8n + Make.com | Workflows, emails, notifications |

---

## 🤖 AI Features

### AI Chat Assistant
- Streams responses token by token (SSE)
- Multilingual: English, Telugu, Hindi, Tamil, Kannada
- Coding hints (without giving away solutions)
- Career guidance + mock interview feedback
- Provider: OpenAI or Anthropic (configurable via `AI_PROVIDER`)

### AI Code Analysis (`POST /api/ai/analyze-code`)
- Time & space complexity analysis
- Code quality feedback
- Specific improvement suggestions

### AI Internship Matching (`POST /api/ai/match-internships`)
- Uses Python sklearn TF-IDF + cosine similarity
- Matches user's skills to internship requirements
- Returns ranked list with match scores

### AI Resume Generator (`POST /api/ai/generate-resume`)
- Generates ATS-optimized resume JSON from user profile
- Includes skills, projects, certifications

---

## 🔄 n8n / Make.com Automation Workflows

### Supported Automation Events (fired by the server)

| Event | Trigger | What n8n/Make does |
|-------|---------|-------------------|
| `user.registered` | New signup | Welcome email + CRM contact + Slack notification |
| `booking.created` | Mentor booked | Email both parties + Google Calendar invite |
| `coding.problem_solved` | Problem accepted | Check badge thresholds + award XP notification |
| `course.completed` | Course finished | Generate + email PDF certificate |
| `auth.password_reset` | Forgot password | Send reset email |

### Setting up n8n

1. Deploy n8n (cloud or self-hosted): https://n8n.io
2. Create a webhook trigger node with URL
3. Copy the webhook URL to `N8N_WEBHOOK_URL` in `.env`
4. Import workflow JSONs from `/automation/n8n/`
5. Set `WEBHOOK_SECRET` for security

### Setting up Make.com

1. Create a Make.com account: https://make.com
2. Create a new Scenario with a Webhook trigger
3. Copy the webhook URL to `MAKE_WEBHOOK_URL` in `.env`
4. The server auto-POSTs events to this URL

### n8n Pull Model (alternative)
Instead of pushing, n8n can poll `GET /api/webhooks/pending-events` every 5 minutes to process events in batches.

---

## 🗄️ Database Schema (Key Tables)

- **users** — auth, XP, streaks, roles
- **courses** — catalog with difficulty, category, video URLs
- **course_enrollments** — progress tracking
- **coding_problems** — problems with test cases, starter code
- **coding_submissions** — code, status, XP earned
- **leaderboard_entries** — denormalized for fast reads
- **mentor_profiles** — extended mentor data
- **mentor_bookings** — session scheduling
- **internships** — opportunities with skills required
- **internship_applications** — user application tracker
- **portfolio_projects** — user projects
- **certifications** — issued certs with hash
- **automation_events** — n8n/make webhook event log

---

## 🐍 Python Analytics Service (`:5001`)

| Endpoint | Description |
|----------|-------------|
| `GET /analytics/leaderboard` | Ranked leaderboard with percentiles, levels, XP trends |
| `GET /analytics/user/:id/progress` | Daily XP, acceptance rate, heatmap, streak |
| `GET /analytics/courses` | Enrollment stats, completion rates, popularity scores |
| `POST /analytics/match-internships` | ML-based internship matching |
| `GET /analytics/platform` | Overall platform stats for admin |

All endpoints use **pandas DataFrames** for aggregation and **numpy** for numerical operations. The internship matcher uses **sklearn TF-IDF + cosine similarity**.

---

## 📹 WebRTC Video Rooms

- Rooms created at `/video/:roomCode` (any string)
- Socket.IO handles offer/answer/ICE candidate exchange
- Features: mute mic, toggle camera, screen share, live chat, collaborative code editor
- Scales to 2-8 participants per room

---

## 🔐 Security

- JWT access tokens (15min) + refresh tokens (7 days)
- bcryptjs password hashing (cost factor 12)
- Rate limiting on all routes (200 req/15min), stricter on AI (20 req/min)
- CORS restricted to `CLIENT_URL`
- Helmet.js security headers
- Code execution: subprocess with 10s timeout + file cleanup
- Webhook secret verification

---

## 📦 Deployment

```bash
# Production
NODE_ENV=production npm start

# Python service (gunicorn)
cd server/python
gunicorn -w 4 -b 0.0.0.0:5001 analytics_service:app

# Recommended: use PM2 for process management
npm install -g pm2
pm2 start server/index.js --name skillbridge-api
pm2 start "cd server/python && gunicorn -w 4 analytics_service:app" --name skillbridge-python
```
