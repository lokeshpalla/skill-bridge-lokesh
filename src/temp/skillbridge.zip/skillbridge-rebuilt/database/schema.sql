-- ============================================================
-- SkillBridge Nexus — Full SQL Schema (MySQL / PostgreSQL)
-- ============================================================

-- 1. USERS & AUTH
CREATE TABLE users (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  email       VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name   VARCHAR(255),
  avatar_url  TEXT,
  bio         TEXT,
  role        ENUM('student','mentor','admin') DEFAULT 'student',
  preferred_language VARCHAR(10) DEFAULT 'en',
  streak_days INT DEFAULT 0,
  total_xp    INT DEFAULT 0,
  problems_solved INT DEFAULT 0,
  is_active   BOOLEAN DEFAULT TRUE,
  reset_token VARCHAR(255),
  reset_token_expires DATETIME,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 2. COURSES
CREATE TABLE courses (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  title         VARCHAR(255) NOT NULL,
  description   TEXT,
  category      VARCHAR(100),
  difficulty    ENUM('beginner','intermediate','advanced'),
  duration_hours INT,
  image_url     TEXT,
  demo_video_url TEXT,
  mentor_id     INT REFERENCES users(id) ON DELETE SET NULL,
  is_published  BOOLEAN DEFAULT FALSE,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 3. COURSE ENROLLMENTS
CREATE TABLE course_enrollments (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  user_id         INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  course_id       INT NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  progress_percent INT DEFAULT 0,
  enrolled_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
  completed_at    DATETIME,
  UNIQUE (user_id, course_id)
);

-- 4. CODING PROBLEMS
CREATE TABLE coding_problems (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  title        VARCHAR(255) NOT NULL,
  description  TEXT,
  difficulty   ENUM('easy','medium','hard'),
  category     VARCHAR(100),
  starter_code TEXT,
  solution     TEXT,
  test_cases   JSON,
  xp_reward    INT DEFAULT 10,
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 5. CODE SUBMISSIONS
CREATE TABLE coding_submissions (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  user_id           INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  problem_id        INT NOT NULL REFERENCES coding_problems(id) ON DELETE CASCADE,
  code              TEXT NOT NULL,
  language          VARCHAR(50) DEFAULT 'javascript',
  status            ENUM('pending','accepted','wrong_answer','error') DEFAULT 'pending',
  execution_time_ms INT,
  xp_earned         INT DEFAULT 0,
  submitted_at      DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 6. LEADERBOARD (denormalized for fast reads)
CREATE TABLE leaderboard_entries (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  user_id         INT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  total_xp        INT DEFAULT 0,
  streak_days     INT DEFAULT 0,
  problems_solved INT DEFAULT 0,
  rank_position   INT,
  updated_at      DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 7. DAILY CHALLENGES
CREATE TABLE daily_challenges (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  problem_id    INT NOT NULL REFERENCES coding_problems(id) ON DELETE CASCADE,
  challenge_date DATE NOT NULL UNIQUE,
  bonus_xp      INT DEFAULT 20,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 8. USER STREAKS
CREATE TABLE user_streaks (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  activity_date DATE NOT NULL,
  activity_type VARCHAR(50),
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (user_id, activity_date)
);

-- 9. MENTORS (extended profile)
CREATE TABLE mentor_profiles (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  user_id      INT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  title        VARCHAR(255),
  company      VARCHAR(255),
  hourly_rate  DECIMAL(10,2),
  availability TEXT,
  skills       JSON,
  sessions_count INT DEFAULT 0,
  rating       DECIMAL(3,2) DEFAULT 5.00,
  linkedin_url TEXT,
  twitter_url  TEXT,
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 10. MENTOR BOOKINGS
CREATE TABLE mentor_bookings (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  student_id   INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  mentor_id    INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session_date DATETIME NOT NULL,
  duration_min INT DEFAULT 60,
  session_type ENUM('one_on_one','group','mock_interview','code_review') DEFAULT 'one_on_one',
  topic        VARCHAR(255),
  notes        TEXT,
  status       ENUM('pending','confirmed','completed','cancelled') DEFAULT 'pending',
  video_room_code VARCHAR(50) UNIQUE,
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 11. INTERNSHIPS
CREATE TABLE internships (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  title        VARCHAR(255) NOT NULL,
  company      VARCHAR(255),
  logo_url     TEXT,
  location     VARCHAR(255),
  type         ENUM('remote','onsite','hybrid') DEFAULT 'remote',
  duration     VARCHAR(100),
  stipend      VARCHAR(100),
  skills_required JSON,
  description  TEXT,
  apply_link   TEXT,
  deadline     DATE,
  is_active    BOOLEAN DEFAULT TRUE,
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 12. INTERNSHIP APPLICATIONS
CREATE TABLE internship_applications (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  user_id        INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  internship_id  INT REFERENCES internships(id) ON DELETE SET NULL,
  company_name   VARCHAR(255),
  role           VARCHAR(255),
  status         ENUM('applied','screening','interview','offer','rejected','accepted') DEFAULT 'applied',
  applied_date   DATE,
  notes          TEXT,
  created_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 13. PORTFOLIO / PROJECTS
CREATE TABLE portfolio_projects (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  user_id      INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title        VARCHAR(255) NOT NULL,
  description  TEXT,
  tech_stack   JSON,
  github_url   TEXT,
  live_url     TEXT,
  image_url    TEXT,
  is_featured  BOOLEAN DEFAULT FALSE,
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 14. CERTIFICATIONS
CREATE TABLE certifications (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  user_id      INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  course_id    INT REFERENCES courses(id) ON DELETE SET NULL,
  title        VARCHAR(255),
  issued_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  cert_hash    VARCHAR(255) UNIQUE,
  is_verified  BOOLEAN DEFAULT FALSE
);

-- 15. AI CHAT HISTORY (optional persistence)
CREATE TABLE ai_chat_sessions (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT REFERENCES users(id) ON DELETE CASCADE,
  language    VARCHAR(10) DEFAULT 'en',
  messages    JSON,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 16. N8N / MAKE.COM WEBHOOK EVENTS LOG
CREATE TABLE automation_events (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  event_type   VARCHAR(100),
  payload      JSON,
  source       ENUM('n8n','make','internal') DEFAULT 'internal',
  status       ENUM('pending','processed','failed') DEFAULT 'pending',
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_submissions_user ON coding_submissions(user_id);
CREATE INDEX idx_submissions_problem ON coding_submissions(problem_id);
CREATE INDEX idx_enrollments_user ON course_enrollments(user_id);
CREATE INDEX idx_enrollments_course ON course_enrollments(course_id);
CREATE INDEX idx_leaderboard_xp ON leaderboard_entries(total_xp DESC);
CREATE INDEX idx_bookings_mentor ON mentor_bookings(mentor_id);
CREATE INDEX idx_bookings_student ON mentor_bookings(student_id);
CREATE INDEX idx_applications_user ON internship_applications(user_id);
CREATE INDEX idx_daily_challenge_date ON daily_challenges(challenge_date);
