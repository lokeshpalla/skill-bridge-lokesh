// SkillBridge Nexus — Express server entry point
require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const helmet     = require('helmet');
const rateLimit  = require('express-rate-limit');
const morgan     = require('morgan');
const path       = require('path');
const { createServer } = require('http');
const { Server }       = require('socket.io');

const app        = express();
const httpServer = createServer(app);

// ── Socket.IO (WebRTC signalling) ─────────────────────────────
const io = new Server(httpServer, {
  cors: { origin: process.env.CLIENT_URL || '*', methods: ['GET', 'POST'] }
});
require('./utils/socketSignalling')(io);

// ── Core middleware ───────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CLIENT_URL || '*', credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));

// ── Rate limiting ─────────────────────────────────────────────
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, max: 300, standardHeaders: true, legacyHeaders: false }));
app.use('/api/ai', rateLimit({ windowMs: 60 * 1000, max: 20, message: { error: 'AI rate limit exceeded. Try again in a minute.' } }));

// ── Static files ──────────────────────────────────────────────
app.use(express.static(path.join(__dirname, '../public')));

// ── API routes — each wrapped so one bad file won't crash all ─
const mount = (prefix, file) => {
  try {
    app.use(prefix, require(file));
    console.log(`✓ ${prefix}`);
  } catch (err) {
    console.error(`✗ Failed to load ${prefix}:`, err.message);
    // Return 503 for this prefix instead of crashing
    app.use(prefix, (req, res) => res.status(503).json({ error: `Route ${prefix} unavailable: ${err.message}` }));
  }
};

mount('/api/auth',        './routes/auth');
mount('/api/users',       './routes/users');
mount('/api/courses',     './routes/courses');
mount('/api/coding',      './routes/coding');
mount('/api/mentors',     './routes/mentors');
mount('/api/leaderboard', './routes/leaderboard');
mount('/api/internships', './routes/internships');
mount('/api/portfolio',   './routes/portfolio');
mount('/api/ai',          './routes/ai');
mount('/api/analytics',   './routes/analytics');
mount('/api/webhooks',    './routes/webhooks');

// ── Health check ──────────────────────────────────────────────
app.get('/api/health', (req, res) => res.json({ status: 'ok', ts: new Date().toISOString() }));

// ── SPA fallback ──────────────────────────────────────────────
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(__dirname, '../public/index.html'));
  } else {
    res.status(404).json({ error: 'API endpoint not found' });
  }
});

// ── Global error handler ──────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('[Server Error]', err.stack);
  res.status(err.status || 500).json({ error: err.message || 'Internal Server Error' });
});

const PORT = process.env.PORT || 3000;
httpServer.listen(PORT, () => {
  console.log(`\n🚀 SkillBridge running at http://localhost:${PORT}\n`);
});

module.exports = { app, io };
