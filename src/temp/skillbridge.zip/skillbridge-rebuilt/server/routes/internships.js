// server/routes/internships.js
const router = require('express').Router();
const { query, execute, queryOne } = require('../utils/db');
const { requireAuth, optionalAuth } = require('../middleware/auth');

// GET /api/internships
router.get('/', optionalAuth, async (req, res) => {
  try {
    const { type, search } = req.query;
    let sql = 'SELECT * FROM internships WHERE is_active = 1';
    const params = [];
    if (type && type !== 'all') { sql += ' AND type = ?'; params.push(type); }
    if (search) { sql += ' AND (title LIKE ? OR company LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
    sql += ' ORDER BY created_at DESC LIMIT 50';
    const rows = await query(sql, params);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/internships/applications/me
router.get('/applications/me', requireAuth, async (req, res) => {
  try {
    const rows = await query(
      'SELECT ia.*, i.title as internship_title, i.company as internship_company FROM internship_applications ia LEFT JOIN internships i ON ia.internship_id = i.id WHERE ia.user_id = ? ORDER BY ia.created_at DESC',
      [req.user.id]
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/internships/:id/apply
router.post('/:id/apply', requireAuth, async (req, res) => {
  try {
    const internship = await queryOne('SELECT * FROM internships WHERE id = ?', [req.params.id]);
    if (!internship) return res.status(404).json({ error: 'Internship not found' });
    const result = await execute(
      'INSERT INTO internship_applications (user_id, internship_id, company_name, role, status, applied_date) VALUES (?,?,?,?,?,CURDATE())',
      [req.user.id, internship.id, internship.company, internship.title, 'applied']
    );
    res.status(201).json({ id: result.insertId, status: 'applied' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// PATCH /api/internships/applications/:id  — update status
router.patch('/applications/:id', requireAuth, async (req, res) => {
  try {
    const { status, notes } = req.body;
    await execute(
      'UPDATE internship_applications SET status=?, notes=? WHERE id=? AND user_id=?',
      [status, notes || null, req.params.id, req.user.id]
    );
    res.json({ updated: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
