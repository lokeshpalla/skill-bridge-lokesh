// server/routes/coding.js
const router = require('express').Router();
const { query, execute, queryOne } = require('../utils/db');
const { requireAuth } = require('../middleware/auth');
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs').promises;
const os = require('os');

// GET /api/coding/problems
router.get('/problems', async (req, res) => {
  try {
    const { difficulty, category, limit = 50, offset = 0 } = req.query;
    let sql = 'SELECT id, title, difficulty, category, xp_reward, starter_code, test_cases, description FROM coding_problems WHERE 1=1';
    const params = [];
    if (difficulty && difficulty !== 'all') { sql += ' AND difficulty = ?'; params.push(difficulty); }
    if (category && category !== 'all')   { sql += ' AND category = ?';    params.push(category); }
    sql += ' ORDER BY FIELD(difficulty,"easy","medium","hard"), created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const problems = await query(sql, params);
    res.json(problems);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/coding/problems/:id
router.get('/problems/:id', async (req, res) => {
  try {
    const problem = await queryOne('SELECT * FROM coding_problems WHERE id = ?', [req.params.id]);
    if (!problem) return res.status(404).json({ error: 'Problem not found' });
    res.json(problem);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/coding/daily-challenge
router.get('/daily-challenge', async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const challenge = await queryOne(
      `SELECT dc.*, cp.title, cp.description, cp.difficulty, cp.starter_code, cp.test_cases, cp.xp_reward
       FROM daily_challenges dc
       JOIN coding_problems cp ON dc.problem_id = cp.id
       WHERE dc.challenge_date = ?`,
      [today]
    );
    res.json(challenge || null);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/coding/submissions (my submissions)
router.get('/submissions', requireAuth, async (req, res) => {
  try {
    const submissions = await query(
      `SELECT cs.*, cp.title as problem_title, cp.difficulty
       FROM coding_submissions cs
       JOIN coding_problems cp ON cs.problem_id = cp.id
       WHERE cs.user_id = ?
       ORDER BY cs.submitted_at DESC LIMIT 100`,
      [req.user.id]
    );
    res.json(submissions);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/coding/run — run code securely via Python sandboxed executor
router.post('/run', requireAuth, async (req, res) => {
  try {
    const { code, language, problem_id } = req.body;
    if (!code) return res.status(400).json({ error: 'Code is required' });

    const problem = problem_id ? await queryOne('SELECT test_cases FROM coding_problems WHERE id = ?', [problem_id]) : null;

    const result = await executeCode(code, language || 'javascript', problem?.test_cases || []);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message, output: '' });
  }
});

// POST /api/coding/submit
router.post('/submit', requireAuth, async (req, res) => {
  try {
    const { code, language, problem_id } = req.body;
    if (!code || !problem_id) return res.status(400).json({ error: 'Code and problem_id required' });

    const problem = await queryOne('SELECT * FROM coding_problems WHERE id = ?', [problem_id]);
    if (!problem) return res.status(404).json({ error: 'Problem not found' });

    const result = await executeCode(code, language || 'javascript', problem.test_cases || []);

    const status   = result.passed ? 'accepted' : result.error ? 'error' : 'wrong_answer';
    const xp_earned = result.passed ? problem.xp_reward : 0;

    await execute(
      'INSERT INTO coding_submissions (user_id, problem_id, code, language, status, execution_time_ms, xp_earned) VALUES (?,?,?,?,?,?,?)',
      [req.user.id, problem_id, code, language, status, result.time_ms, xp_earned]
    );

    if (result.passed) {
      // Award XP
      await execute('UPDATE users SET total_xp = total_xp + ?, problems_solved = problems_solved + 1 WHERE id = ?', [xp_earned, req.user.id]);
      await execute('UPDATE leaderboard_entries SET total_xp = total_xp + ?, problems_solved = problems_solved + 1 WHERE user_id = ?', [xp_earned, req.user.id]);

      // 🔔 Trigger n8n automation: problem solved
      triggerWebhook('coding.problem_solved', {
        userId: req.user.id, problemId: problem_id, xpEarned: xp_earned, language
      }).catch(console.error);
    }

    res.json({ status, result, xp_earned });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Code Executor (sandboxed) ─────────────────────────────────
async function executeCode(code, language, testCases) {
  const tmpDir = os.tmpdir();
  const start = Date.now();

  try {
    let output = '';
    let passed = false;
    let error = null;

    if (language === 'python') {
      // Python execution via python3 subprocess
      const tmpFile = path.join(tmpDir, `sb_${Date.now()}.py`);
      const testRunner = buildPythonTestRunner(code, testCases);
      await fs.writeFile(tmpFile, testRunner);

      const result = await runProcess(`python3 "${tmpFile}"`, 10000);
      await fs.unlink(tmpFile).catch(() => {});
      output = result.stdout;
      error  = result.stderr;
      passed = result.stdout.includes('ALL_TESTS_PASSED');

    } else if (language === 'javascript') {
      const tmpFile = path.join(tmpDir, `sb_${Date.now()}.js`);
      const testRunner = buildJSTestRunner(code, testCases);
      await fs.writeFile(tmpFile, testRunner);

      const result = await runProcess(`node "${tmpFile}"`, 10000);
      await fs.unlink(tmpFile).catch(() => {});
      output = result.stdout;
      error  = result.stderr;
      passed = result.stdout.includes('ALL_TESTS_PASSED');
    } else {
      // For other languages, just return output
      output = `Language "${language}" execution queued.`;
      passed = false;
    }

    return { output, passed, error, time_ms: Date.now() - start };
  } catch (err) {
    return { output: '', passed: false, error: err.message, time_ms: Date.now() - start };
  }
}

function buildJSTestRunner(code, testCases) {
  const cases = JSON.stringify(Array.isArray(testCases) ? testCases : []);
  return `
${code}
const cases = ${cases};
let allPassed = true;
for (const tc of cases) {
  try {
    const fnName = Object.keys(global).find(k => typeof global[k]==='function' && !['require','setTimeout','setInterval','Buffer'].includes(k));
    // Fallback: eval a call
    const result = eval('(' + ${JSON.stringify(code)}.match(/function\\s+(\\w+)/)?.[1] + ')(' + JSON.stringify(tc.input) + ')');
    const ok = JSON.stringify(result) === JSON.stringify(tc.expected);
    if (!ok) { allPassed = false; console.log('FAIL: expected', tc.expected, 'got', result); }
    else console.log('PASS');
  } catch(e) { allPassed = false; console.error('ERROR:', e.message); }
}
if (allPassed) console.log('ALL_TESTS_PASSED');
`;
}

function buildPythonTestRunner(code, testCases) {
  const cases = JSON.stringify(Array.isArray(testCases) ? testCases : []);
  return `
import json, sys
${code}

cases = json.loads('''${cases.replace(/'/g, "\\'")}''')
all_passed = True
import re
fn_match = re.search(r'def (\\w+)', '''${code.replace(/'/g, "\\'")}''')
fn_name = fn_match.group(1) if fn_match else None

for tc in cases:
    try:
        inp = tc.get('input')
        expected = tc.get('expected')
        if fn_name:
            fn = locals().get(fn_name) or globals().get(fn_name)
            if isinstance(inp, list):
                result = fn(*inp)
            else:
                result = fn(inp)
            if result == expected:
                print('PASS')
            else:
                all_passed = False
                print(f'FAIL: expected {expected} got {result}')
    except Exception as e:
        all_passed = False
        print(f'ERROR: {e}')

if all_passed:
    print('ALL_TESTS_PASSED')
`;
}

function runProcess(cmd, timeout) {
  return new Promise((resolve, reject) => {
    exec(cmd, { timeout, maxBuffer: 1024 * 1024 }, (error, stdout, stderr) => {
      resolve({ stdout: stdout || '', stderr: stderr || '', error });
    });
  });
}

async function triggerWebhook(event, payload) {
  const url = process.env.N8N_WEBHOOK_URL || process.env.MAKE_WEBHOOK_URL;
  if (!url) return;
  await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-SkillBridge-Event': event },
    body: JSON.stringify({ event, payload, timestamp: new Date().toISOString() }),
  });
}

module.exports = router;
