// server/routes/users.js
const router = require('express').Router();
const { query, execute, queryOne } = require('../utils/db');
const { requireAuth } = require('../middleware/auth');

// GET /api/users/me
router.get('/me', requireAuth, async (req, res) => {
  try {
    const user = await queryOne(
      'SELECT id, email, full_name, role, avatar_url, bio, total_xp, streak_days, problems_solved, preferred_language, created_at FROM users WHERE id = ?',
      [req.user.id]
    );
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/users/me
router.put('/me', requireAuth, async (req, res) => {
  try {
    const { full_name, bio, avatar_url, preferred_language } = req.body;
    await execute(
      'UPDATE users SET full_name=?, bio=?, avatar_url=?, preferred_language=? WHERE id=?',
      [full_name || req.user.full_name, bio || null, avatar_url || null, preferred_language || 'en', req.user.id]
    );
    const updated = await queryOne('SELECT id, email, full_name, role, avatar_url, bio, total_xp, streak_days, problems_solved FROM users WHERE id=?', [req.user.id]);
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/users/:id
router.get('/:id', async (req, res) => {
  try {
    const user = await queryOne(
      'SELECT id, full_name, avatar_url, bio, total_xp, streak_days, problems_solved, created_at FROM users WHERE id = ? AND is_active = 1',
      [req.params.id]
    );
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
