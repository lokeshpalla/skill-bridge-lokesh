// server/routes/auth.js
const router = require('express').Router();
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { query, execute, queryOne } = require('../utils/db');
const { signTokens, JWT_SECRET, requireAuth } = require('../middleware/auth');
const jwt = require('jsonwebtoken');

// ── POST /api/auth/register ───────────────────────────────────
router.post('/register', async (req, res) => {
  try {
    const { email, password, full_name } = req.body;

    if (!email || !password)
      return res.status(400).json({ error: 'Email and password are required' });
    if (password.length < 6)
      return res.status(400).json({ error: 'Password must be at least 6 characters' });

    const normalizedEmail = email.toLowerCase().trim();

    const existing = await queryOne('SELECT id FROM users WHERE email = ?', [normalizedEmail]);
    if (existing)
      return res.status(409).json({ error: 'An account with this email already exists' });

    const password_hash = await bcrypt.hash(password, 12);

    const result = await execute(
      'INSERT INTO users (email, password_hash, full_name, role) VALUES (?, ?, ?, ?)',
      [normalizedEmail, password_hash, full_name?.trim() || '', 'student']
    );
    const userId = result.insertId;

    // Bootstrap leaderboard row
    await execute('INSERT INTO leaderboard_entries (user_id, total_xp, streak_days, problems_solved) VALUES (?, 0, 0, 0)', [userId]);

    const tokens = signTokens(userId, 'student');

    // Fire-and-forget automation webhook
    triggerWebhook('user.registered', { userId, email: normalizedEmail, full_name }).catch(() => {});

    return res.status(201).json({
      user: { id: userId, email: normalizedEmail, full_name: full_name || '', role: 'student', total_xp: 0, streak_days: 0, problems_solved: 0 },
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
    });
  } catch (err) {
    console.error('[register]', err);
    return res.status(500).json({ error: 'Registration failed. Please try again.' });
  }
});

// ── POST /api/auth/login ──────────────────────────────────────
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password)
      return res.status(400).json({ error: 'Email and password are required' });

    const user = await queryOne(
      'SELECT id, email, full_name, role, password_hash, total_xp, streak_days, problems_solved, avatar_url, is_active FROM users WHERE email = ?',
      [email.toLowerCase().trim()]
    );

    if (!user)
      return res.status(401).json({ error: 'Invalid email or password' });

    if (!user.is_active)
      return res.status(403).json({ error: 'Account is deactivated. Please contact support.' });

    const passwordMatch = await bcrypt.compare(password, user.password_hash);
    if (!passwordMatch)
      return res.status(401).json({ error: 'Invalid email or password' });

    const tokens = signTokens(user.id, user.role);

    // Update streak async, don't block response
    updateStreak(user.id).catch(() => {});

    const { password_hash, reset_token, reset_token_expires, ...safeUser } = user;

    return res.json({
      user: safeUser,
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
    });
  } catch (err) {
    console.error('[login]', err);
    return res.status(500).json({ error: 'Login failed. Please try again.' });
  }
});

// ── POST /api/auth/refresh ────────────────────────────────────
router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken)
      return res.status(401).json({ error: 'Refresh token required' });

    let decoded;
    try {
      decoded = jwt.verify(refreshToken, JWT_SECRET);
    } catch (e) {
      return res.status(401).json({ error: 'Invalid or expired refresh token' });
    }

    if (decoded.type !== 'refresh')
      return res.status(401).json({ error: 'Invalid token type' });

    const user = await queryOne(
      'SELECT id, role FROM users WHERE id = ? AND is_active = 1',
      [decoded.id]
    );
    if (!user)
      return res.status(401).json({ error: 'User not found' });

    const tokens = signTokens(user.id, user.role);
    return res.json({ accessToken: tokens.accessToken, refreshToken: tokens.refreshToken });
  } catch (err) {
    console.error('[refresh]', err);
    return res.status(401).json({ error: 'Token refresh failed' });
  }
});

// ── GET /api/auth/me ──────────────────────────────────────────
router.get('/me', requireAuth, (req, res) => {
  // requireAuth already stripped sensitive fields
  return res.json(req.user);
});

// ── POST /api/auth/forgot-password ───────────────────────────
router.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email)
      return res.status(400).json({ error: 'Email is required' });

    const user = await queryOne('SELECT id FROM users WHERE email = ?', [email.toLowerCase().trim()]);

    // Always return success to prevent email enumeration
    if (user) {
      const token = crypto.randomBytes(32).toString('hex');
      const expires = new Date(Date.now() + 3_600_000); // 1 hour
      await execute(
        'UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE id = ?',
        [token, expires, user.id]
      );
      triggerWebhook('auth.password_reset', { email, token, expires }).catch(() => {});
    }

    return res.json({ message: 'If that email exists, a reset link has been sent.' });
  } catch (err) {
    console.error('[forgot-password]', err);
    return res.status(500).json({ error: 'Password reset failed' });
  }
});

// ── POST /api/auth/reset-password ────────────────────────────
router.post('/reset-password', async (req, res) => {
  try {
    const { token, password } = req.body;
    if (!token || !password)
      return res.status(400).json({ error: 'Token and new password are required' });
    if (password.length < 6)
      return res.status(400).json({ error: 'Password must be at least 6 characters' });

    const user = await queryOne(
      'SELECT id FROM users WHERE reset_token = ? AND reset_token_expires > NOW()',
      [token]
    );
    if (!user)
      return res.status(400).json({ error: 'Reset link is invalid or has expired' });

    const password_hash = await bcrypt.hash(password, 12);
    await execute(
      'UPDATE users SET password_hash = ?, reset_token = NULL, reset_token_expires = NULL WHERE id = ?',
      [password_hash, user.id]
    );

    return res.json({ message: 'Password has been reset successfully' });
  } catch (err) {
    console.error('[reset-password]', err);
    return res.status(500).json({ error: 'Password reset failed' });
  }
});

// ── POST /api/auth/logout ─────────────────────────────────────
router.post('/logout', requireAuth, (req, res) => {
  // Stateless JWT — client deletes tokens. Could add a token blacklist here.
  return res.json({ message: 'Logged out successfully' });
});

// ── Helpers ──────────────────────────────────────────────────
async function updateStreak(userId) {
  const today = new Date().toISOString().split('T')[0];
  try {
    await execute(
      'INSERT IGNORE INTO user_streaks (user_id, activity_date, activity_type) VALUES (?, ?, ?)',
      [userId, today, 'login']
    );
    // Count consecutive days backwards from today
    const rows = await query(
      'SELECT activity_date FROM user_streaks WHERE user_id = ? ORDER BY activity_date DESC LIMIT 90',
      [userId]
    );
    let streak = 0;
    let cursor = new Date(today);
    for (const row of rows) {
      const d = new Date(row.activity_date);
      const diffDays = Math.round((cursor - d) / 86_400_000);
      if (diffDays > 1) break;
      streak++;
      cursor = d;
    }
    await execute('UPDATE users SET streak_days = ? WHERE id = ?', [streak, userId]);
    await execute('UPDATE leaderboard_entries SET streak_days = ? WHERE user_id = ?', [streak, userId]);
  } catch (e) {
    console.error('[updateStreak]', e.message);
  }
}

async function triggerWebhook(event, payload) {
  const url = process.env.N8N_WEBHOOK_URL || process.env.MAKE_WEBHOOK_URL;
  if (!url) return;
  await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-SkillBridge-Event': event },
    body: JSON.stringify({ event, payload, timestamp: new Date().toISOString() }),
  });
}

module.exports = router;
