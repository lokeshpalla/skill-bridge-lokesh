// server/routes/webhooks.js — n8n & Make.com automation endpoints
const router = require('express').Router();
const { query, execute, queryOne } = require('../utils/db');

// Webhook secret verification
const verifySecret = (req, res, next) => {
  const secret = req.headers['x-webhook-secret'];
  if (secret !== process.env.WEBHOOK_SECRET) {
    return res.status(401).json({ error: 'Invalid webhook secret' });
  }
  next();
};

// ─────────────────────────────────────────────────────────────
// INBOUND webhooks FROM n8n / Make.com
// ─────────────────────────────────────────────────────────────

// POST /api/webhooks/n8n — receive events from n8n workflows
router.post('/n8n', verifySecret, async (req, res) => {
  const { event, payload } = req.body;
  console.log(`[n8n webhook] event: ${event}`, payload);

  await execute(
    'INSERT INTO automation_events (event_type, payload, source, status) VALUES (?,?,?,?)',
    [event, JSON.stringify(payload), 'n8n', 'processed']
  );

  switch (event) {
    case 'daily_challenge.created':
      // n8n creates daily challenge, we log it
      break;
    case 'leaderboard.refresh':
      await refreshLeaderboardRanks();
      break;
    case 'certification.issue':
      await issueCertification(payload);
      break;
    case 'internship.reminder':
      // n8n sends reminders, just log here
      break;
    default:
      console.log(`Unhandled n8n event: ${event}`);
  }

  res.json({ received: true, event });
});

// POST /api/webhooks/make — receive events from Make.com
router.post('/make', verifySecret, async (req, res) => {
  const { event, data } = req.body;
  console.log(`[Make.com webhook] event: ${event}`, data);

  await execute(
    'INSERT INTO automation_events (event_type, payload, source, status) VALUES (?,?,?,?)',
    [event, JSON.stringify(data), 'make', 'processed']
  );

  res.json({ received: true });
});

// ─────────────────────────────────────────────────────────────
// OUTBOUND trigger endpoints (called by server, picked up by n8n)
// These are "pull" endpoints n8n polls, or "push" we POST to n8n
// ─────────────────────────────────────────────────────────────

// GET /api/webhooks/pending-events — n8n polls this
router.get('/pending-events', verifySecret, async (req, res) => {
  const events = await query(
    'SELECT * FROM automation_events WHERE status = "pending" ORDER BY created_at ASC LIMIT 50'
  );
  if (events.length) {
    await execute(
      'UPDATE automation_events SET status = "processed" WHERE id IN (?)',
      [events.map(e => e.id)]
    );
  }
  res.json(events);
});

// POST /api/webhooks/trigger — internal endpoint to fire a webhook to n8n
router.post('/trigger', async (req, res) => {
  const { event, payload } = req.body;
  await logAndSend(event, payload, 'internal');
  res.json({ sent: true });
});

// ─────────────────────────────────────────────────────────────
// n8n / Make.com WORKFLOW DOCUMENTATION (returned as JSON)
// ─────────────────────────────────────────────────────────────

// GET /api/webhooks/workflows — returns workflow config for n8n import
router.get('/workflows', (req, res) => {
  res.json({
    description: 'SkillBridge Automation Workflows',
    n8n_workflows: [
      {
        name: 'Welcome Email on Register',
        trigger: 'Webhook: user.registered',
        actions: ['Send welcome email via SMTP/SendGrid', 'Add to CRM (HubSpot/Notion)', 'Post to Slack #new-users'],
        n8n_import: '/automation/n8n/welcome-email.json'
      },
      {
        name: 'Daily Challenge Creator',
        trigger: 'Cron: 00:00 daily',
        actions: ['Pick random problem from DB', 'POST /api/webhooks/n8n { event: "daily_challenge.created" }', 'Send push notification to all students'],
        n8n_import: '/automation/n8n/daily-challenge.json'
      },
      {
        name: 'Leaderboard Refresh',
        trigger: 'Cron: every hour',
        actions: ['Call GET /api/leaderboard/raw', 'Recompute ranks with pandas', 'POST results back'],
        n8n_import: '/automation/n8n/leaderboard-refresh.json'
      },
      {
        name: 'Mentor Booking Notification',
        trigger: 'Webhook: booking.created',
        actions: ['Email student + mentor', 'Create Google Calendar invite', 'Send Slack DM'],
        n8n_import: '/automation/n8n/booking-notification.json'
      },
      {
        name: 'Internship Deadline Alert',
        trigger: 'Cron: daily at 09:00',
        actions: ['Query internships expiring in 7 days', 'Email matched students', 'Post in Discord #opportunities'],
        n8n_import: '/automation/n8n/internship-alerts.json'
      },
      {
        name: 'XP Streak Breakdown Alert',
        trigger: 'Cron: daily at 20:00',
        actions: ['Find users with streak >= 7 who haven\'t logged in today', 'Send push notification "Don\'t break your streak!"'],
        n8n_import: '/automation/n8n/streak-alert.json'
      },
      {
        name: 'Certificate Auto-Issue',
        trigger: 'Webhook: course.completed',
        actions: ['Generate PDF certificate', 'Store hash in DB', 'Email PDF to student', 'Post to LinkedIn API'],
        n8n_import: '/automation/n8n/certification.json'
      },
    ],
    make_scenarios: [
      {
        name: 'New User → HubSpot CRM',
        trigger: 'Webhook: user.registered',
        actions: ['Create HubSpot contact', 'Add to onboarding email sequence']
      },
      {
        name: 'Problem Solved → Badge Award',
        trigger: 'Webhook: coding.problem_solved',
        actions: ['Check badge thresholds', 'Award badge via API', 'Post on user activity feed']
      },
      {
        name: 'Portfolio Submission → AI Review',
        trigger: 'Webhook: portfolio.submitted',
        actions: ['Send to Claude API for review', 'Store AI feedback', 'Notify mentor']
      },
    ]
  });
});

// ── Helpers ──────────────────────────────────────────────────
async function refreshLeaderboardRanks() {
  await query(`
    UPDATE leaderboard_entries le
    JOIN (
      SELECT user_id, RANK() OVER (ORDER BY total_xp DESC) as new_rank
      FROM leaderboard_entries
    ) ranked ON le.user_id = ranked.user_id
    SET le.rank_position = ranked.new_rank
  `);
}

async function issueCertification({ userId, courseId, title }) {
  const hash = require('crypto').randomBytes(16).toString('hex');
  await execute(
    'INSERT INTO certifications (user_id, course_id, title, cert_hash, is_verified) VALUES (?,?,?,?,1)',
    [userId, courseId, title, hash]
  );
}

async function logAndSend(event, payload, source) {
  await execute(
    'INSERT INTO automation_events (event_type, payload, source, status) VALUES (?,?,?,?)',
    [event, JSON.stringify(payload), source, 'pending']
  );
  // Also fire immediately if webhook URL configured
  const url = process.env.N8N_WEBHOOK_URL;
  if (url) {
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-SkillBridge-Event': event },
      body: JSON.stringify({ event, payload }),
    }).catch(console.error);
  }
}

module.exports = router;
