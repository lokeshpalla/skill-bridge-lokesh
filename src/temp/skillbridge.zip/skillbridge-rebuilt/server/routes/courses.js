// server/routes/courses.js
const router = require('express').Router();
const { query, execute, queryOne } = require('../utils/db');
const { requireAuth, optionalAuth } = require('../middleware/auth');

// GET /api/courses
router.get('/', optionalAuth, async (req, res) => {
  try {
    const { category, difficulty, limit = 50, offset = 0 } = req.query;
    let sql = 'SELECT id, title, description, category, difficulty, duration_hours, image_url, demo_video_url, is_published FROM courses WHERE is_published = 1';
    const params = [];
    if (category && category !== 'All') { sql += ' AND category = ?'; params.push(category); }
    if (difficulty && difficulty !== 'All') { sql += ' AND difficulty = ?'; params.push(difficulty.toLowerCase()); }
    sql += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));
    const courses = await query(sql, params);
    res.json(courses);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/courses/enrollments/me
router.get('/enrollments/me', requireAuth, async (req, res) => {
  try {
    const enrollments = await query(
      'SELECT ce.*, c.title, c.category, c.image_url FROM course_enrollments ce JOIN courses c ON ce.course_id = c.id WHERE ce.user_id = ?',
      [req.user.id]
    );
    res.json(enrollments);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/courses/:id
router.get('/:id', async (req, res) => {
  try {
    const course = await queryOne('SELECT * FROM courses WHERE id = ? AND is_published = 1', [req.params.id]);
    if (!course) return res.status(404).json({ error: 'Course not found' });
    res.json(course);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/courses/:id/enroll
router.post('/:id/enroll', requireAuth, async (req, res) => {
  try {
    await execute(
      'INSERT IGNORE INTO course_enrollments (user_id, course_id) VALUES (?, ?)',
      [req.user.id, req.params.id]
    );
    res.json({ enrolled: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
