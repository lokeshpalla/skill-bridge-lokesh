// server/routes/leaderboard.js
const router = require('express').Router();
const { query, execute, queryOne } = require('../utils/db');
const { optionalAuth } = require('../middleware/auth');

// GET /api/leaderboard
router.get('/', optionalAuth, async (req, res) => {
  try {
    const { limit = 50, offset = 0 } = req.query;
    const rows = await query(
      `SELECT le.user_id, le.total_xp, le.streak_days, le.problems_solved,
              u.full_name, u.avatar_url,
              RANK() OVER (ORDER BY le.total_xp DESC) as rank_position,
              FLOOR(le.total_xp / 1000) + 1 as level
       FROM leaderboard_entries le
       JOIN users u ON le.user_id = u.id
       WHERE u.is_active = 1
       ORDER BY le.total_xp DESC
       LIMIT ? OFFSET ?`,
      [parseInt(limit), parseInt(offset)]
    );

    // If current user is logged in, find their rank
    let myRank = null;
    if (req.user) {
      const r = await queryOne(
        'SELECT COUNT(*) + 1 as rank FROM leaderboard_entries le JOIN users u ON le.user_id = u.id WHERE le.total_xp > (SELECT total_xp FROM leaderboard_entries WHERE user_id = ?) AND u.is_active = 1',
        [req.user.id]
      );
      myRank = r?.rank || null;
    }

    res.json({ entries: rows, myRank });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/leaderboard/raw  (for n8n/analytics)
router.get('/raw', async (req, res) => {
  try {
    const rows = await query('SELECT user_id, total_xp, streak_days, problems_solved FROM leaderboard_entries ORDER BY total_xp DESC');
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
