// server/routes/analytics.js — proxies to Python service or falls back to SQL
const router = require('express').Router();
const { query } = require('../utils/db');
const { requireAuth, requireRole } = require('../middleware/auth');

const PYTHON_URL = process.env.PYTHON_SERVICE_URL || 'http://localhost:5001';

async function pythonProxy(path, res, fallback) {
  try {
    const r = await fetch(`${PYTHON_URL}${path}`, { signal: AbortSignal.timeout(5000) });
    if (!r.ok) throw new Error('Python service error');
    const data = await r.json();
    return res.json(data);
  } catch {
    // Python service unavailable — use SQL fallback
    return res.json(await fallback());
  }
}

// GET /api/analytics/user/:id/progress
router.get('/user/:id/progress', requireAuth, async (req, res) => {
  await pythonProxy(`/analytics/user/${req.params.id}/progress`, res, async () => {
    const subs = await query('SELECT status, xp_earned, language FROM coding_submissions WHERE user_id = ?', [req.params.id]);
    const total = subs.length;
    const accepted = subs.filter(s => s.status === 'accepted').length;
    return { total_submissions: total, total_accepted: accepted, acceptance_rate: total ? Math.round(accepted / total * 100) : 0 };
  });
});

// GET /api/analytics/platform  (admin only)
router.get('/platform', requireAuth, requireRole('admin'), async (req, res) => {
  await pythonProxy('/analytics/platform', res, async () => {
    const [users] = await query('SELECT COUNT(*) as count FROM users');
    const [subs]  = await query('SELECT COUNT(*) as count FROM coding_submissions');
    const [enr]   = await query('SELECT COUNT(*) as count FROM course_enrollments');
    return { total_users: users?.count || 0, total_submissions: subs?.count || 0, total_enrollments: enr?.count || 0 };
  });
});

// GET /api/analytics/leaderboard
router.get('/leaderboard', async (req, res) => {
  await pythonProxy('/analytics/leaderboard', res, async () => {
    return await query('SELECT le.*, u.full_name, u.avatar_url FROM leaderboard_entries le JOIN users u ON le.user_id = u.id ORDER BY le.total_xp DESC LIMIT 50');
  });
});

module.exports = router;
