// server/routes/mentors.js
const router = require('express').Router();
const { query, execute, queryOne } = require('../utils/db');
const { requireAuth, optionalAuth } = require('../middleware/auth');
const crypto = require('crypto');

// GET /api/mentors
router.get('/', optionalAuth, async (req, res) => {
  try {
    const { skill, search } = req.query;
    let sql = `SELECT u.id, u.full_name, u.avatar_url,
               mp.title, mp.company, mp.hourly_rate, mp.availability,
               mp.skills, mp.sessions_count, mp.rating, mp.linkedin_url, mp.twitter_url, u.bio
               FROM mentor_profiles mp
               JOIN users u ON mp.user_id = u.id
               WHERE u.is_active = 1`;
    const params = [];
    if (search) { sql += ' AND (u.full_name LIKE ? OR mp.company LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
    sql += ' ORDER BY mp.rating DESC LIMIT 50';
    const mentors = await query(sql, params);
    res.json(mentors);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/mentors/bookings/me
router.get('/bookings/me', requireAuth, async (req, res) => {
  try {
    const bookings = await query(
      `SELECT mb.*, u.full_name as mentor_name, u.avatar_url as mentor_avatar
       FROM mentor_bookings mb JOIN users u ON mb.mentor_id = u.id
       WHERE mb.student_id = ? ORDER BY mb.session_date DESC`,
      [req.user.id]
    );
    res.json(bookings);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/mentors/book
router.post('/book', requireAuth, async (req, res) => {
  try {
    const { mentor_id, session_date, duration_min, session_type, topic, notes } = req.body;
    if (!mentor_id || !session_date) return res.status(400).json({ error: 'mentor_id and session_date required' });
    const roomCode = crypto.randomBytes(4).toString('hex');
    const result = await execute(
      'INSERT INTO mentor_bookings (student_id, mentor_id, session_date, duration_min, session_type, topic, notes, video_room_code) VALUES (?,?,?,?,?,?,?,?)',
      [req.user.id, mentor_id, session_date, duration_min || 60, session_type || 'one_on_one', topic || '', notes || '', roomCode]
    );
    res.status(201).json({ id: result.insertId, video_room_code: roomCode });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
