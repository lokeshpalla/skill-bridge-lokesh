// server/routes/portfolio.js
const router = require('express').Router();
const { query, execute, queryOne } = require('../utils/db');
const { requireAuth, optionalAuth } = require('../middleware/auth');

// GET /api/portfolio/me  or  /api/portfolio/:userId
router.get('/me', requireAuth, async (req, res) => {
  try {
    const projects = await query('SELECT * FROM portfolio_projects WHERE user_id = ? ORDER BY is_featured DESC, created_at DESC', [req.user.id]);
    const certs = await query('SELECT * FROM certifications WHERE user_id = ?', [req.user.id]);
    const user = await queryOne('SELECT id, full_name, avatar_url, bio, total_xp, streak_days, problems_solved FROM users WHERE id = ?', [req.user.id]);
    res.json({ user, projects, certifications: certs });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/:userId', optionalAuth, async (req, res) => {
  try {
    const user = await queryOne('SELECT id, full_name, avatar_url, bio, total_xp, streak_days, problems_solved FROM users WHERE id = ? AND is_active = 1', [req.params.userId]);
    if (!user) return res.status(404).json({ error: 'Portfolio not found' });
    const projects = await query('SELECT * FROM portfolio_projects WHERE user_id = ? ORDER BY is_featured DESC', [req.params.userId]);
    const certs = await query('SELECT * FROM certifications WHERE user_id = ? AND is_verified = 1', [req.params.userId]);
    res.json({ user, projects, certifications: certs });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// PUT /api/portfolio/me  — upsert projects array
router.put('/me', requireAuth, async (req, res) => {
  try {
    const { projects, bio } = req.body;
    if (bio !== undefined) await execute('UPDATE users SET bio = ? WHERE id = ?', [bio, req.user.id]);
    if (Array.isArray(projects)) {
      // Delete old, re-insert new
      await execute('DELETE FROM portfolio_projects WHERE user_id = ?', [req.user.id]);
      for (const p of projects) {
        await execute(
          'INSERT INTO portfolio_projects (user_id, title, description, tech_stack, github_url, live_url, image_url, is_featured) VALUES (?,?,?,?,?,?,?,?)',
          [req.user.id, p.title, p.description || '', JSON.stringify(p.tech_stack || []), p.github_url || null, p.live_url || null, p.image_url || null, p.is_featured ? 1 : 0]
        );
      }
    }
    res.json({ updated: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
