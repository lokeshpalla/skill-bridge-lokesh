// server/routes/ai.js — AI Assistant with Socratic mode, interview sim, code review
const router = require('express').Router();
const { requireAuth } = require('../middleware/auth');
const { query } = require('../utils/db');

const OPENAI_KEY   = process.env.OPENAI_API_KEY;
const ANTHROPIC_KEY= process.env.ANTHROPIC_API_KEY;
const AI_PROVIDER  = process.env.AI_PROVIDER || 'openai';

/* ── SYSTEM PROMPTS BY MODE ─────────────────────────────────── */
const SYSTEM_PROMPTS = {
  chat: `You are SkillBridge AI — an expert coding tutor and career coach for Indian engineering students targeting top tech companies.

CORE PHILOSOPHY — SOCRATIC METHOD:
- NEVER give direct answers to coding problems. Always guide with questions.
- Ask: "What have you tried so far?" before helping.
- Break down problems: "What's the simplest subproblem you could solve first?"
- Celebrate progress, gently redirect wrong approaches.
- Be concise — responses under 200 words unless showing code.

CAPABILITIES:
1. Coding hints (guide, never solve)
2. Concept explanation with real-world analogies
3. Career guidance (roadmaps, resume, FAANG prep)
4. Learning support in 5 languages

LANGUAGE RULE: Always respond in the SAME language the user writes in.
Supported: English, Telugu (తెలుగు), Hindi (हिंदी), Tamil (தமிழ்), Kannada (ಕನ್ನಡ)

TONE: Warm, encouraging, like a brilliant friend who happens to be a senior SDE.`,

  interview: `You are a senior technical interviewer at a top-tier tech company (Google/Microsoft/Amazon level).

INTERVIEW RULES:
- Ask ONE question at a time. Wait for the candidate to respond.
- Start with a clear problem statement or behavioral question.
- Follow up with probing questions based on their answer.
- After each answer, give structured feedback: [Strengths] [Areas to improve] [Score: X/10]
- For DSA: start easy, increase difficulty based on performance.
- For system design: explore requirements → high-level → deep dive.
- For behavioral: use STAR framework, ask for specific examples.

SCORING: After 3-4 questions, give an overall assessment with hire/no-hire recommendation.

Keep responses professional, clear, and under 150 words per turn (except for problem statements).`,

  review: `You are a senior code reviewer at a top tech company.

REVIEW STRUCTURE (always follow this):
1. **Correctness** — does it handle all cases? What edge cases does it miss?
2. **Time Complexity** — exact Big-O with explanation
3. **Space Complexity** — exact Big-O with explanation
4. **Code Quality** — naming, readability, structure
5. **Specific Improvements** — 2-3 concrete code changes with examples
6. **Overall Rating** — X/10 with one-line verdict

Be specific and actionable. Show improved code snippets where relevant.
Be direct — don't sugarcoat real issues. Engineers grow from honest feedback.`,

  roadmap: `You are a senior engineering manager and career coach who has helped 500+ engineers land FAANG offers.

ROADMAP RULES:
- Create week-by-week structured plans with specific resources.
- Always include: what to study, how long, which resources (LeetCode, books, courses).
- Be realistic about timelines — don't overpromise.
- Include checkpoints and ways to measure progress.
- For FAANG prep: emphasize LC patterns, not random problems.
- Recommend free resources first, paid only if significantly better.

Format plans clearly with headers, weeks/months, and estimated hours per day.`,
};

/* ── POST /api/ai/chat ─────────────────────────────────────── */
router.post('/chat', requireAuth, async (req, res) => {
  const { messages, language, stream = true, mode = 'chat', systemExtra = '' } = req.body;
  if (!messages?.length) return res.status(400).json({ error: 'Messages required' });

  // Build system prompt
  let systemPrompt = SYSTEM_PROMPTS[mode] || SYSTEM_PROMPTS.chat;
  if (language && language !== 'en') {
    const langNames = { te:'Telugu (తెలుగు)', hi:'Hindi (हिंदी)', ta:'Tamil (தமிழ்)', kn:'Kannada (ಕನ್ನಡ)' };
    systemPrompt += `\n\nIMPORTANT: The user has selected ${langNames[language] || 'English'}. Respond in that language.`;
  }
  if (systemExtra) systemPrompt += `\n\nCONTEXT: ${systemExtra}`;

  try {
    if (AI_PROVIDER === 'anthropic') {
      await _streamAnthropic(messages, systemPrompt, stream, res, req.user.id);
    } else {
      await _streamOpenAI(messages, systemPrompt, stream, res, req.user.id);
    }
  } catch(err) {
    console.error('AI chat error:', err.message);
    if (!res.headersSent) res.status(500).json({ error: 'AI service unavailable' });
  }
});

/* ── POST /api/ai/analyze-code ─────────────────────────────── */
router.post('/analyze-code', requireAuth, async (req, res) => {
  const { code, language: lang = 'javascript', problem_title = 'unknown' } = req.body;
  if (!code) return res.status(400).json({ error: 'Code required' });

  const prompt = `Analyze this ${lang} code for "${problem_title}":

\`\`\`${lang}
${code}
\`\`\`

Provide:
1. **Correctness** — Will it pass edge cases?
2. **Time Complexity** — Big-O with brief explanation
3. **Space Complexity** — Big-O with brief explanation
4. **Code Quality** — 1-2 specific issues
5. **Top Improvement** — The single most impactful change

Keep it concise. Total under 200 words.`;

  try {
    const reply = await _singleMessage(prompt, SYSTEM_PROMPTS.review);
    res.json({ analysis: reply });
  } catch(err) {
    res.status(500).json({ error: 'Analysis failed' });
  }
});

/* ── POST /api/ai/socratic-hint ────────────────────────────── */
router.post('/socratic-hint', requireAuth, async (req, res) => {
  const { problem_title, problem_description, difficulty, user_code = '', stuck_on = '' } = req.body;

  const prompt = `Problem: "${problem_title}" (${difficulty})
Description: ${problem_description}
${user_code ? `Student's current code:\n\`\`\`\n${user_code}\n\`\`\`` : 'Student has not written code yet.'}
${stuck_on ? `Student says they're stuck on: ${stuck_on}` : ''}

Give a Socratic hint: ask ONE guiding question that helps them discover the next step themselves.
Do NOT reveal the approach. Make them think. Keep it under 80 words.`;

  try {
    const hint = await _singleMessage(prompt, SYSTEM_PROMPTS.chat);
    res.json({ hint });
  } catch(err) {
    res.status(500).json({ error: 'Hint failed' });
  }
});

/* ── POST /api/ai/generate-resume ──────────────────────────── */
router.post('/generate-resume', requireAuth, async (req, res) => {
  const { profile, skills = [], projects = [], certifications = [], experience = [] } = req.body;

  const prompt = `Generate an ATS-optimized resume JSON for:
Name: ${profile?.full_name}
Skills: ${skills.join(', ')}
Projects: ${JSON.stringify(projects?.slice(0,5))}
Certifications: ${JSON.stringify(certifications?.slice(0,3))}
Experience: ${JSON.stringify(experience?.slice(0,3))}

Return ONLY valid JSON with this exact structure:
{
  "summary": "2-3 sentence professional summary with keywords",
  "skills": ["skill1", "skill2", ...],
  "experience_bullets": ["• Action verb + metric + impact", ...],
  "project_bullets": ["• Project name: description with tech stack", ...],
  "ats_keywords": ["keyword1", "keyword2", ...],
  "ats_score": 92
}`;

  try {
    const raw = await _singleMessage(prompt, 'You are an expert resume writer specializing in tech industry ATS optimization. Return only valid JSON.');
    let parsed;
    try { parsed = JSON.parse(raw.replace(/```json|```/g, '').trim()); }
    catch { parsed = { summary: raw, ats_score: 85 }; }
    res.json(parsed);
  } catch(err) {
    res.status(500).json({ error: 'Resume generation failed' });
  }
});

/* ── POST /api/ai/match-internships ───────────────────────── */
router.post('/match-internships', requireAuth, async (req, res) => {
  const { profile, skills = [], internships = [] } = req.body;

  const prompt = `Match this candidate to internships and return a JSON array:
Candidate skills: ${skills.join(', ')}
Internships: ${JSON.stringify(internships?.slice(0,20))}

Return ONLY a JSON array of matched internship IDs ordered by relevance: [id1, id2, ...]
Include only good matches (>60% skill overlap).`;

  try {
    const raw = await _singleMessage(prompt, 'You are an AI recruiter. Return only a JSON array of IDs.');
    let ids;
    try { ids = JSON.parse(raw.replace(/```json|```/g,'').trim()); }
    catch { ids = []; }
    res.json({ matched_ids: ids });
  } catch(err) {
    res.status(500).json({ error: 'Matching failed', matched_ids: [] });
  }
});

/* ── STREAMING HELPERS ──────────────────────────────────────── */
async function _streamOpenAI(messages, systemPrompt, doStream, res, userId) {
  if (!OPENAI_KEY) return _mockStream(res, doStream);

  const payload = {
    model: 'gpt-4o-mini',
    messages: [{ role: 'system', content: systemPrompt }, ...messages],
    stream: doStream,
    max_tokens: 1000,
    temperature: 0.7,
  };

  const upstream = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${OPENAI_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!upstream.ok) {
    const err = await upstream.text();
    throw new Error(`OpenAI error: ${upstream.status} ${err}`);
  }

  if (!doStream) {
    const data = await upstream.json();
    return res.json({ reply: data.choices[0]?.message?.content || '' });
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  const reader = upstream.body;
  let buffer   = '';
  for await (const chunk of reader) {
    buffer += chunk.toString();
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';
    for (const line of lines) {
      if (!line.startsWith('data: ')) continue;
      const data = line.slice(6).trim();
      if (data === '[DONE]') { res.write('data: [DONE]\n\n'); res.end(); return; }
      try {
        const parsed = JSON.parse(data);
        const token  = parsed.choices?.[0]?.delta?.content || '';
        if (token) res.write(`data: ${JSON.stringify({ token })}\n\n`);
      } catch {}
    }
  }
  res.end();
}

async function _streamAnthropic(messages, systemPrompt, doStream, res, userId) {
  if (!ANTHROPIC_KEY) return _mockStream(res, doStream);

  const upstream = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': ANTHROPIC_KEY,
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 1000,
      system: systemPrompt,
      messages,
      stream: doStream,
    }),
  });

  if (!upstream.ok) throw new Error(`Anthropic error: ${upstream.status}`);

  if (!doStream) {
    const data = await upstream.json();
    return res.json({ reply: data.content?.[0]?.text || '' });
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  let buffer = '';
  for await (const chunk of upstream.body) {
    buffer += chunk.toString();
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';
    for (const line of lines) {
      if (!line.startsWith('data: ')) continue;
      const data = line.slice(6).trim();
      try {
        const parsed = JSON.parse(data);
        if (parsed.type === 'content_block_delta') {
          const token = parsed.delta?.text || '';
          if (token) res.write(`data: ${JSON.stringify({ token })}\n\n`);
        }
        if (parsed.type === 'message_stop') { res.write('data: [DONE]\n\n'); res.end(); return; }
      } catch {}
    }
  }
  res.end();
}

async function _singleMessage(prompt, systemPrompt = SYSTEM_PROMPTS.chat) {
  if (AI_PROVIDER === 'anthropic' && ANTHROPIC_KEY) {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': ANTHROPIC_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({ model: 'claude-haiku-4-5-20251001', max_tokens: 800, system: systemPrompt, messages: [{ role: 'user', content: prompt }] }),
    });
    const data = await res.json();
    return data.content?.[0]?.text || '';
  }
  if (OPENAI_KEY) {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${OPENAI_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: 'gpt-4o-mini', messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: prompt }], max_tokens: 800, temperature: 0.5 }),
    });
    const data = await res.json();
    return data.choices?.[0]?.message?.content || '';
  }
  return 'AI service not configured. Add OPENAI_API_KEY or ANTHROPIC_API_KEY to .env';
}

function _mockStream(res, doStream) {
  if (!doStream) return res.json({ reply: 'Configure an AI provider in .env to enable AI features.' });
  res.setHeader('Content-Type', 'text/event-stream');
  const msg = 'Add OPENAI_API_KEY or ANTHROPIC_API_KEY to your .env file to enable AI features.';
  msg.split(' ').forEach((word, i) => {
    setTimeout(() => res.write(`data: ${JSON.stringify({ token: word + ' ' })}\n\n`), i * 60);
  });
  setTimeout(() => { res.write('data: [DONE]\n\n'); res.end(); }, msg.split(' ').length * 60 + 100);
}

module.exports = router;
