// server/middleware/auth.js — JWT authentication middleware
const jwt = require('jsonwebtoken');
const { queryOne } = require('../utils/db');

const JWT_SECRET = process.env.JWT_SECRET || 'skillbridge-secret-change-in-prod';

// Sign access (15 min) + refresh (7 days) tokens
const signTokens = (userId, role) => ({
  accessToken:  jwt.sign({ id: userId, role }, JWT_SECRET, { expiresIn: '15m' }),
  refreshToken: jwt.sign({ id: userId, type: 'refresh' }, JWT_SECRET, { expiresIn: '7d' }),
});

// requireAuth — blocks unauthenticated requests
const requireAuth = async (req, res, next) => {
  try {
    const header = req.headers.authorization || '';
    if (!header.startsWith('Bearer '))
      return res.status(401).json({ error: 'Authentication required' });

    const token = header.slice(7);

    let decoded;
    try {
      decoded = jwt.verify(token, JWT_SECRET);
    } catch (e) {
      if (e.name === 'TokenExpiredError')
        return res.status(401).json({ error: 'Token expired', code: 'TOKEN_EXPIRED' });
      return res.status(401).json({ error: 'Invalid token' });
    }

    const user = await queryOne(
      'SELECT id, email, full_name, role, total_xp, streak_days, problems_solved, avatar_url FROM users WHERE id = ? AND is_active = 1',
      [decoded.id]
    );
    if (!user)
      return res.status(401).json({ error: 'User not found or account deactivated' });

    req.user = user;
    next();
  } catch (err) {
    console.error('[requireAuth]', err);
    return res.status(500).json({ error: 'Authentication error' });
  }
};

// requireRole — use after requireAuth
const requireRole = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role))
    return res.status(403).json({ error: 'Insufficient permissions' });
  next();
};

// optionalAuth — attaches user if token present, never blocks
const optionalAuth = async (req, res, next) => {
  try {
    const header = req.headers.authorization || '';
    if (header.startsWith('Bearer ')) {
      const token = header.slice(7);
      const decoded = jwt.verify(token, JWT_SECRET);
      req.user = await queryOne(
        'SELECT id, email, full_name, role, total_xp, streak_days FROM users WHERE id = ? AND is_active = 1',
        [decoded.id]
      );
    }
  } catch { /* silent */ }
  next();
};

module.exports = { signTokens, requireAuth, requireRole, optionalAuth, JWT_SECRET };
