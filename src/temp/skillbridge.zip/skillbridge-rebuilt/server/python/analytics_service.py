#!/usr/bin/env python3
"""
SkillBridge Nexus — Python Analytics & Data Service
Uses: pandas, numpy, scipy
Runs as a separate microservice on port 5001
Called by Node.js via internal HTTP
"""

import os
import json
from datetime import datetime, timedelta
from typing import Optional

import numpy as np
import pandas as pd
from flask import Flask, request, jsonify
import mysql.connector

app = Flask(__name__)

# ── DB connection ─────────────────────────────────────────────
def get_db():
    return mysql.connector.connect(
        host=os.environ.get('DB_HOST', 'localhost'),
        user=os.environ.get('DB_USER', 'root'),
        password=os.environ.get('DB_PASSWORD', ''),
        database=os.environ.get('DB_NAME', 'skillbridge'),
    )

def query_df(sql: str, params=None) -> pd.DataFrame:
    """Execute SQL and return pandas DataFrame."""
    conn = get_db()
    try:
        df = pd.read_sql(sql, conn, params=params)
        return df
    finally:
        conn.close()

# ─────────────────────────────────────────────────────────────
# LEADERBOARD ANALYTICS
# ─────────────────────────────────────────────────────────────
@app.route('/analytics/leaderboard', methods=['GET'])
def leaderboard_analytics():
    """Compute ranked leaderboard with stats using pandas."""
    df = query_df("""
        SELECT le.user_id, u.full_name, u.avatar_url, le.total_xp,
               le.streak_days, le.problems_solved, le.updated_at
        FROM leaderboard_entries le
        JOIN users u ON le.user_id = u.id
        WHERE u.is_active = 1
        ORDER BY le.total_xp DESC
    """)

    if df.empty:
        return jsonify([])

    # Compute rank
    df['rank'] = df['total_xp'].rank(ascending=False, method='min').astype(int)

    # Percentile within the leaderboard
    df['percentile'] = (1 - df['total_xp'].rank(pct=True)).round(3) * 100

    # XP moving average (7-day) — placeholder with numpy
    df['xp_trend'] = np.random.normal(loc=df['total_xp'].mean(), scale=df['total_xp'].std() * 0.05, size=len(df))
    df['xp_trend'] = df['xp_trend'].clip(lower=0).astype(int)

    # Level calculation: every 1000 XP = 1 level
    df['level'] = (df['total_xp'] // 1000 + 1).astype(int)

    result = df.fillna(0).to_dict(orient='records')
    return jsonify(result)

# ─────────────────────────────────────────────────────────────
# USER PROGRESS ANALYTICS
# ─────────────────────────────────────────────────────────────
@app.route('/analytics/user/<int:user_id>/progress', methods=['GET'])
def user_progress(user_id: int):
    """Detailed learning analytics for a user."""
    # Submission history
    subs = query_df("""
        SELECT cs.submitted_at, cs.status, cs.xp_earned, cs.language,
               cp.difficulty, cp.category
        FROM coding_submissions cs
        JOIN coding_problems cp ON cs.problem_id = cp.id
        WHERE cs.user_id = %s
        ORDER BY cs.submitted_at
    """, params=(user_id,))

    if subs.empty:
        return jsonify({'message': 'No data yet', 'stats': {}})

    subs['submitted_at'] = pd.to_datetime(subs['submitted_at'])
    subs['date'] = subs['submitted_at'].dt.date

    # Daily XP over time (cumulative)
    daily_xp = subs.groupby('date')['xp_earned'].sum().cumsum().reset_index()
    daily_xp.columns = ['date', 'cumulative_xp']
    daily_xp['date'] = daily_xp['date'].astype(str)

    # Problems by difficulty
    by_difficulty = subs[subs['status'] == 'accepted'].groupby('difficulty').size().to_dict()

    # Problems by category
    by_category = subs[subs['status'] == 'accepted'].groupby('category').size().to_dict()

    # Language distribution
    by_language = subs.groupby('language').size().to_dict()

    # Acceptance rate
    total = len(subs)
    accepted = len(subs[subs['status'] == 'accepted'])
    acceptance_rate = round(accepted / total * 100, 1) if total > 0 else 0

    # Streak calculation using numpy
    dates = pd.to_datetime(subs['date'].unique())
    dates_sorted = np.sort(dates)
    diffs = np.diff(dates_sorted.astype(np.int64) / 86400000000000)
    streak = int(np.sum(diffs == 1)) + 1 if len(diffs) > 0 else 1

    # Weekly activity heatmap (last 52 weeks)
    end = pd.Timestamp.today()
    start = end - pd.Timedelta(weeks=52)
    recent = subs[subs['submitted_at'] >= start].copy()
    recent['week'] = recent['submitted_at'].dt.isocalendar().week
    recent['weekday'] = recent['submitted_at'].dt.dayofweek
    heatmap = recent.groupby(['week', 'weekday']).size().reset_index()
    heatmap.columns = ['week', 'weekday', 'count']

    return jsonify({
        'daily_xp': daily_xp.to_dict(orient='records'),
        'by_difficulty': by_difficulty,
        'by_category': by_category,
        'by_language': by_language,
        'acceptance_rate': acceptance_rate,
        'total_submissions': total,
        'total_accepted': accepted,
        'current_streak': streak,
        'activity_heatmap': heatmap.to_dict(orient='records'),
    })

# ─────────────────────────────────────────────────────────────
# COURSE ANALYTICS
# ─────────────────────────────────────────────────────────────
@app.route('/analytics/courses', methods=['GET'])
def course_analytics():
    """Course enrollment and completion statistics."""
    df = query_df("""
        SELECT c.id, c.title, c.category, c.difficulty,
               COUNT(ce.id) as enrollments,
               AVG(ce.progress_percent) as avg_progress,
               SUM(CASE WHEN ce.completed_at IS NOT NULL THEN 1 ELSE 0 END) as completions
        FROM courses c
        LEFT JOIN course_enrollments ce ON c.id = ce.course_id
        WHERE c.is_published = 1
        GROUP BY c.id
        ORDER BY enrollments DESC
    """)

    if df.empty:
        return jsonify([])

    df['completion_rate'] = (df['completions'] / df['enrollments'].replace(0, 1) * 100).round(1)
    df['avg_progress'] = df['avg_progress'].fillna(0).round(1)
    df['popularity_score'] = (
        0.6 * df['enrollments'] / df['enrollments'].max() +
        0.4 * df['completion_rate'] / 100
    ).round(3)

    return jsonify(df.fillna(0).to_dict(orient='records'))

# ─────────────────────────────────────────────────────────────
# INTERNSHIP MATCHING via ML (cosine similarity)
# ─────────────────────────────────────────────────────────────
@app.route('/analytics/match-internships', methods=['POST'])
def match_internships():
    """AI-powered internship matching using sklearn TF-IDF cosine similarity."""
    data = request.json
    user_skills = data.get('skills', [])
    user_courses = data.get('courses', [])

    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.metrics.pairwise import cosine_similarity

        internships = query_df("SELECT id, title, company, skills_required, description FROM internships WHERE is_active = 1")
        if internships.empty:
            return jsonify([])

        # Build text profiles
        user_profile = ' '.join(user_skills + user_courses).lower()
        internships['profile'] = internships.apply(
            lambda r: f"{r['title']} {r['company']} {r['skills_required']} {r['description'] or ''}", axis=1
        ).str.lower()

        corpus = [user_profile] + internships['profile'].tolist()
        tfidf = TfidfVectorizer(stop_words='english', ngram_range=(1, 2))
        matrix = tfidf.fit_transform(corpus)

        scores = cosine_similarity(matrix[0:1], matrix[1:]).flatten()
        internships['match_score'] = (scores * 100).round(1)
        top = internships.nlargest(5, 'match_score')[['id', 'title', 'company', 'match_score']]

        return jsonify(top.to_dict(orient='records'))
    except ImportError:
        # sklearn not available, return all internships
        return jsonify(internships.head(5).to_dict(orient='records'))

# ─────────────────────────────────────────────────────────────
# PLATFORM HEALTH DASHBOARD
# ─────────────────────────────────────────────────────────────
@app.route('/analytics/platform', methods=['GET'])
def platform_stats():
    """Overall platform statistics for admin dashboard."""
    users   = query_df("SELECT COUNT(*) as count, DATE(created_at) as date FROM users GROUP BY date ORDER BY date")
    subs    = query_df("SELECT COUNT(*) as count, DATE(submitted_at) as date FROM coding_submissions GROUP BY date ORDER BY date")
    enrolls = query_df("SELECT COUNT(*) as count FROM course_enrollments")

    total_users = int(users['count'].sum()) if not users.empty else 0
    total_subs  = int(subs['count'].sum()) if not subs.empty else 0
    total_enr   = int(enrolls['count'].iloc[0]) if not enrolls.empty else 0

    # Growth rate (last 7 days vs prior 7 days)
    if not users.empty:
        users['date'] = pd.to_datetime(users['date'])
        last7  = users[users['date'] >= pd.Timestamp.today() - timedelta(days=7)]['count'].sum()
        prior7 = users[(users['date'] >= pd.Timestamp.today() - timedelta(days=14)) &
                       (users['date'] <  pd.Timestamp.today() - timedelta(days=7))]['count'].sum()
        growth = round((last7 - prior7) / max(prior7, 1) * 100, 1)
    else:
        growth = 0

    return jsonify({
        'total_users': total_users,
        'total_submissions': total_subs,
        'total_enrollments': total_enr,
        'user_growth_rate_pct': growth,
        'daily_registrations': users.tail(30).to_dict(orient='records') if not users.empty else [],
        'daily_submissions': subs.tail(30).to_dict(orient='records') if not subs.empty else [],
    })

# ─────────────────────────────────────────────────────────────
if __name__ == '__main__':
    port = int(os.environ.get('PYTHON_PORT', 5001))
    app.run(host='0.0.0.0', port=port, debug=os.environ.get('DEBUG', 'false') == 'true')
