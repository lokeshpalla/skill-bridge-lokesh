// server/utils/socketSignalling.js — WebRTC room signalling
module.exports = (io) => {
  const rooms = new Map(); // roomCode → Set of socket IDs

  io.on('connection', (socket) => {
    console.log(`[Socket] connected: ${socket.id}`);

    // Join a video room
    socket.on('join-room', ({ roomCode, userId, userName }) => {
      socket.join(roomCode);
      if (!rooms.has(roomCode)) rooms.set(roomCode, new Set());
      rooms.get(roomCode).add(socket.id);

      // Notify others in the room
      socket.to(roomCode).emit('user-joined', { socketId: socket.id, userId, userName });

      // Send existing peers to the new user
      const peers = [...rooms.get(roomCode)].filter(id => id !== socket.id);
      socket.emit('room-peers', peers);

      console.log(`[Room ${roomCode}] ${userName} joined. Total: ${rooms.get(roomCode).size}`);
    });

    // WebRTC signalling: offer
    socket.on('offer', ({ to, offer }) => {
      io.to(to).emit('offer', { from: socket.id, offer });
    });

    // WebRTC signalling: answer
    socket.on('answer', ({ to, answer }) => {
      io.to(to).emit('answer', { from: socket.id, answer });
    });

    // WebRTC signalling: ICE candidate
    socket.on('ice-candidate', ({ to, candidate }) => {
      io.to(to).emit('ice-candidate', { from: socket.id, candidate });
    });

    // Screen share toggle
    socket.on('screen-share', ({ roomCode, sharing }) => {
      socket.to(roomCode).emit('peer-screen-share', { socketId: socket.id, sharing });
    });

    // Chat message within room
    socket.on('room-message', ({ roomCode, message, userName }) => {
      io.to(roomCode).emit('room-message', {
        from: socket.id, userName, message,
        timestamp: new Date().toISOString()
      });
    });

    // Live code sync (for collaborative coding)
    socket.on('code-update', ({ roomCode, code, language }) => {
      socket.to(roomCode).emit('code-update', { from: socket.id, code, language });
    });

    // Disconnect cleanup
    socket.on('disconnect', () => {
      for (const [roomCode, members] of rooms) {
        if (members.has(socket.id)) {
          members.delete(socket.id);
          socket.to(roomCode).emit('user-left', { socketId: socket.id });
          if (members.size === 0) rooms.delete(roomCode);
          break;
        }
      }
      console.log(`[Socket] disconnected: ${socket.id}`);
    });
  });
};
