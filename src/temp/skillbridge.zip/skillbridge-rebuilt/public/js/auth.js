// public/js/auth.js — Client-side auth state
const Auth = (() => {
  let currentUser = null;
  const listeners = [];

  const getUser    = () => currentUser;
  const isLoggedIn = () => !!currentUser;

  const setUser = (user) => {
    currentUser = user;
    listeners.forEach(fn => fn(user));
  };

  const login = async ({ email, password }) => {
    const res = await API.auth.login({ email, password });
    if (!res || !res.accessToken)
      throw new Error('Unexpected response from server');
    localStorage.setItem('sb_token', res.accessToken);
    localStorage.setItem('sb_refresh_token', res.refreshToken);
    setUser(res.user);
    return res;
  };

  const register = async ({ email, password, full_name }) => {
    const res = await API.auth.register({ email, password, full_name });
    if (!res || !res.accessToken)
      throw new Error('Unexpected response from server');
    localStorage.setItem('sb_token', res.accessToken);
    localStorage.setItem('sb_refresh_token', res.refreshToken);
    setUser(res.user);
    return res;
  };

  const logout = async () => {
    try { await API.auth.logout(); } catch { /* ignore */ }
    localStorage.removeItem('sb_token');
    localStorage.removeItem('sb_refresh_token');
    setUser(null);
    Router.navigate('/');
  };

  // Restore session from localStorage on page load
  const restore = async () => {
    const token = localStorage.getItem('sb_token');
    if (!token) return;
    try {
      const user = await API.auth.me();
      if (user) setUser(user);
    } catch {
      // Token invalid/expired — clear storage silently
      localStorage.removeItem('sb_token');
      localStorage.removeItem('sb_refresh_token');
    }
  };

  const onChange = (fn) => { listeners.push(fn); };

  return { getUser, isLoggedIn, login, register, logout, restore, onChange, setUser };
})();
