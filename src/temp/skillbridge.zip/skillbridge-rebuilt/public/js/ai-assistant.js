/* ═══════════════════════════════════════════════════════════════
   SKILLBRIDGE AI ASSISTANT — World-Class Floating Widget
   Features: Streaming SSE, Socratic mode, interview sim,
             multilingual, code review, resume analysis,
             context-aware suggestions, conversation memory
   ═══════════════════════════════════════════════════════════════ */
const AIAssistant = (() => {
  let messages   = [];
  let isOpen     = false;
  let isLoading  = false;
  let mode       = 'chat'; // 'chat' | 'interview' | 'review'
  let interviewState = { active: false, round: 0, topic: '' };

  /* ── INIT ───────────────────────────────────────────────── */
  const init = () => {
    _setupToggle();
    _setupInput();
    _setupControls();
    _setupModes();
    _setupSuggestions();
    _injectStyles();
  };

  /* ── TOGGLE / OPEN / CLOSE ─────────────────────────────── */
  const _setupToggle = () => {
    document.getElementById('aiToggle')?.addEventListener('click', () => {
      isOpen = !isOpen;
      document.getElementById('aiPanel')?.classList.toggle('open', isOpen);
      if (isOpen) _focusInput();
    });
    document.getElementById('aiClose')?.addEventListener('click', () => {
      isOpen = false;
      document.getElementById('aiPanel')?.classList.remove('open');
    });
    // Close on Escape
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && isOpen) {
        isOpen = false;
        document.getElementById('aiPanel')?.classList.remove('open');
      }
    });
  };

  /* ── INPUT ──────────────────────────────────────────────── */
  const _setupInput = () => {
    const input = document.getElementById('aiInput');
    const send  = document.getElementById('aiSend');
    send?.addEventListener('click', _sendMessage);
    input?.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); _sendMessage(); }
    });
    input?.addEventListener('input', () => {
      input.style.height = 'auto';
      input.style.height = Math.min(input.scrollHeight, 110) + 'px';
    });
  };

  /* ── CONTROLS ───────────────────────────────────────────── */
  const _setupControls = () => {
    document.getElementById('aiClear')?.addEventListener('click', () => {
      messages = [];
      interviewState = { active: false, round: 0, topic: '' };
      mode = 'chat';
      _updateModeUI();
      document.getElementById('aiMessages').innerHTML = '';
      _appendBotMessage(_welcomeMessage());
    });
  };

  /* ── MODES ──────────────────────────────────────────────── */
  const _setupModes = () => {
    document.getElementById('aiModeBtn')?.addEventListener('click', () => {
      const menu = document.getElementById('aiModeMenu');
      if (menu) menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
    });
    document.querySelectorAll('[data-ai-mode]').forEach(btn => {
      btn.addEventListener('click', () => {
        const m = btn.dataset.aiMode;
        document.getElementById('aiModeMenu').style.display = 'none';
        _setMode(m);
      });
    });
  };

  const _setMode = (m) => {
    mode = m;
    _updateModeUI();
    const intros = {
      chat:      _welcomeMessage(),
      interview: `🎤 **Interview Simulator activated.**\n\nI'll act as a real technical interviewer. Choose your focus:\n\n• **DSA** — arrays, trees, graphs, DP\n• **System Design** — scalability, databases, APIs\n• **Behavioral** — STAR method, culture fit\n• **Frontend/Backend** — specific domain questions\n\nType your target role (e.g. "SDE at Google") and I'll begin the interview.`,
      review:    `🔍 **Code Review mode.**\n\nPaste your code and I'll give you:\n\n• **Correctness** — logic errors, edge cases\n• **Complexity** — Big-O time & space analysis\n• **Quality** — naming, structure, readability\n• **Improvements** — specific refactoring suggestions\n\nPaste your code to begin.`,
      roadmap:   `🗺️ **Career Roadmap mode.**\n\nTell me:\n1. Your current skill level (beginner / intermediate / advanced)\n2. Your target role (SDE, ML engineer, frontend, etc.)\n3. Your timeline (1 month / 3 months / 6 months)\n\nI'll build a personalized week-by-week study plan.`,
    };
    document.getElementById('aiMessages').innerHTML = '';
    _appendBotMessage(intros[m] || intros.chat);
  };

  const _updateModeUI = () => {
    const label = document.getElementById('aiModeLabel');
    const icons = { chat:'🤖', interview:'🎤', review:'🔍', roadmap:'🗺️' };
    const names = { chat:'AI Tutor', interview:'Interview Sim', review:'Code Review', roadmap:'Roadmap' };
    if (label) label.textContent = icons[mode] + ' ' + names[mode];
  };

  /* ── SUGGESTIONS ────────────────────────────────────────── */
  const _setupSuggestions = () => {
    document.getElementById('aiSuggestions')?.addEventListener('click', e => {
      const btn = e.target.closest('.ai-suggestion');
      if (!btn) return;
      const input = document.getElementById('aiInput');
      if (input) { input.value = btn.dataset.prompt; input.focus(); }
      _sendMessage();
    });
  };

  const _updateSuggestions = () => {
    const el = document.getElementById('aiSuggestions');
    if (!el) return;
    const suggestions = {
      chat: [
        { label: '📚 Study plan for DSA', prompt: 'Create a 30-day DSA study plan for SDE interviews' },
        { label: '💼 Resume tips', prompt: 'Review my resume strategy for FAANG applications' },
        { label: '🔥 Explain Binary Search', prompt: 'Explain binary search with a real-world analogy' },
        { label: '⚡ DP pattern guide', prompt: 'Teach me the most common dynamic programming patterns' },
      ],
      interview: [
        { label: '🎯 Start DSA round', prompt: 'Start a DSA interview round' },
        { label: '🏗️ System design', prompt: 'Give me a system design question' },
        { label: '🤝 Behavioral', prompt: 'Ask me a behavioral interview question' },
        { label: '✅ Feedback on answer', prompt: 'Give me feedback on my last answer' },
      ],
      review: [
        { label: '📊 Analyze complexity', prompt: 'Analyze the time and space complexity of my code' },
        { label: '🐛 Find bugs', prompt: 'Find any bugs or edge cases my code misses' },
        { label: '✨ Suggest improvements', prompt: 'How can I make this code cleaner and more Pythonic?' },
        { label: '🔄 Convert to optimal', prompt: 'Show me a more optimal version of this algorithm' },
      ],
      roadmap: [
        { label: '🚀 FAANG in 3 months', prompt: 'I want to get a FAANG SDE offer in 3 months, where do I start?' },
        { label: '🤖 ML engineer path', prompt: 'Create a 6-month roadmap to become an ML engineer' },
        { label: '🌐 Full stack path', prompt: 'What should I learn to become a full stack developer?' },
        { label: '📈 Senior SDE skills', prompt: 'What skills separate a junior SDE from a senior SDE?' },
      ],
    };
    const list = suggestions[mode] || suggestions.chat;
    el.innerHTML = list.map(s =>
      `<button class="ai-suggestion" data-prompt="${escHtml(s.prompt)}" title="${escHtml(s.prompt)}">${s.label}</button>`
    ).join('');
  };

  /* ── SEND MESSAGE ───────────────────────────────────────── */
  const _sendMessage = async () => {
    const input   = document.getElementById('aiInput');
    const text    = input?.value.trim();
    if (!text || isLoading) return;

    const lang    = document.getElementById('aiLang')?.value || 'en';
    const msgList = document.getElementById('aiMessages');
    const sugBox  = document.getElementById('aiSuggestions');

    messages.push({ role: 'user', content: text });
    _appendUserMessage(text);
    if (input) { input.value = ''; input.style.height = 'auto'; }
    if (sugBox) sugBox.style.display = 'none';

    const typing  = _appendTyping();
    isLoading     = true;
    document.getElementById('aiSend').disabled = true;

    // Build system context for current mode
    const systemExtra = _buildSystemContext(mode, text);

    try {
      if (!Auth.isLoggedIn()) {
        typing.remove();
        _appendBotMessage('Please **sign in** to chat with SkillBridge AI. I support English, Telugu (తెలుగు), Hindi (हिंदी), Tamil (தமிழ்), and Kannada (ಕನ್ನಡ)! 🌐');
        isLoading = false;
        document.getElementById('aiSend').disabled = false;
        return;
      }

      let reply = '';
      const replyEl = document.createElement('div');
      replyEl.className = 'ai-msg ai-msg--bot';
      replyEl.innerHTML = '<div class="ai-msg-content ai-streaming"></div>';
      const contentEl = replyEl.querySelector('.ai-msg-content');

      typing.remove();
      msgList.appendChild(replyEl);
      _scrollBottom();

      await API.ai.chat(
        { messages, language: lang, stream: true, mode, systemExtra },
        chunk => {
          reply += chunk;
          contentEl.innerHTML = _formatMarkdown(reply) + '<span class="ai-cursor">▋</span>';
          _scrollBottom();
        },
        () => {
          contentEl.innerHTML = _formatMarkdown(reply);
          contentEl.classList.remove('ai-streaming');
          messages.push({ role: 'assistant', content: reply });
          isLoading = false;
          document.getElementById('aiSend').disabled = false;
          _updateSuggestions();
          if (sugBox) { sugBox.style.display = 'flex'; }
          // Trim history to avoid context overflow
          if (messages.length > 20) messages = messages.slice(-16);
        }
      );
    } catch(e) {
      typing.remove();
      _appendBotMessage(`Connection issue. Please try again. (${e.message})`);
      isLoading = false;
      document.getElementById('aiSend').disabled = false;
    }
  };

  /* ── MESSAGE RENDERING ──────────────────────────────────── */
  const _appendUserMessage = (text) => {
    const msgList = document.getElementById('aiMessages');
    const el = document.createElement('div');
    el.className = 'ai-msg ai-msg--user';
    el.innerHTML = `<div class="ai-msg-content">${escHtml(text)}</div>`;
    msgList.appendChild(el);
    _scrollBottom();
  };

  const _appendBotMessage = (text) => {
    const msgList = document.getElementById('aiMessages');
    if (!msgList) return;
    const el = document.createElement('div');
    el.className = 'ai-msg ai-msg--bot';
    el.innerHTML = `<div class="ai-msg-content">${_formatMarkdown(text)}</div>`;
    msgList.appendChild(el);
    _scrollBottom();
  };

  const _appendTyping = () => {
    const msgList = document.getElementById('aiMessages');
    if (!msgList) return { remove: ()=>{} };
    const el = document.createElement('div');
    el.className = 'ai-msg ai-msg--bot';
    el.innerHTML = `<div class="ai-typing"><span></span><span></span><span></span></div>`;
    msgList.appendChild(el);
    _scrollBottom();
    return el;
  };

  const _scrollBottom = () => {
    const el = document.getElementById('aiMessages');
    if (el) el.scrollTop = el.scrollHeight;
  };

  const _focusInput = () => setTimeout(() => document.getElementById('aiInput')?.focus(), 80);

  /* ── MARKDOWN FORMATTER ─────────────────────────────────── */
  const _formatMarkdown = (text) => {
    return text
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) =>
        `<div style="position:relative;margin:0.6rem 0">
          <div style="display:flex;align-items:center;justify-content:space-between;padding:0.3rem 0.75rem;background:rgba(0,0,0,0.5);border-radius:6px 6px 0 0;border:1px solid rgba(255,255,255,0.06);border-bottom:none">
            <span style="font-size:0.68rem;font-weight:700;color:rgba(148,163,184,0.6);text-transform:uppercase;letter-spacing:0.06em">${lang||'code'}</span>
          </div>
          <pre style="margin:0;padding:0.75rem;background:rgba(0,0,0,0.45);border:1px solid rgba(255,255,255,0.06);border-radius:0 0 6px 6px;overflow-x:auto"><code style="font-family:var(--font-mono);font-size:0.8rem;color:#cdd6f4;line-height:1.7">${code.trim()}</code></pre>
        </div>`)
      .replace(/`([^`]+)`/g, '<code style="background:rgba(0,0,0,0.4);border:1px solid rgba(255,255,255,0.08);padding:1px 6px;border-radius:4px;font-family:var(--font-mono);font-size:0.83em;color:#93c5fd">$1</code>')
      .replace(/\*\*(.+?)\*\*/g, '<strong style="color:var(--text);font-weight:700">$1</strong>')
      .replace(/\*(.+?)\*/g, '<em style="color:var(--text-2)">$1</em>')
      .replace(/^### (.+)$/gm, '<div style="font-weight:800;font-size:0.9rem;color:var(--text);margin:0.75rem 0 0.35rem;font-family:var(--font-head)">$1</div>')
      .replace(/^## (.+)$/gm,  '<div style="font-weight:800;font-size:1rem;color:var(--text);margin:0.75rem 0 0.35rem;font-family:var(--font-head)">$1</div>')
      .replace(/^# (.+)$/gm,   '<div style="font-weight:800;font-size:1.1rem;color:var(--text);margin:0.75rem 0 0.35rem;font-family:var(--font-head)">$1</div>')
      .replace(/^[-•] (.+)$/gm,'<div style="display:flex;gap:0.5rem;margin:0.2rem 0"><span style="color:var(--blue-2);flex-shrink:0;margin-top:0.05rem">•</span><span>$1</span></div>')
      .replace(/^\d+\. (.+)$/gm,'<div style="margin:0.2rem 0;padding-left:1rem">$1</div>')
      .replace(/\n\n/g, '<div style="height:0.5rem"></div>')
      .replace(/\n/g, '<br>');
  };

  /* ── SYSTEM CONTEXT BUILDER ─────────────────────────────── */
  const _buildSystemContext = (mode, userText) => {
    const page = window.location.pathname;
    let ctx = '';
    if (page.includes('coding') && typeof Pages?.Coding?.currentProblem !== 'undefined') {
      const p = Pages.Coding.currentProblem;
      if (p) ctx += `Current problem: "${p.title}" (${p.difficulty}, ${p.category}). `;
    }
    if (mode === 'interview' && !interviewState.active) {
      interviewState.active = true;
      interviewState.round  = 1;
      ctx += ' You are now in INTERVIEW SIMULATOR mode. Act as a strict but fair technical interviewer. Ask one question at a time. Wait for the candidate to answer before proceeding. Give structured feedback after each answer.';
    }
    if (mode === 'review') {
      ctx += ' You are in CODE REVIEW mode. Focus exclusively on analyzing code quality, correctness, time complexity, space complexity, and specific improvement suggestions.';
    }
    if (mode === 'roadmap') {
      ctx += ' You are in ROADMAP mode. Create structured, actionable study plans with specific resources, timelines, and milestones.';
    }
    return ctx;
  };

  /* ── WELCOME MESSAGE ────────────────────────────────────── */
  const _welcomeMessage = () => {
    const user = Auth.getUser();
    const name = user?.full_name?.split(' ')[0] || 'there';
    return `Hey ${escHtml(name)}! 👋 I'm your **SkillBridge AI** — part tutor, part career coach.\n\nI can help you:\n\n• 💡 **Solve problems** — hints without spoilers (Socratic method)\n• 🎤 **Practice interviews** — realistic mock sessions\n• 🔍 **Review your code** — complexity, bugs, improvements\n• 🗺️ **Plan your career** — roadmaps, resources, timelines\n\nSwitch modes using the **🤖** button, or just ask me anything!`;
  };

  /* ── PUBLIC API ─────────────────────────────────────────── */
  const ask = (question) => {
    if (!isOpen) {
      isOpen = true;
      document.getElementById('aiPanel')?.classList.add('open');
    }
    const input = document.getElementById('aiInput');
    if (input) { input.value = question; _sendMessage(); }
  };

  const open = () => {
    if (!isOpen) {
      isOpen = true;
      document.getElementById('aiPanel')?.classList.add('open');
      _focusInput();
    }
  };

  /* ── INJECT STYLES ──────────────────────────────────────── */
  const _injectStyles = () => {
    const style = document.createElement('style');
    style.textContent = `
      .ai-cursor { animation: aiCursorBlink 0.7s step-end infinite; }
      @keyframes aiCursorBlink { 0%,100%{opacity:1} 50%{opacity:0} }
      .ai-suggestion {
        padding: 0.28rem 0.7rem;
        font-size: 0.75rem; font-weight: 600;
        background: var(--surface); border: 1px solid var(--border-2);
        border-radius: var(--r-full); cursor: pointer; color: var(--text-2);
        font-family: var(--font-body); transition: all var(--fast); white-space: nowrap;
        flex-shrink: 0;
      }
      .ai-suggestion:hover { background: var(--surface-2); border-color: var(--border-3); color: var(--text); }
      #aiModeMenu {
        position: absolute; bottom: calc(100% + 8px); right: 0;
        background: var(--surface-2); border: 1px solid var(--border-2);
        border-radius: var(--r-lg); padding: 0.35rem;
        min-width: 180px; box-shadow: var(--shadow-lg);
        display: none; z-index: 10;
      }
      .ai-mode-option {
        display: flex; align-items: center; gap: 0.6rem;
        padding: 0.55rem 0.85rem; border-radius: var(--r-sm);
        font-size: 0.855rem; font-weight: 500; color: var(--text-2);
        cursor: pointer; transition: all var(--fast);
        background: none; border: none; width: 100%;
        font-family: var(--font-body); text-align: left;
      }
      .ai-mode-option:hover { background: var(--surface-3); color: var(--text); }
    `;
    document.head.appendChild(style);
    // Init suggestions
    _updateSuggestions();
  };

  return { init, ask, open };
})();
