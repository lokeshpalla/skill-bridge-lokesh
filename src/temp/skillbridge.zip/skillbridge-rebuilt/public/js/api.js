// Global utilities (available to all scripts)
window.escHtml = (s) => String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');

// public/js/api.js — Centralized API client
const API = (() => {
  const BASE = '/api';

  const getToken  = () => localStorage.getItem('sb_token');
  const getRefresh = () => localStorage.getItem('sb_refresh_token');

  const buildHeaders = (extra = {}) => ({
    'Content-Type': 'application/json',
    ...(getToken() ? { Authorization: `Bearer ${getToken()}` } : {}),
    ...extra,
  });

  // ── Token refresh (called once automatically on 401) ────────
  let _refreshing = null; // deduplicate concurrent refresh calls
  const refreshTokens = async () => {
    if (_refreshing) return _refreshing;
    _refreshing = (async () => {
      const rt = getRefresh();
      if (!rt) return false;
      try {
        const res = await fetch(`${BASE}/auth/refresh`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ refreshToken: rt }),
        });
        if (!res.ok) return false;
        const data = await res.json();
        localStorage.setItem('sb_token', data.accessToken);
        localStorage.setItem('sb_refresh_token', data.refreshToken);
        return true;
      } catch {
        return false;
      } finally {
        _refreshing = null;
      }
    })();
    return _refreshing;
  };

  // ── Core fetch with automatic 1-retry after token refresh ───
  const apiFetch = async (url, options, retry = true) => {
    const res = await fetch(url, options);

    if (res.status === 401 && retry) {
      const ok = await refreshTokens();
      if (ok) {
        // Rebuild Authorization header with new token and retry once
        options.headers = { ...options.headers, Authorization: `Bearer ${getToken()}` };
        return apiFetch(url, options, false);
      } else {
        // Refresh failed — force logout
        localStorage.removeItem('sb_token');
        localStorage.removeItem('sb_refresh_token');
        if (typeof Auth !== 'undefined') Auth.setUser(null);
        if (typeof Router !== 'undefined') Router.navigate('/auth');
        throw new Error('Session expired. Please sign in again.');
      }
    }

    if (!res.ok) {
      let errMsg = `Request failed (${res.status})`;
      try {
        const body = await res.json();
        errMsg = body.error || body.message || errMsg;
      } catch {}
      throw new Error(errMsg);
    }

    // Return raw response for streaming endpoints
    const ct = res.headers.get('content-type') || '';
    if (ct.includes('text/event-stream')) return res;

    return res.json();
  };

  const get = (path, params = {}) => {
    const qs = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v !== undefined && v !== null)
    ).toString();
    const url = `${BASE}${path}${qs ? '?' + qs : ''}`;
    return apiFetch(url, { headers: buildHeaders() });
  };

  const post = (path, body = {}) =>
    apiFetch(`${BASE}${path}`, {
      method: 'POST',
      headers: buildHeaders(),
      body: JSON.stringify(body),
    });

  const put = (path, body = {}) =>
    apiFetch(`${BASE}${path}`, {
      method: 'PUT',
      headers: buildHeaders(),
      body: JSON.stringify(body),
    });

  const del = (path) =>
    apiFetch(`${BASE}${path}`, { method: 'DELETE', headers: buildHeaders() });

  // ── SSE streaming (AI chat) ──────────────────────────────────
  const stream = async (path, body, onChunk, onDone) => {
    const res = await fetch(`${BASE}${path}`, {
      method: 'POST',
      headers: buildHeaders(),
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      let msg = `AI request failed (${res.status})`;
      try { const d = await res.json(); msg = d.error || msg; } catch {}
      throw new Error(msg);
    }

    if (!res.body) throw new Error('Streaming not supported in this browser');

    const reader  = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop(); // keep incomplete last line
      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        const data = line.slice(6).trim();
        if (data === '[DONE]') { onDone?.(); return; }
        try {
          const parsed = JSON.parse(data);
          // OpenAI format
          const text = parsed.choices?.[0]?.delta?.content
            // Anthropic format
            ?? parsed.delta?.text
            ?? '';
          if (text) onChunk(text);
        } catch { /* skip malformed SSE */ }
      }
    }
    onDone?.();
  };

  // ── Public API surface ───────────────────────────────────────
  return {
    auth: {
      register:       (d)     => post('/auth/register', d),
      login:          (d)     => post('/auth/login', d),
      refresh:        (d)     => post('/auth/refresh', d),
      forgotPassword: (email) => post('/auth/forgot-password', { email }),
      resetPassword:  (d)     => post('/auth/reset-password', d),
      logout:         ()      => post('/auth/logout'),
      me:             ()      => get('/auth/me'),
    },
    users: {
      profile: (id) => get(`/users/${id || 'me'}`),
      update:  (d)  => put('/users/me', d),
    },
    courses: {
      list:        (p)  => get('/courses', p),
      get:         (id) => get(`/courses/${id}`),
      enroll:      (id) => post(`/courses/${id}/enroll`),
      enrollments: ()   => get('/courses/enrollments/me'),
    },
    coding: {
      problems:    (p)  => get('/coding/problems', p),
      problem:     (id) => get(`/coding/problems/${id}`),
      daily:       ()   => get('/coding/daily-challenge'),
      run:         (d)  => post('/coding/run', d),
      submit:      (d)  => post('/coding/submit', d),
      submissions: ()   => get('/coding/submissions'),
    },
    mentors: {
      list:     (p) => get('/mentors', p),
      book:     (d) => post('/mentors/book', d),
      bookings: ()  => get('/mentors/bookings/me'),
    },
    leaderboard: {
      list: (p) => get('/leaderboard', p),
    },
    internships: {
      list:    (p)  => get('/internships', p),
      apply:   (id) => post(`/internships/${id}/apply`),
      tracker: ()   => get('/internships/applications/me'),
    },
    portfolio: {
      get:    (userId) => get(`/portfolio/${userId || 'me'}`),
      update: (d)      => put('/portfolio/me', d),
    },
    ai: {
      chat:             (d, onChunk, onDone) => stream('/ai/chat', d, onChunk, onDone),
      analyzeCode:      (d)                  => post('/ai/analyze-code', d),
      generateResume:   (d)                  => post('/ai/generate-resume', d),
      matchInternships: (d)                  => post('/ai/match-internships', d),
    },
    analytics: {
      userProgress: (id) => get(`/analytics/user/${id}/progress`),
      platform:     ()   => get('/analytics/platform'),
    },
  };
})();

// ── Toast utility ────────────────────────────────────────────
window.showToast = (msg, type = 'info', duration = 3500) => {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  const icon = { success: '✓', error: '✕', info: 'ℹ' }[type] || '●';
  t.innerHTML = `<span style="font-size:1rem;flex-shrink:0">${icon}</span><span>${msg}</span>`;
  container.appendChild(t);
  setTimeout(() => t.remove(), duration);
};
