// app.js — Application bootstrap (loaded last)
// Pages namespace is set up here so all page scripts can populate it
window.Pages = window.Pages || {};

// Utility available to all pages
window.escHtml = function(s) {
  return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
};

document.addEventListener('DOMContentLoaded', async () => {
  // 1. Restore auth session from localStorage
  await Auth.restore();

  // 2. Boot navbar
  Navbar.init();

  // 3. Boot AI widget
  if (typeof AIAssistant !== 'undefined') AIAssistant.init();

  // 4. Register all routes
  Router.register('/',             () => Pages.Home.render());
  Router.register('/auth',         () => Pages.Auth.render());
  Router.register('/dashboard',    () => Pages.Dashboard.render());
  Router.register('/courses',      () => Pages.Courses.render());
  Router.register('/coding',       () => Pages.Coding.render());
  Router.register('/mentors',      () => Pages.Mentors.render());
  Router.register('/leaderboard',  () => Pages.Leaderboard.render());
  Router.register('/internships',  () => Pages.Internships.render());
  Router.register('/portfolio',    () => Pages.Portfolio.render());
  Router.register('/video/:roomCode', (p) => Pages.Video.render(p));

  // 5. Render the current URL
  Router.render(location.pathname);

  // 6. Show notification dot if logged in
  if (Auth.isLoggedIn()) {
    document.getElementById('notifDot')?.classList.add('show');
  }
});
