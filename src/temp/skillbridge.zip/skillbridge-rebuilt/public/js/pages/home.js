/* ─── HOME PAGE ───────────────────────────────────────────── */
Pages.Home = {
  render() {
    const app = document.getElementById('app');
    app.innerHTML = `
<div class="pt-page">

<!-- ═══════════════════════════ HERO ═══════════════════════════ -->
<section style="min-height:calc(100vh - 64px);display:flex;align-items:center;position:relative;overflow:hidden;padding:3rem 0">

  <!-- Background atmosphere -->
  <div style="position:absolute;inset:0;pointer-events:none">
    <div style="position:absolute;top:-20%;left:-10%;width:800px;height:800px;background:radial-gradient(circle,rgba(59,130,246,0.1) 0%,transparent 65%);animation:glowPulse 7s ease-in-out infinite"></div>
    <div style="position:absolute;bottom:-10%;right:-5%;width:700px;height:600px;background:radial-gradient(circle,rgba(139,92,246,0.09) 0%,transparent 65%);animation:glowPulse 9s 2s ease-in-out infinite"></div>
    <!-- Grid -->
    <div style="position:absolute;inset:0;background-image:linear-gradient(var(--border) 1px,transparent 1px),linear-gradient(90deg,var(--border) 1px,transparent 1px);background-size:72px 72px;mask-image:radial-gradient(ellipse at 50% 50%,black 20%,transparent 70%);opacity:0.6"></div>
  </div>

  <div class="container" style="position:relative;z-index:1">
    <div style="display:grid;grid-template-columns:1.1fr 0.9fr;gap:4rem;align-items:center">

      <!-- Left -->
      <div>
        <div class="fade-up" style="display:inline-flex;align-items:center;gap:0.6rem;padding:0.35rem 1rem;background:rgba(59,130,246,0.08);border:1px solid rgba(59,130,246,0.18);border-radius:var(--r-full);font-size:0.75rem;font-weight:700;letter-spacing:0.07em;text-transform:uppercase;color:var(--blue-2);margin-bottom:1.75rem">
          <span style="width:6px;height:6px;border-radius:50%;background:var(--blue);box-shadow:0 0 8px var(--blue)"></span>
          India's #1 AI-Powered Career Platform
        </div>

        <h1 class="fade-up-1" style="margin-bottom:1.25rem">
          Learn. Build.<br><span class="text-grad">Get Hired.</span>
        </h1>

        <p class="fade-up-2" style="font-size:1.1rem;max-width:480px;margin-bottom:2.25rem;line-height:1.8;color:var(--text-2)">
          The complete platform combining <span style="color:var(--text);font-weight:600">AI tutoring</span>, expert mentors,
          competitive coding, and placement support — built for India's next generation engineers.
        </p>

        <div class="fade-up-3" style="display:flex;gap:0.875rem;flex-wrap:wrap;margin-bottom:3rem">
          <a href="/auth" class="btn-primary btn-xl" onclick="Router.navigate('/auth');return false">
            Start for Free
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
          </a>
          <a href="/mentors" class="btn-ghost btn-xl" onclick="Router.navigate('/mentors');return false">
            Meet Mentors
          </a>
        </div>

        <!-- Social proof -->
        <div class="fade-up-4" style="display:flex;align-items:center;gap:1.5rem;flex-wrap:wrap">
          <div style="display:flex">
            ${['photo-1494790108377-be9c29b29330','photo-1507003211169-0a1dd7228f2d','photo-1438761681033-6461ffad8d80','photo-1472099645785-5658abf4ff4e'].map((p,i)=>`
            <img src="https://images.unsplash.com/${p}?w=40&h=40&fit=crop&crop=face" style="width:30px;height:30px;border-radius:50%;border:2px solid var(--bg);object-fit:cover;${i?'margin-left:-8px':''}"/>`).join('')}
          </div>
          <div>
            <div style="display:flex;gap:1px;margin-bottom:2px">${'★'.repeat(5).split('').map(()=>`<span style="color:var(--amber-2);font-size:0.8rem">★</span>`).join('')}</div>
            <div style="font-size:0.8rem;color:var(--text-2)"><b style="color:var(--text)">50,000+</b> learners · <b style="color:var(--emerald-2)">92% placement</b></div>
          </div>
        </div>
      </div>

      <!-- Right: UI preview -->
      <div class="fade-up-2" style="position:relative;padding:1rem">
        <!-- Main dashboard card -->
        <div style="background:var(--surface);border:1px solid var(--border-2);border-radius:var(--r-2xl);padding:1.5rem;box-shadow:var(--shadow-xl),var(--glow-blue);animation:float 6s ease-in-out infinite">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem">
            <div>
              <div style="font-family:var(--font-head);font-weight:700;margin-bottom:0.2rem">Your Progress</div>
              <div style="font-size:0.78rem;color:var(--text-3)">Week 8 · Full Stack Track</div>
            </div>
            <span class="badge badge-green">On Track</span>
          </div>
          ${[['React & TypeScript','88%'],['System Design','62%'],['Node.js APIs','74%']].map(([n,p],i)=>`
          <div style="margin-bottom:${i<2?'1rem':'0'}">
            <div style="display:flex;justify-content:space-between;font-size:0.83rem;margin-bottom:0.4rem">
              <span style="font-weight:500;color:var(--text)">${n}</span>
              <span style="color:var(--blue-2);font-weight:700">${p}</span>
            </div>
            <div class="progress-bar"><div class="progress-fill" style="width:${p}"></div></div>
          </div>`).join('')}
        </div>

        <!-- Floating AI card -->
        <div style="position:absolute;bottom:-20px;left:-30px;background:var(--surface-2);border:1px solid rgba(139,92,246,0.3);border-radius:var(--r-xl);padding:0.875rem 1.1rem;box-shadow:var(--shadow-lg),var(--glow-violet);max-width:210px;animation:float 8s 1.5s ease-in-out infinite;z-index:2">
          <div style="display:flex;align-items:center;gap:0.5rem;margin-bottom:0.4rem">
            <div style="width:7px;height:7px;border-radius:50%;background:var(--violet-2);box-shadow:0 0 8px var(--violet)"></div>
            <span style="font-size:0.68rem;font-weight:800;color:var(--violet-2);letter-spacing:0.06em">AI TUTOR</span>
          </div>
          <p style="font-size:0.78rem;color:var(--text-2);margin:0;line-height:1.5">What's the time complexity of your solution? Think about it step by step 🤔</p>
        </div>

        <!-- Floating XP card -->
        <div style="position:absolute;top:-16px;right:-16px;background:var(--surface-2);border:1px solid rgba(16,185,129,0.25);border-radius:var(--r-lg);padding:0.875rem 1.1rem;box-shadow:var(--shadow-md);animation:float 7s 0.8s ease-in-out infinite">
          <div style="font-size:0.72rem;color:var(--text-3);margin-bottom:0.25rem">This week</div>
          <div style="font-family:var(--font-head);font-size:1.4rem;font-weight:800;color:var(--emerald-2)">+2,840 XP</div>
          <div style="font-size:0.72rem;color:var(--emerald);margin-top:0.1rem">↑ 34% vs last week</div>
        </div>
      </div>
    </div>

    <!-- Stats row -->
    <div class="fade-up-5" style="display:grid;grid-template-columns:repeat(4,1fr);gap:1px;background:var(--border);border-radius:var(--r-xl);overflow:hidden;margin-top:4.5rem;border:1px solid var(--border)">
      ${[['50K+','Active Learners','👥'],['500+','Expert Mentors','🎓'],['2M+','Problems Solved','💻'],['92%','Placement Rate','🚀']].map(([v,l,e])=>`
      <div style="background:var(--surface);padding:1.5rem 2rem;text-align:center;transition:background var(--fast)" onmouseover="this.style.background='var(--surface-2)'" onmouseout="this.style.background='var(--surface)'">
        <div style="font-size:1.4rem;margin-bottom:0.5rem">${e}</div>
        <div class="text-grad" style="font-family:var(--font-head);font-size:1.9rem;font-weight:800;line-height:1">${v}</div>
        <div style="font-size:0.77rem;color:var(--text-3);margin-top:0.35rem;font-weight:600;letter-spacing:0.02em">${l}</div>
      </div>`).join('')}
    </div>
  </div>
</section>

<!-- ═══════════════════════════ FEATURES ════════════════════════ -->
<section class="section" id="features" style="background:linear-gradient(180deg,var(--bg) 0%,var(--bg-1) 50%,var(--bg) 100%)">
  <div class="container">
    <div style="text-align:center;margin-bottom:4rem">
      <div class="section-badge section-badge-blue">Platform</div>
      <h2 style="margin-top:0.6rem">Everything from learning<br>to <span class="text-grad">landing the offer</span></h2>
      <p style="margin-top:1rem;max-width:480px;margin-left:auto;margin-right:auto">Not just courses. A complete career engine with AI, mentors, coding practice, and job placement.</p>
    </div>

    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:1px;background:var(--border);border-radius:var(--r-2xl);overflow:hidden;border:1px solid var(--border)">
      ${[
        {icon:'🤖',accent:'blue',  label:'5 Languages',     title:'AI Tutor That Actually Teaches', desc:'Multilingual AI in English, Telugu, Hindi, Tamil & Kannada. Uses Socratic method — never just gives the answer.'},
        {icon:'👥',accent:'violet',label:'500+ Mentors',    title:'1:1 Sessions With Actual Engineers', desc:'Book hours with engineers at Google, Microsoft, Flipkart, Razorpay. Real interviews, real feedback.'},
        {icon:'💻',accent:'cyan',  label:'2000+ Problems',  title:'LeetCode-Style Coding Arena', desc:'Curated DSA, algorithms & system design with AI hints, complexity badges, and community solutions.'},
        {icon:'🔥',accent:'orange',label:'Daily Rewards',   title:'Gamified Streaks & Leaderboard', desc:'XP, badges, daily challenges, weekly contests. Habit-forming design backed by behavioral science.'},
        {icon:'💼',accent:'green', label:'1000+ Listings',  title:'AI-Matched Internships', desc:'ML matching to GSoC, MLH, LFX and 1000+ company programs. Tracks status, auto-fills applications.'},
        {icon:'📄',accent:'violet',label:'ATS-Optimized',   title:'Portfolio & Resume Builder', desc:'Auto-generates your portfolio from solved problems. One-click ATS resume scores 95%+ on parsers.'},
      ].map(f=>`
      <div style="background:var(--surface);padding:2rem 1.75rem;position:relative;overflow:hidden;transition:background var(--fast)" onmouseover="this.style.background='var(--surface-2)'" onmouseout="this.style.background='var(--surface)'">
        <div style="position:absolute;top:0;right:0;width:140px;height:140px;background:radial-gradient(circle at top right,${{blue:'rgba(59,130,246,0.07)',violet:'rgba(139,92,246,0.07)',cyan:'rgba(6,182,212,0.07)',orange:'rgba(249,115,22,0.07)',green:'rgba(16,185,129,0.07)'}[f.accent]} 0%,transparent 70%);pointer-events:none"></div>
        <div style="font-size:1.75rem;margin-bottom:1rem">${f.icon}</div>
        <div style="font-size:0.7rem;font-weight:800;letter-spacing:0.08em;text-transform:uppercase;color:${{blue:'var(--blue-2)',violet:'var(--violet-2)',cyan:'var(--cyan-2)',orange:'#fb923c',green:'var(--emerald-2)'}[f.accent]};margin-bottom:0.6rem">${f.label}</div>
        <h4 style="margin-bottom:0.6rem;font-size:1rem;line-height:1.3">${f.title}</h4>
        <p style="font-size:0.875rem;line-height:1.7;margin:0">${f.desc}</p>
      </div>`).join('')}
    </div>
  </div>
</section>

<!-- ═════════════════════ HOW IT WORKS ══════════════════════════ -->
<section class="section">
  <div class="container">
    <div style="text-align:center;margin-bottom:4rem">
      <div class="section-badge section-badge-violet">Process</div>
      <h2 style="margin-top:0.6rem">From zero to <span class="text-grad">job-ready</span><br>in 90 days</h2>
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:2rem;position:relative">
      <div style="position:absolute;top:28px;left:20%;right:20%;height:1px;background:linear-gradient(90deg,transparent,var(--border-3),transparent)"></div>
      ${[
        {n:'01',icon:'🎯',title:'Set Your Goal',desc:'Tell AI your target role — FAANG, startup, freelancer. Get a personalized 90-day roadmap generated in seconds.',color:'blue'},
        {n:'02',icon:'⚡',title:'Learn & Practice',desc:'AI tutor + mentor sessions + daily coding + live projects. Every day tracked and adapted to your pace.',color:'violet'},
        {n:'03',icon:'🚀',title:'Get Placed',desc:'Auto-matched internships, AI-polished resume, mock interviews. Placement support until you get the offer.',color:'green'},
      ].map(s=>`
      <div style="text-align:center;position:relative;z-index:1">
        <div style="width:56px;height:56px;border-radius:50%;background:${{blue:'rgba(59,130,246,0.1)',violet:'rgba(139,92,246,0.1)',green:'rgba(16,185,129,0.1)'}[s.color]};border:1px solid ${{blue:'rgba(59,130,246,0.2)',violet:'rgba(139,92,246,0.2)',green:'rgba(16,185,129,0.2)'}[s.color]};display:grid;place-items:center;margin:0 auto 1.5rem;font-size:1.4rem;background:var(--bg)">
          <span>${s.icon}</span>
        </div>
        <div style="font-family:var(--font-mono);font-size:0.68rem;color:var(--text-4);margin-bottom:0.5rem;letter-spacing:0.06em">${s.n}</div>
        <h4 style="margin-bottom:0.75rem;font-size:1.05rem">${s.title}</h4>
        <p style="font-size:0.875rem;line-height:1.75">${s.desc}</p>
      </div>`).join('')}
    </div>
  </div>
</section>

<!-- ════════════════════════ MENTORS ════════════════════════════ -->
<section class="section" style="background:var(--bg-1)">
  <div class="container">
    <div style="display:flex;align-items:flex-end;justify-content:space-between;flex-wrap:wrap;gap:1.5rem;margin-bottom:3rem">
      <div>
        <div class="section-badge section-badge-violet">Mentors</div>
        <h2 style="margin-top:0.6rem">Learn from engineers at<br><span class="text-grad">world-class companies</span></h2>
      </div>
      <a href="/mentors" class="btn-outline" onclick="Router.navigate('/mentors');return false">Browse 500+ Mentors →</a>
    </div>
    <div class="grid-3">${this._mentorCards()}</div>
  </div>
</section>

<!-- ═══════════════════ TESTIMONIALS ════════════════════════════ -->
<section class="section">
  <div class="container">
    <div style="text-align:center;margin-bottom:3.5rem">
      <div class="section-badge section-badge-green">Results</div>
      <h2 style="margin-top:0.6rem">Real learners, <span class="text-grad">real results</span></h2>
    </div>
    <div class="grid-3">
      ${[
        {name:'Priya Sharma',company:'Google',role:'SDE II',img:'photo-1494790108377-be9c29b29330',text:'The AI tutor explained dynamic programming in Telugu and suddenly everything clicked. Got my Google offer 4 months after joining.',xp:'15,400',problems:'312'},
        {name:'Arjun Reddy',company:'Razorpay',role:'Backend Engineer',img:'photo-1507003211169-0a1dd7228f2d',text:'8 mock interview sessions with my Flipkart mentor. I failed the first 3. Passed the next 5. Razorpay offer in hand 2 weeks later.',xp:'22,800',problems:'541'},
        {name:'Kavitha Nair',company:'Microsoft',role:'ML Engineer',img:'photo-1438761681033-6461ffad8d80',text:'The internship matching found me a GSoC project that turned into a PPO at Microsoft. The AI resume builder hit 97% ATS score.',xp:'18,200',problems:'428'},
      ].map(t=>`
      <div class="card-glow" style="display:flex;flex-direction:column;gap:1.1rem">
        <div style="display:flex;gap:2px">${'★'.repeat(5).split('').map(()=>`<span style="color:var(--amber-2);font-size:0.88rem">★</span>`).join('')}</div>
        <p style="font-size:0.875rem;line-height:1.8;font-style:italic;color:var(--text-2);margin:0;flex:1">"${t.text}"</p>
        <div style="display:flex;align-items:center;gap:0.875rem;padding-top:1rem;border-top:1px solid var(--border)">
          <img src="https://images.unsplash.com/${t.img}?w=60&h=60&fit=crop&crop=face" style="width:38px;height:38px;border-radius:50%;object-fit:cover;border:2px solid var(--border-2);flex-shrink:0"/>
          <div style="flex:1;min-width:0">
            <div style="font-weight:700;font-size:0.875rem">${t.name}</div>
            <div style="font-size:0.75rem;color:var(--blue-2)">${t.role} @ ${t.company}</div>
          </div>
          <div style="text-align:right;flex-shrink:0">
            <div style="font-size:0.72rem;color:var(--text-3)">${t.xp} XP</div>
            <div style="font-size:0.72rem;color:var(--text-3)">${t.problems} solved</div>
          </div>
        </div>
      </div>`).join('')}
    </div>
  </div>
</section>

<!-- ════════════════════ COMPANIES BANNER ═══════════════════════ -->
<div style="border-top:1px solid var(--border);border-bottom:1px solid var(--border);padding:2.5rem 0;background:var(--bg-1)">
  <div class="container" style="text-align:center">
    <p style="font-size:0.72rem;font-weight:800;letter-spacing:0.1em;text-transform:uppercase;color:var(--text-4);margin-bottom:2rem">OUR LEARNERS WORK AT</p>
    <div style="display:flex;align-items:center;justify-content:center;gap:2.5rem;flex-wrap:wrap">
      ${['Google','Microsoft','Amazon','Flipkart','Razorpay','Swiggy','Atlassian','PhonePe'].map(c=>`
      <span style="font-family:var(--font-head);font-size:1rem;font-weight:800;color:var(--text-4);letter-spacing:-0.02em;transition:color var(--mid);cursor:default" onmouseover="this.style.color='var(--text)'" onmouseout="this.style.color='var(--text-4)'">${c}</span>`).join('')}
    </div>
  </div>
</div>

<!-- ═══════════════════════════ CTA ═════════════════════════════ -->
<section class="section" style="position:relative;overflow:hidden">
  <div style="position:absolute;inset:0;background:radial-gradient(ellipse at 50% 50%,rgba(59,130,246,0.07) 0%,transparent 65%);pointer-events:none"></div>
  <div class="container-xs" style="text-align:center;position:relative;z-index:1">
    <div class="section-badge section-badge-blue" style="margin-bottom:1.25rem">Free Forever Plan Available</div>
    <h2 style="margin-bottom:1.1rem">Your dream job is<br><span class="text-grad">90 days away.</span></h2>
    <p style="font-size:1.05rem;margin-bottom:2.5rem;max-width:400px;margin-left:auto;margin-right:auto">Join 50,000+ learners already on their path to top tech companies.</p>
    <div style="display:flex;gap:0.875rem;justify-content:center;flex-wrap:wrap;margin-bottom:1.5rem">
      <a href="/auth" class="btn-primary btn-xl" onclick="Router.navigate('/auth');return false">Create Free Account</a>
      <a href="/mentors" class="btn-ghost btn-xl" onclick="Router.navigate('/mentors');return false">Book a Demo</a>
    </div>
    <p style="font-size:0.77rem;color:var(--text-4)">✓ No credit card &nbsp;·&nbsp; ✓ Cancel anytime &nbsp;·&nbsp; ✓ Free tier forever</p>
  </div>
</section>

<!-- ═══════════════════════ FOOTER ══════════════════════════════ -->
<footer style="border-top:1px solid var(--border);padding:3.5rem 0 2rem">
  <div class="container">
    <div style="display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:3rem;margin-bottom:2.5rem">
      <div>
        <div style="display:flex;align-items:center;gap:0.55rem;margin-bottom:1rem">
          <img src="/assets/logo.svg" width="28" height="28" style="filter:drop-shadow(0 0 8px rgba(59,130,246,0.5))"/>
          <span style="font-family:var(--font-head);font-weight:800;font-size:1.05rem">Skill<em style="font-style:normal;background:var(--grad-brand);-webkit-background-clip:text;-webkit-text-fill-color:transparent">Bridge</em></span>
        </div>
        <p style="font-size:0.875rem;max-width:260px;line-height:1.8;margin-bottom:1.5rem">AI-powered career platform built for India's next generation of software engineers.</p>
        <div style="display:flex;gap:0.6rem">
          ${['𝕏','in','gh'].map(s=>`<a href="#" style="width:32px;height:32px;background:var(--surface);border:1px solid var(--border);border-radius:var(--r-sm);display:grid;place-items:center;font-size:0.78rem;color:var(--text-3);text-decoration:none;transition:all var(--fast)" onmouseover="this.style.borderColor='var(--border-2)';this.style.color='var(--text-2)'" onmouseout="this.style.borderColor='var(--border)';this.style.color='var(--text-3)'">${s}</a>`).join('')}
        </div>
      </div>
      ${[
        {h:'Platform', links:['Dashboard','Courses','Coding Arena','Mentors','Leaderboard']},
        {h:'Career',   links:['Internships','Portfolio','Resume Builder','Mock Interviews','Certifications']},
        {h:'Company',  links:['About','Blog','Careers','Privacy Policy','Terms of Service']},
      ].map(col=>`
      <div>
        <div style="font-weight:800;font-size:0.78rem;letter-spacing:0.07em;text-transform:uppercase;color:var(--text-3);margin-bottom:1.1rem">${col.h}</div>
        <div style="display:flex;flex-direction:column;gap:0.6rem">
          ${col.links.map(l=>`<a href="#" style="font-size:0.855rem;color:var(--text-3);text-decoration:none;font-weight:500;transition:color var(--fast)" onmouseover="this.style.color='var(--text-2)'" onmouseout="this.style.color='var(--text-3)'">${l}</a>`).join('')}
        </div>
      </div>`).join('')}
    </div>
    <div style="border-top:1px solid var(--border);padding-top:1.5rem;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem">
      <p style="font-size:0.78rem;margin:0;color:var(--text-4)">© 2026 SkillBridge Technologies Pvt. Ltd. · Made with ❤️ in Hyderabad</p>
      <p style="font-size:0.78rem;margin:0;color:var(--text-4)">CIN: U72900TG2026PTC123456</p>
    </div>
  </div>
</footer>
</div>`;
  },

  _mentorCards() {
    return [
      {name:'Sarah Chen',title:'Senior SWE @ Google',skills:['System Design','React','DSA'],rating:4.9,sessions:347,img:'photo-1494790108377-be9c29b29330',rate:'₹3,500'},
      {name:'Raj Patel',title:'AI/ML Lead @ Microsoft',skills:['Python','LLMs','MLOps'],rating:4.8,sessions:291,img:'photo-1507003211169-0a1dd7228f2d',rate:'₹3,200'},
      {name:'Prachi Gupta',title:'Staff Engineer @ Amazon',skills:['AWS','Node.js','DevOps'],rating:4.9,sessions:419,img:'photo-1438761681033-6461ffad8d80',rate:'₹3,800'},
    ].map(m=>`
    <div class="mentor-card">
      <div style="display:flex;align-items:center;gap:0.875rem">
        <img src="https://images.unsplash.com/${m.img}?w=80&h=80&fit=crop&crop=face" class="mentor-avatar"/>
        <div style="flex:1;min-width:0">
          <div style="font-weight:700;color:var(--text);font-size:0.95rem">${m.name}</div>
          <div style="font-size:0.78rem;color:var(--text-3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${m.title}</div>
          <div style="display:flex;align-items:center;gap:0.5rem;margin-top:0.3rem">
            <span class="mentor-stars">★ ${m.rating}</span>
            <span style="color:var(--text-4);font-size:0.72rem">${m.sessions} sessions</span>
          </div>
        </div>
        <div style="text-align:right;flex-shrink:0">
          <div style="font-family:var(--font-head);font-weight:800;color:var(--blue-2);font-size:1rem">${m.rate}</div>
          <div style="font-size:0.68rem;color:var(--text-3)">/session</div>
        </div>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:0.35rem">
        ${m.skills.map(s=>`<span class="skill-pill">${s}</span>`).join('')}
      </div>
      <button class="btn-primary btn-sm" style="width:100%;justify-content:center" onclick="Router.navigate('/mentors')">Book Session →</button>
    </div>`).join('');
  }
};
