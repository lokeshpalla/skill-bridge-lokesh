// ── AUTH PAGE ─────────────────────────────────────────────────
Pages.Auth = {
  mode: 'login',

  render() {
    // Redirect if already logged in
    if (Auth.isLoggedIn()) { Router.navigate('/dashboard'); return; }

    const app = document.getElementById('app');
    app.innerHTML = `
    <div class="pt-page" style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:2rem;position:relative">
      <div style="position:absolute;inset:0;background:radial-gradient(ellipse at 50% 30%,rgba(0,212,255,0.06) 0%,transparent 70%);pointer-events:none"></div>

      <div style="width:100%;max-width:440px;position:relative;z-index:1">
        <!-- Logo -->
        <div style="text-align:center;margin-bottom:1.75rem">
          <div style="display:inline-flex;align-items:center;gap:0.6rem;margin-bottom:0.5rem">
            <img src="/assets/logo.svg" width="42" height="42" style="filter:drop-shadow(0 0 8px rgba(0,212,255,0.5))"/>
            <span style="font-family:var(--font-head);font-size:1.4rem;font-weight:700">Skill<em style="font-style:normal;background:var(--grad-brand);-webkit-background-clip:text;-webkit-text-fill-color:transparent">Bridge</em></span>
          </div>
          <p style="font-size:0.875rem;color:var(--text-2)">Your gateway to career acceleration</p>
        </div>

        <div class="auth-card">
          <!-- Tabs -->
          <div class="tabs" style="width:100%;margin-bottom:1.75rem" id="authTabs">
            <button class="tab active" id="tabLogin"  onclick="Pages.Auth.setMode('login')">Sign In</button>
            <button class="tab"        id="tabSignup" onclick="Pages.Auth.setMode('signup')">Sign Up</button>
          </div>

          <!-- Error banner -->
          <div id="authError" style="display:none;margin-bottom:1rem;padding:0.75rem 1rem;background:rgba(255,80,80,0.1);border:1px solid rgba(255,80,80,0.25);border-radius:var(--r);font-size:0.875rem;color:#ff8080;line-height:1.5"></div>

          <!-- LOGIN FORM -->
          <form id="loginForm" novalidate>
            <div class="field">
              <label class="label" for="loginEmail">Email</label>
              <input class="input" type="email" id="loginEmail" autocomplete="email" placeholder="you@example.com" required />
            </div>
            <div class="field" style="margin-top:1rem">
              <label class="label" for="loginPassword">Password</label>
              <input class="input" type="password" id="loginPassword" autocomplete="current-password" placeholder="••••••••" required />
            </div>
            <div style="text-align:right;margin-top:0.5rem;margin-bottom:1.25rem">
              <button type="button" style="background:none;border:none;font-size:0.82rem;color:var(--text-2);cursor:pointer;font-family:var(--font-body)" onclick="Pages.Auth.setMode('forgot')">Forgot password?</button>
            </div>
            <button type="submit" class="btn-primary" style="width:100%;justify-content:center" id="loginBtn">Sign In</button>
          </form>

          <!-- SIGNUP FORM -->
          <form id="signupForm" style="display:none" novalidate>
            <div class="field">
              <label class="label" for="signupName">Full Name</label>
              <input class="input" type="text" id="signupName" autocomplete="name" placeholder="Your name" />
            </div>
            <div class="field" style="margin-top:1rem">
              <label class="label" for="signupEmail">Email</label>
              <input class="input" type="email" id="signupEmail" autocomplete="email" placeholder="you@example.com" required />
            </div>
            <div class="field" style="margin-top:1rem">
              <label class="label" for="signupPassword">Password</label>
              <input class="input" type="password" id="signupPassword" autocomplete="new-password" placeholder="At least 6 characters" required />
            </div>
            <button type="submit" class="btn-primary" style="width:100%;justify-content:center;margin-top:1.5rem" id="signupBtn">Create Account</button>
          </form>

          <!-- FORGOT PASSWORD FORM -->
          <form id="forgotForm" style="display:none" novalidate>
            <p style="font-size:0.875rem;color:var(--text-2);margin-bottom:1.25rem">Enter your email and we'll send a reset link.</p>
            <div class="field">
              <label class="label" for="forgotEmail">Email</label>
              <input class="input" type="email" id="forgotEmail" autocomplete="email" placeholder="you@example.com" required />
            </div>
            <button type="submit" class="btn-primary" style="width:100%;justify-content:center;margin-top:1.5rem" id="forgotBtn">Send Reset Link</button>
            <button type="button" class="btn-ghost" style="width:100%;justify-content:center;margin-top:0.5rem" onclick="Pages.Auth.setMode('login')">← Back to Sign In</button>
          </form>
        </div>
      </div>
    </div>`;

    this.mode = 'login';
    this._setupHandlers();
  },

  setMode(mode) {
    this.mode = mode;
    // Hide all forms
    ['loginForm', 'signupForm', 'forgotForm'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.display = 'none';
    });
    // Show the right form
    const formMap = { login: 'loginForm', signup: 'signupForm', forgot: 'forgotForm' };
    const activeForm = document.getElementById(formMap[mode]);
    if (activeForm) activeForm.style.display = 'block';
    // Update tabs
    document.getElementById('tabLogin')?.classList.toggle('active', mode === 'login');
    document.getElementById('tabSignup')?.classList.toggle('active', mode === 'signup');
    // Show/hide tabs row (hide for forgot)
    const tabs = document.getElementById('authTabs');
    if (tabs) tabs.style.display = mode === 'forgot' ? 'none' : 'flex';
    // Clear error
    this._clearError();
    // Focus first input
    setTimeout(() => activeForm?.querySelector('input')?.focus(), 50);
  },

  _setupHandlers() {
    // Login
    document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email    = document.getElementById('loginEmail').value.trim();
      const password = document.getElementById('loginPassword').value;
      if (!email || !password) return this._showError('Please enter your email and password.');

      const btn = document.getElementById('loginBtn');
      this._setLoading(btn, 'Signing in...');
      this._clearError();

      try {
        await Auth.login({ email, password });
        showToast('Welcome back! 🎉', 'success');
        Router.navigate('/dashboard');
      } catch (err) {
        this._showError(err.message);
        this._setLoading(btn, null, 'Sign In');
      }
    });

    // Sign up
    document.getElementById('signupForm')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const full_name = document.getElementById('signupName').value.trim();
      const email     = document.getElementById('signupEmail').value.trim();
      const password  = document.getElementById('signupPassword').value;
      if (!email || !password) return this._showError('Email and password are required.');
      if (password.length < 6) return this._showError('Password must be at least 6 characters.');

      const btn = document.getElementById('signupBtn');
      this._setLoading(btn, 'Creating account...');
      this._clearError();

      try {
        await Auth.register({ email, password, full_name });
        showToast('Welcome to SkillBridge! 🚀', 'success');
        Router.navigate('/dashboard');
      } catch (err) {
        this._showError(err.message);
        this._setLoading(btn, null, 'Create Account');
      }
    });

    // Forgot password
    document.getElementById('forgotForm')?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('forgotEmail').value.trim();
      if (!email) return this._showError('Please enter your email address.');

      const btn = document.getElementById('forgotBtn');
      this._setLoading(btn, 'Sending...');
      this._clearError();

      try {
        await API.auth.forgotPassword(email);
        showToast('Reset link sent! Check your inbox.', 'success');
        this.setMode('login');
      } catch (err) {
        this._showError(err.message);
        this._setLoading(btn, null, 'Send Reset Link');
      }
    });
  },

  _showError(msg) {
    const el = document.getElementById('authError');
    if (!el) return;
    el.textContent = msg;
    el.style.display = 'block';
  },

  _clearError() {
    const el = document.getElementById('authError');
    if (el) el.style.display = 'none';
  },

  _setLoading(btn, loadingText, resetText) {
    if (!btn) return;
    if (loadingText) {
      btn.disabled = true;
      btn.textContent = loadingText;
    } else {
      btn.disabled = false;
      btn.textContent = resetText || 'Submit';
    }
  }
};

// ── DASHBOARD ─────────────────────────────────────────────────
Pages.Dashboard = {
  async render() {
    if (!Auth.isLoggedIn()) { Router.navigate('/auth'); return; }
    const user = Auth.getUser();
    const app  = document.getElementById('app');

    app.innerHTML = `
    <div class="pt-page" style="min-height:100vh">
      <div class="container" style="padding-top:2rem;padding-bottom:4rem">

        <!-- Welcome bar -->
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1.5rem;margin-bottom:2rem">
          <div>
            <h1 style="font-size:2rem;margin-bottom:0.3rem">Welcome back, <span class="text-grad">${escHtml(user.full_name?.split(' ')[0] || 'Learner')}!</span></h1>
            <p>You're on a <strong style="color:var(--orange)">${user.streak_days || 0}-day streak</strong> · Keep it up! 🔥</p>
          </div>
          <div style="display:flex;gap:0.5rem;align-items:center;padding:0.75rem 1.25rem;background:rgba(255,123,53,0.08);border:1px solid rgba(255,123,53,0.2);border-radius:var(--r-xl)">
            <span style="font-size:1.8rem">🔥</span>
            <div>
              <div style="font-family:var(--font-head);font-size:1.4rem;font-weight:700;color:var(--orange)">${user.streak_days || 0}</div>
              <div style="font-size:0.75rem;color:var(--text-2)">Day Streak</div>
            </div>
          </div>
        </div>

        <!-- Stats -->
        <div class="grid-4" style="margin-bottom:2rem">
          ${[
            ['🔥', user.streak_days || 0,           'Day Streak',      'stat-icon-orange'],
            ['⚡', (user.total_xp || 0).toLocaleString(), 'Total XP', 'stat-icon-cyan'],
            ['💻', user.problems_solved || 0,        'Problems Solved', 'stat-icon-green'],
            ['🏆', '#—',                              'Global Rank',    'stat-icon-yellow'],
          ].map(([icon, val, label, cls]) => `
          <div class="stat-card">
            <div class="stat-icon ${cls}" style="font-size:1.2rem">${icon}</div>
            <div><div class="stat-value">${val}</div><div class="stat-label">${label}</div></div>
          </div>`).join('')}
        </div>

        <!-- Two-column layout -->
        <div style="display:grid;grid-template-columns:1fr 360px;gap:1.5rem;align-items:start">
          <div style="display:flex;flex-direction:column;gap:1.5rem">

            <!-- Recent challenges -->
            <div class="card-glow">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.25rem">
                <h3 style="font-size:1.05rem;color:var(--text)">Recent Challenges <span class="badge badge-orange" style="font-size:0.7rem">+50 XP bonus</span></h3>
                <a href="/coding" class="btn-ghost btn-sm" onclick="Router.navigate('/coding');return false">View All →</a>
              </div>
              <div id="dashChallenges">
                <div class="skeleton" style="height:52px;border-radius:var(--r-lg);margin-bottom:0.5rem"></div>
                <div class="skeleton" style="height:52px;border-radius:var(--r-lg);margin-bottom:0.5rem"></div>
                <div class="skeleton" style="height:52px;border-radius:var(--r-lg)"></div>
              </div>
            </div>

            <!-- Skill progress -->
            <div class="card">
              <h3 style="font-size:1.05rem;color:var(--text);margin-bottom:1.25rem">📈 Skill Progress</h3>
              ${[['Problem Solving',72],['System Design',45],['React / Frontend',85],['Data Structures',68]].map(([n,p])=>`
              <div style="margin-bottom:1rem">
                <div style="display:flex;justify-content:space-between;margin-bottom:0.4rem;font-size:0.875rem">
                  <span style="color:var(--text)">${n}</span><span style="color:var(--text-2)">${p}%</span>
                </div>
                <div class="progress-bar"><div class="progress-fill" style="width:${p}%"></div></div>
              </div>`).join('')}
            </div>
          </div>

          <!-- Sidebar -->
          <div style="display:flex;flex-direction:column;gap:1.25rem">
            <div class="card">
              <h3 style="font-size:1rem;color:var(--text);margin-bottom:1rem">🎯 Weekly Goals</h3>
              ${[['Complete 5 coding problems',true],['Attend 1 mentor session',true],['Submit project milestone',false],['Complete 3 more problems',false]].map(([t,done])=>`
              <div style="display:flex;align-items:center;gap:0.75rem;padding:0.5rem 0;border-bottom:1px solid var(--border)">
                <span style="color:${done?'var(--green)':'var(--text-3)'};font-size:1rem">${done?'✓':'○'}</span>
                <span style="font-size:0.875rem;${done?'opacity:0.5;text-decoration:line-through':''}">${t}</span>
              </div>`).join('')}
              <div style="margin-top:0.75rem">
                <div style="display:flex;justify-content:space-between;font-size:0.8rem;margin-bottom:0.4rem">
                  <span style="color:var(--text-2)">Progress</span><span style="color:var(--cyan)">2/4</span>
                </div>
                <div class="progress-bar"><div class="progress-fill" style="width:50%"></div></div>
              </div>
            </div>

            <div class="card">
              <h3 style="font-size:1rem;color:var(--text);margin-bottom:1rem">⚡ Quick Actions</h3>
              <div style="display:flex;flex-direction:column;gap:0.5rem">
                <a href="/coding"      class="btn-outline btn-sm" onclick="Router.navigate('/coding');return false">💻 Solve a Problem</a>
                <a href="/mentors"     class="btn-outline btn-sm" onclick="Router.navigate('/mentors');return false">👥 Book a Mentor</a>
                <a href="/courses"     class="btn-outline btn-sm" onclick="Router.navigate('/courses');return false">📚 Browse Courses</a>
                <a href="/portfolio"   class="btn-outline btn-sm" onclick="Router.navigate('/portfolio');return false">📄 Update Portfolio</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>`;

    // Load real leaderboard rank
    try {
      const lb = await API.leaderboard.list({ limit: 100 });
      const myEntry = lb.entries?.find(e => e.user_id === user.id);
      if (myEntry) {
        document.querySelectorAll('.stat-value')[3].textContent = '#' + myEntry.rank_position;
      }
    } catch {}

    // Load recent problems
    try {
      const problems = await API.coding.problems({ limit: 3 });
      const subs     = await API.coding.submissions().catch(() => []);
      const solved   = new Set(subs.filter(s => s.status === 'accepted').map(s => s.problem_id));

      document.getElementById('dashChallenges').innerHTML = problems.map(p => `
      <div class="challenge-card${solved.has(p.id) ? ' solved' : ''}" onclick="Router.navigate('/coding')" style="margin-bottom:0.5rem;cursor:pointer">
        <div class="challenge-check ${solved.has(p.id) ? 'done' : 'todo'}">${solved.has(p.id) ? '✓' : '○'}</div>
        <div style="flex:1;min-width:0">
          <div style="font-weight:600;color:var(--text);font-size:0.9rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escHtml(p.title)}</div>
          <div style="font-size:0.75rem;color:var(--text-3)">${p.xp_reward} XP</div>
        </div>
        <span class="badge badge-${p.difficulty}">${p.difficulty}</span>
      </div>`).join('');
    } catch {}
  }
};

// ── VIDEO ROOM ─────────────────────────────────────────────────
Pages.Video = {
  localStream: null,
  socket: null,

  async render({ roomCode }) {
    if (!Auth.isLoggedIn()) { Router.navigate('/auth'); return; }
    const user = Auth.getUser();
    const app  = document.getElementById('app');

    app.innerHTML = `
    <div class="pt-page" style="min-height:100vh;display:flex;flex-direction:column">
      <div style="padding:1rem 1.5rem;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;background:var(--surface)">
        <div style="display:flex;align-items:center;gap:0.75rem">
          <img src="/assets/logo.svg" width="30" height="30" style="filter:drop-shadow(0 0 6px rgba(0,212,255,0.4))"/>
          <span style="font-weight:600">Live Session</span>
          <span class="badge badge-green">Room: ${escHtml(roomCode)}</span>
        </div>
        <div style="display:flex;align-items:center;gap:0.75rem">
          <span id="peerCount" style="font-size:0.8rem;color:var(--text-2)">1 participant</span>
          <button class="btn-outline btn-sm" onclick="navigator.clipboard.writeText(window.location.href).then(()=>showToast('Link copied!','success'))">📋 Copy Link</button>
        </div>
      </div>
      <div style="flex:1;display:grid;grid-template-columns:1fr 280px">
        <div style="padding:1.5rem;display:flex;flex-direction:column;gap:1rem">
          <div class="video-grid" id="videoGrid">
            <div class="video-tile">
              <video id="localVideo" autoplay muted playsinline style="width:100%;height:100%;object-fit:cover"></video>
              <div class="video-tile-name">${escHtml(user.full_name || 'You')} (You)</div>
            </div>
          </div>
          <div class="video-controls" style="background:var(--surface);border-radius:var(--r-xl);padding:1rem">
            <button class="video-ctrl-btn" id="micBtn" onclick="Pages.Video.toggleMic()" title="Toggle mic">🎤</button>
            <button class="video-ctrl-btn" id="camBtn" onclick="Pages.Video.toggleCamera()" title="Toggle camera">📷</button>
            <button class="video-ctrl-btn" id="screenBtn" onclick="Pages.Video.toggleScreen()" title="Share screen">🖥</button>
            <button class="video-ctrl-btn end-call" onclick="Pages.Video.hangup()" title="End call">📵</button>
          </div>
        </div>
        <div style="border-left:1px solid var(--border);display:flex;flex-direction:column">
          <div id="chatMessages" style="flex:1;overflow-y:auto;padding:1rem;display:flex;flex-direction:column;gap:0.75rem;min-height:0;max-height:calc(100vh - 200px)"></div>
          <div style="border-top:1px solid var(--border);padding:0.75rem;display:flex;gap:0.5rem">
            <input type="text" class="input" id="chatInput" placeholder="Message..." style="font-size:0.85rem"/>
            <button class="btn-primary btn-sm" onclick="Pages.Video.sendChat()">Send</button>
          </div>
        </div>
      </div>
    </div>`;

    await this._startMedia(roomCode);
  },

  async _startMedia(roomCode) {
    try {
      this.localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      document.getElementById('localVideo').srcObject = this.localStream;
    } catch {
      showToast('Camera/mic permission denied', 'error');
    }
    if (typeof io !== 'undefined') {
      this.socket = io();
      const user = Auth.getUser();
      this.socket.emit('join-room', { roomCode, userId: user.id, userName: user.full_name || 'Learner' });
      this.socket.on('room-message', ({ userName, message }) => this._appendChat(userName, message));
      this.socket.on('user-joined', ({ userName }) => {
        showToast(`${userName} joined`, 'info');
        const el = document.getElementById('peerCount');
        if (el) el.textContent = `${document.querySelectorAll('.video-tile').length + 1} participants`;
      });
    }
    document.getElementById('chatInput')?.addEventListener('keydown', e => { if (e.key === 'Enter') this.sendChat(); });
  },

  toggleMic()    { const t = this.localStream?.getAudioTracks()[0]; if (t) { t.enabled = !t.enabled; document.getElementById('micBtn').classList.toggle('muted', !t.enabled); } },
  toggleCamera() { const t = this.localStream?.getVideoTracks()[0]; if (t) { t.enabled = !t.enabled; document.getElementById('camBtn').classList.toggle('cam-off', !t.enabled); } },

  async toggleScreen() {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      document.getElementById('localVideo').srcObject = stream;
      stream.getVideoTracks()[0].onended = () => { document.getElementById('localVideo').srcObject = this.localStream; };
    } catch {}
  },

  hangup() {
    this.localStream?.getTracks().forEach(t => t.stop());
    this.socket?.disconnect();
    Router.navigate('/mentors');
  },

  sendChat() {
    const input = document.getElementById('chatInput');
    const msg = input?.value.trim();
    if (!msg) return;
    const user = Auth.getUser();
    this.socket?.emit('room-message', { roomCode: location.pathname.split('/').pop(), message: msg, userName: user.full_name || 'You' });
    this._appendChat('You', msg, true);
    input.value = '';
  },

  _appendChat(name, msg, isMe = false) {
    const el = document.getElementById('chatMessages');
    if (!el) return;
    const d = document.createElement('div');
    d.style.cssText = `display:flex;flex-direction:column;align-items:${isMe ? 'flex-end' : 'flex-start'}`;
    d.innerHTML = `<div style="font-size:0.7rem;color:var(--text-3);margin-bottom:0.2rem">${escHtml(name)}</div>
      <div style="max-width:85%;padding:0.5rem 0.75rem;border-radius:10px;font-size:0.85rem;background:${isMe ? 'rgba(0,212,255,0.15)' : 'var(--surface-2)'};color:var(--text)">${escHtml(msg)}</div>`;
    el.appendChild(d);
    el.scrollTop = el.scrollHeight;
  }
};

// ── Utility ───────────────────────────────────────────────────
function escHtml(s) {
  return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
