Pages.Dashboard = {
  async render() {
    if (!Auth.isLoggedIn()) { Router.navigate('/auth'); return; }
    const user = Auth.getUser();
    const app  = document.getElementById('app');
    const hr   = new Date().getHours();
    const greeting = hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening';

    app.innerHTML = `
<div class="pt-page" style="min-height:100vh">
  <div class="container" style="padding-top:2.5rem;padding-bottom:5rem">

    <!-- Top bar -->
    <div style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1.5rem;margin-bottom:2.5rem">
      <div>
        <p style="font-size:0.78rem;font-weight:700;letter-spacing:0.07em;text-transform:uppercase;color:var(--text-3);margin-bottom:0.4rem">${greeting}</p>
        <h2 style="font-size:2.2rem;font-weight:800;margin-bottom:0.35rem">${escHtml(user.full_name?.split(' ')[0] || 'Learner')} <span class="text-grad">👋</span></h2>
        <p style="margin:0;font-size:0.9rem">${user.streak_days ? `🔥 <b style="color:var(--amber-2)">${user.streak_days}-day streak</b> — you're on fire!` : `Start your first streak today 🚀`}</p>
      </div>
      <div style="display:flex;gap:0.65rem;flex-wrap:wrap">
        <button class="btn-ghost btn-sm" onclick="Router.navigate('/coding')">💻 Practice</button>
        <button class="btn-primary btn-sm" onclick="Router.navigate('/mentors')">📅 Book Mentor</button>
      </div>
    </div>

    <!-- Stats row -->
    <div class="grid-4" style="margin-bottom:2rem">
      ${[
        {icon:'⚡',val:(user.total_xp||0).toLocaleString(),label:'Total XP',sub:'Level '+(Math.floor((user.total_xp||0)/1000)+1),cls:'stat-icon-blue'},
        {icon:'💻',val:user.problems_solved||0,label:'Problems Solved',sub:'All difficulties',cls:'stat-icon-violet'},
        {icon:'🔥',val:(user.streak_days||0)+' days',label:'Current Streak',sub:'Keep it up!',cls:'stat-icon-amber'},
        {icon:'🏆',val:'#—',label:'Global Rank',sub:'Loading…',cls:'stat-icon-green',id:'dashRank'},
      ].map(s=>`
      <div class="stat-card" style="flex-direction:column;align-items:flex-start;gap:0.875rem">
        <div class="stat-icon ${s.cls}">${s.icon}</div>
        <div>
          <div class="stat-value" ${s.id?`id="${s.id}"`:''}>${s.val}</div>
          <div class="stat-label">${s.label}</div>
          <div style="font-size:0.72rem;color:var(--text-4);margin-top:0.1rem">${s.sub}</div>
        </div>
      </div>`).join('')}
    </div>

    <!-- Main grid row 1 -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;margin-bottom:1.5rem">

      <!-- XP Chart -->
      <div class="card-glow" style="padding:1.75rem">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem">
          <div><h4 style="margin-bottom:0.2rem">XP This Week</h4><p style="margin:0;font-size:0.78rem">Daily breakdown</p></div>
          <div class="text-grad" style="font-family:var(--font-head);font-size:1.3rem;font-weight:800" id="xpWeekTotal">+0 XP</div>
        </div>
        <canvas id="xpChart" style="width:100%" height="120"></canvas>
      </div>

      <!-- Heatmap -->
      <div class="card-glow" style="padding:1.75rem">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem">
          <div><h4 style="margin-bottom:0.2rem">Activity Heatmap</h4><p style="margin:0;font-size:0.78rem">Last 16 weeks</p></div>
          <div style="font-size:0.78rem;color:var(--text-3)" id="activeDays">— active days</div>
        </div>
        <div id="heatmap" style="display:flex;gap:3px;overflow-x:auto;padding-bottom:3px"></div>
        <div style="display:flex;align-items:center;gap:0.5rem;margin-top:0.75rem;font-size:0.72rem;color:var(--text-4)">
          Less ${[0,1,2,3,4].map(l=>`<div style="width:10px;height:10px;border-radius:2px;background:${['var(--surface-3)','rgba(59,130,246,0.18)','rgba(59,130,246,0.38)','rgba(59,130,246,0.62)','var(--blue-2)'][l]}"></div>`).join('')} More
        </div>
      </div>
    </div>

    <!-- Main grid row 2 -->
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1.5rem;margin-bottom:1.5rem">

      <!-- Skill Radar -->
      <div class="card-glow" style="padding:1.75rem">
        <h4 style="margin-bottom:1.25rem">Skill Radar</h4>
        <canvas id="radarChart" height="190" style="width:100%"></canvas>
        <div id="skillList" style="margin-top:1rem;display:flex;flex-direction:column;gap:0.5rem"></div>
      </div>

      <!-- Daily Challenges -->
      <div class="card-glow" style="padding:1.75rem">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.25rem">
          <h4>Daily Challenges</h4>
          <span class="badge badge-orange">+50 XP</span>
        </div>
        <div id="dashChallenges">${[1,2,3].map(()=>`<div class="skeleton" style="height:52px;border-radius:var(--r-lg);margin-bottom:0.5rem"></div>`).join('')}</div>
      </div>

      <!-- Weekly Goals -->
      <div class="card-glow" style="padding:1.75rem">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.25rem">
          <h4>Weekly Goals</h4>
          <span id="goalsDone" style="font-size:0.78rem;color:var(--blue-2);font-weight:700">2/5 done</span>
        </div>
        <div>
          ${[
            {t:'Solve 5 problems',done:true},
            {t:'Complete 1 course module',done:true},
            {t:'Book a mentor session',done:false},
            {t:'Submit portfolio project',done:false},
            {t:'Attend weekly contest',done:false},
          ].map((g,i)=>`
          <div style="display:flex;align-items:center;gap:0.75rem;padding:0.55rem 0;border-bottom:${i<4?'1px solid var(--border)':'none'};cursor:pointer" onclick="Pages.Dashboard._toggleGoal(this)">
            <div class="challenge-check goal-check ${g.done?'done':'todo'}">${g.done?'✓':'○'}</div>
            <span style="font-size:0.84rem;color:${g.done?'var(--text-3)':'var(--text)'};${g.done?'text-decoration:line-through':''};transition:all var(--fast)">${g.t}</span>
          </div>`).join('')}
        </div>
      </div>
    </div>

    <!-- Row 3 -->
    <div style="display:grid;grid-template-columns:2fr 1fr;gap:1.5rem">

      <!-- Recent Submissions -->
      <div class="card-glow" style="padding:1.75rem">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.25rem">
          <h4>Recent Submissions</h4>
          <a href="/coding" class="btn-ghost btn-sm" onclick="Router.navigate('/coding');return false">View All →</a>
        </div>
        <div id="recentSubs">${[1,2,3,4,5].map(()=>`<div class="skeleton" style="height:42px;border-radius:var(--r-sm);margin-bottom:0.5rem"></div>`).join('')}</div>
      </div>

      <!-- Quick Actions -->
      <div class="card" style="padding:1.75rem">
        <h4 style="margin-bottom:1.25rem">Quick Actions</h4>
        <div style="display:flex;flex-direction:column;gap:0.5rem">
          ${[
            ['💻','Solve a Problem','/coding'],
            ['👥','Find a Mentor','/mentors'],
            ['📚','Browse Courses','/courses'],
            ['💼','View Internships','/internships'],
            ['📄','My Portfolio','/portfolio'],
            ['🏆','Leaderboard','/leaderboard'],
          ].map(([e,l,p])=>`
          <button class="btn-ghost btn-sm" style="width:100%;justify-content:flex-start;text-align:left" onclick="Router.navigate('${p}')">${e} ${l}</button>`).join('')}
        </div>
      </div>
    </div>

  </div>
</div>`;

    this._initCharts(user);
    this._initHeatmap();
    this._loadChallenges();
    this._loadSubmissions();
    this._loadRank(user);
  },

  _toggleGoal(row) {
    const check = row.querySelector('.goal-check');
    const text  = row.querySelector('span:last-child');
    const isDone = check.classList.toggle('done');
    check.classList.toggle('todo', !isDone);
    check.textContent = isDone ? '✓' : '○';
    text.style.textDecoration = isDone ? 'line-through' : 'none';
    text.style.color = isDone ? 'var(--text-3)' : 'var(--text)';
  },

  _initCharts(user) {
    const days = ['M','T','W','T','F','S','S'];
    const xp   = [80,320,0,540,200,480,150];
    const total = xp.reduce((a,b)=>a+b,0);
    const el = document.getElementById('xpWeekTotal');
    if (el) el.textContent = '+' + total.toLocaleString() + ' XP';

    const canvas = document.getElementById('xpChart');
    if (!canvas) return;
    requestAnimationFrame(() => {
      canvas.width  = canvas.offsetWidth || 400;
      canvas.height = 120;
      const c = canvas.getContext('2d');
      const max = Math.max(...xp, 1);
      const W = canvas.width, H = canvas.height, PB = 22, PT = 8;
      const bW = (W - 32) / days.length;

      xp.forEach((v, i) => {
        const bH = ((v/max) * (H - PB - PT));
        const x  = 16 + i * bW + bW * 0.18;
        const w  = bW * 0.64;
        const y  = H - PB - bH;
        if (v > 0) {
          const g = c.createLinearGradient(0, y, 0, H - PB);
          g.addColorStop(0, 'rgba(59,130,246,0.85)');
          g.addColorStop(1, 'rgba(59,130,246,0.12)');
          c.fillStyle = g;
          c.beginPath(); c.roundRect(x, y, w, bH, 4); c.fill();
        }
        c.fillStyle = v > 0 ? 'rgba(148,163,184,0.6)' : 'var(--text-4)';
        c.font = '600 10px Plus Jakarta Sans, sans-serif';
        c.textAlign = 'center';
        c.fillText(days[i], x + w/2, H - 6);
      });
    });

    this._drawRadar();
  },

  _drawRadar() {
    const canvas = document.getElementById('radarChart');
    if (!canvas) return;
    requestAnimationFrame(() => {
      const W = canvas.offsetWidth || 200;
      canvas.width = W; canvas.height = 190;
      const c = canvas.getContext('2d'), cx = W/2, cy = 90, r = 70;
      const skills = [
        {l:'DSA',v:0.72},{l:'Frontend',v:0.85},{l:'Backend',v:0.60},
        {l:'System Design',v:0.45},{l:'ML/AI',v:0.35},{l:'DevOps',v:0.50},
      ];
      const n = skills.length;
      const ang = i => (i * 2 * Math.PI / n) - Math.PI/2;

      // Rings
      [.25,.5,.75,1].forEach(ring => {
        c.beginPath();
        skills.forEach((_,i) => { const a=ang(i),x=cx+r*ring*Math.cos(a),y=cy+r*ring*Math.sin(a); i?c.lineTo(x,y):c.moveTo(x,y); });
        c.closePath(); c.strokeStyle='rgba(120,180,255,0.07)'; c.lineWidth=1; c.stroke();
      });
      // Spokes
      skills.forEach((_,i) => { c.beginPath(); c.moveTo(cx,cy); c.lineTo(cx+r*Math.cos(ang(i)),cy+r*Math.sin(ang(i))); c.strokeStyle='rgba(120,180,255,0.08)'; c.stroke(); });
      // Fill
      c.beginPath();
      skills.forEach((s,i) => { const a=ang(i),x=cx+r*s.v*Math.cos(a),y=cy+r*s.v*Math.sin(a); i?c.lineTo(x,y):c.moveTo(x,y); });
      c.closePath(); c.fillStyle='rgba(59,130,246,0.1)'; c.fill();
      c.strokeStyle='rgba(59,130,246,0.55)'; c.lineWidth=2; c.stroke();
      // Dots
      skills.forEach((s,i) => { const a=ang(i),x=cx+r*s.v*Math.cos(a),y=cy+r*s.v*Math.sin(a); c.beginPath(); c.arc(x,y,3.5,0,2*Math.PI); c.fillStyle='#3b82f6'; c.fill(); });
      // Labels
      c.font='600 10px Plus Jakarta Sans, sans-serif'; c.fillStyle='rgba(120,164,200,0.65)'; c.textAlign='center';
      skills.forEach((s,i) => { const a=ang(i),x=cx+(r+16)*Math.cos(a),y=cy+(r+16)*Math.sin(a)+4; c.fillText(s.l,x,y); });

      // Skill list
      const list = document.getElementById('skillList');
      if (list) list.innerHTML = skills.map(s=>`
      <div style="display:flex;align-items:center;gap:0.75rem">
        <div style="font-size:0.78rem;color:var(--text-2);width:90px;flex-shrink:0;font-weight:500">${s.l}</div>
        <div class="progress-bar" style="flex:1"><div class="progress-fill" style="width:${Math.round(s.v*100)}%"></div></div>
        <div style="font-size:0.75rem;color:var(--blue-2);font-weight:700;width:30px;text-align:right">${Math.round(s.v*100)}%</div>
      </div>`).join('');
    });
  },

  _initHeatmap() {
    const container = document.getElementById('heatmap');
    if (!container) return;
    const WEEKS = 16, today = new Date(), totalDays = WEEKS * 7;
    const start = new Date(today); start.setDate(today.getDate() - totalDays + 1);
    const activity = {};
    for (let i = 0; i < totalDays; i++) {
      const d = new Date(start); d.setDate(start.getDate()+i);
      const k = d.toISOString().split('T')[0];
      if (Math.random() < 0.35 + (i/totalDays)*0.3) activity[k] = Math.floor(Math.random()*5)+1;
    }
    const active = Object.keys(activity).length;
    const el = document.getElementById('activeDays');
    if (el) el.textContent = active + ' active days';
    const colors = ['var(--surface-3)','rgba(59,130,246,0.18)','rgba(59,130,246,0.38)','rgba(59,130,246,0.62)','var(--blue-2)'];
    for (let w=0; w<WEEKS; w++) {
      const col = document.createElement('div');
      col.style.cssText = 'display:flex;flex-direction:column;gap:3px;flex-shrink:0';
      for (let d=0; d<7; d++) {
        const date = new Date(start); date.setDate(start.getDate()+w*7+d);
        const k = date.toISOString().split('T')[0];
        const lvl = Math.min(activity[k]||0, 4);
        const cell = document.createElement('div');
        cell.style.cssText = `width:10px;height:10px;border-radius:2px;background:${colors[lvl]};cursor:pointer;transition:transform .12s`;
        cell.title = `${k}: ${lvl?lvl+' activities':'No activity'}`;
        cell.onmouseover = () => cell.style.transform='scale(1.45)';
        cell.onmouseout  = () => cell.style.transform='scale(1)';
        col.appendChild(cell);
      }
      container.appendChild(col);
    }
  },

  async _loadChallenges() {
    try {
      const problems = await API.coding.problems({limit:3});
      const subs = Auth.isLoggedIn() ? await API.coding.submissions().catch(()=>[]) : [];
      const solved = new Set(subs.filter(s=>s.status==='accepted').map(s=>s.problem_id));
      const el = document.getElementById('dashChallenges');
      if (!el) return;
      el.innerHTML = problems.map(p=>`
      <div class="challenge-card${solved.has(p.id)?' solved':''}" onclick="Router.navigate('/coding')" style="margin-bottom:0.5rem">
        <div class="challenge-check ${solved.has(p.id)?'done':'todo'}">${solved.has(p.id)?'✓':'○'}</div>
        <div style="flex:1;min-width:0">
          <div class="problem-title" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escHtml(p.title)}</div>
          <div style="font-size:0.72rem;color:var(--text-3)">${p.xp_reward} XP</div>
        </div>
        <span class="badge badge-${p.difficulty}">${p.difficulty}</span>
      </div>`).join('');
    } catch {
      const el = document.getElementById('dashChallenges');
      if (el) el.innerHTML = '<p style="font-size:0.85rem;color:var(--text-3)">Start coding to see challenges!</p>';
    }
  },

  async _loadSubmissions() {
    try {
      const subs = await API.coding.submissions();
      const el = document.getElementById('recentSubs');
      if (!el) return;
      if (!subs.length) { el.innerHTML='<p style="font-size:0.85rem;color:var(--text-3);padding:0.5rem 0">No submissions yet — start coding!</p>'; return; }
      el.innerHTML = subs.slice(0,6).map(s=>`
      <div style="display:flex;align-items:center;gap:0.875rem;padding:0.55rem 0;border-bottom:1px solid var(--border)">
        <div style="width:7px;height:7px;border-radius:50%;flex-shrink:0;background:${s.status==='accepted'?'var(--emerald)':s.status==='error'?'var(--rose)':'var(--amber)'}"></div>
        <div style="flex:1;min-width:0">
          <div style="font-size:0.855rem;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escHtml(s.problem_title||'Problem #'+s.problem_id)}</div>
          <div style="font-size:0.72rem;color:var(--text-3)">${escHtml(s.language||'')} · ${s.status}</div>
        </div>
        ${s.xp_earned?`<span style="font-size:0.78rem;font-weight:700;color:var(--blue-2)">+${s.xp_earned}</span>`:''}
      </div>`).join('');
    } catch {}
  },

  async _loadRank(user) {
    try {
      const res = await API.leaderboard.list({limit:100});
      const entries = res.entries || res;
      const me = entries.find(e=>e.user_id===user.id);
      const el = document.getElementById('dashRank');
      if (el && me) { el.textContent='#'+me.rank_position; el.closest('.stat-card').querySelector('.stat-label').textContent='Global Rank'; }
    } catch {}
  }
};
