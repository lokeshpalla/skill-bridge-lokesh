// Video page is defined in pages/auth.js (Pages.Video)
// This file exists so index.html script tags don't 404
