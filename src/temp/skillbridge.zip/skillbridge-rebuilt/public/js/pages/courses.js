Pages.Courses = {
  currentCategory: 'All',
  async render() {
    if (!Auth.isLoggedIn()) { Router.navigate('/auth'); return; }
    const app = document.getElementById('app');
    app.innerHTML = `
<div class="pt-page" style="min-height:100vh">
  <div class="container" style="padding-top:2.5rem;padding-bottom:5rem">
    <div style="display:flex;align-items:flex-end;justify-content:space-between;flex-wrap:wrap;gap:1.5rem;margin-bottom:2.5rem">
      <div>
        <div class="section-badge section-badge-blue">Courses</div>
        <h2 style="margin-top:0.6rem">Master every skill<br><span class="text-grad">step by step</span></h2>
      </div>
      <div class="filter-bar" id="courseFilters">
        ${['All','Frontend','Backend','DSA','System Design','ML/AI','DevOps'].map((c,i)=>`
        <button class="filter-chip${i===0?' active':''}" data-cat="${c}">${c}</button>`).join('')}
      </div>
    </div>

    <div class="grid-4" style="margin-bottom:2.5rem">
      ${[
        {e:'📚',v:'120+',l:'Courses',c:'stat-icon-blue'},
        {e:'⚡',v:'2.4K',l:'Hours of Content',c:'stat-icon-violet'},
        {e:'✅',v:'48K+',l:'Completions',c:'stat-icon-green'},
        {e:'⭐',v:'4.7',l:'Avg Rating',c:'stat-icon-amber'},
      ].map(s=>`
      <div class="stat-card">
        <div class="stat-icon ${s.c}">${s.e}</div>
        <div><div class="stat-value">${s.v}</div><div class="stat-label">${s.l}</div></div>
      </div>`).join('')}
    </div>

    <div id="courseGrid" class="grid-3">
      ${[1,2,3,4,5,6].map(()=>`<div class="skeleton" style="height:280px;border-radius:var(--r-xl)"></div>`).join('')}
    </div>
  </div>
</div>`;
    this._setupFilters();
    await this._load();
  },

  _setupFilters() {
    document.getElementById('courseFilters')?.addEventListener('click', e=>{
      const chip = e.target.closest('.filter-chip'); if (!chip) return;
      e.currentTarget.querySelectorAll('.filter-chip').forEach(c=>c.classList.remove('active'));
      chip.classList.add('active');
      this.currentCategory = chip.dataset.cat;
      this._load();
    });
  },

  async _load() {
    try {
      const params = this.currentCategory !== 'All' ? {category: this.currentCategory} : {};
      const courses = await API.courses.list(params);
      const grid = document.getElementById('courseGrid');
      if (!grid) return;
      const icons = {Frontend:'⚛️',Backend:'🛠️',DSA:'🧩','System Design':'🏗️','ML/AI':'🤖',DevOps:'⚙️'};
      const colors = {Frontend:'blue',Backend:'violet',DSA:'cyan','System Design':'orange','ML/AI':'violet',DevOps:'green'};
      grid.innerHTML = courses.map(c=>`
      <div class="card-glow" style="display:flex;flex-direction:column;gap:1rem;cursor:pointer" onclick="Pages.Courses._enroll(${c.id},this)">
        <div style="height:130px;background:${ {'blue':'rgba(59,130,246,0.08)','violet':'rgba(139,92,246,0.08)','cyan':'rgba(6,182,212,0.08)','orange':'rgba(249,115,22,0.08)','green':'rgba(16,185,129,0.08)'}[colors[c.category]||'blue'] };border-radius:var(--r-lg);display:flex;align-items:center;justify-content:center;font-size:2.5rem;border:1px solid ${ {'blue':'rgba(59,130,246,0.12)','violet':'rgba(139,92,246,0.12)','cyan':'rgba(6,182,212,0.12)','orange':'rgba(249,115,22,0.12)','green':'rgba(16,185,129,0.12)'}[colors[c.category]||'blue'] }">
          ${icons[c.category]||'📚'}
        </div>
        <div>
          <div style="display:flex;align-items:center;gap:0.5rem;margin-bottom:0.5rem">
            <span class="badge badge-${c.difficulty||'medium'}">${c.difficulty||'Intermediate'}</span>
            ${c.is_new?`<span class="badge badge-new">New</span>`:''}
          </div>
          <div style="font-weight:700;font-size:0.95rem;margin-bottom:0.35rem;line-height:1.3">${escHtml(c.title)}</div>
          <p style="font-size:0.82rem;line-height:1.6;margin:0;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">${escHtml(c.description||'')}</p>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-top:auto;padding-top:0.75rem;border-top:1px solid var(--border)">
          <span style="font-size:0.8rem;color:var(--text-3)">📖 ${c.duration_hours||'—'}h · ${c.lessons_count||'—'} lessons</span>
          <button class="btn-primary btn-sm enroll-btn">Enroll Free</button>
        </div>
      </div>`).join('');
    } catch {
      const grid = document.getElementById('courseGrid');
      if (grid) grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:4rem;color:var(--text-2)">Could not load courses.</div>`;
    }
  },

  async _enroll(id, card) {
    const btn = card.querySelector('.enroll-btn');
    if (btn.disabled) return;
    btn.disabled = true; btn.textContent = 'Enrolling…';
    try {
      await API.courses.enroll(id);
      showToast('Enrolled successfully! 🎉', 'success');
      btn.textContent = '✓ Enrolled';
    } catch(e) {
      showToast(e.message||'Could not enroll', 'error');
      btn.disabled = false; btn.textContent = 'Enroll Free';
    }
  }
};
