Pages.Leaderboard = {
  async render() {
    const app = document.getElementById('app');
    app.innerHTML = `
<div class="pt-page" style="min-height:100vh">
  <div class="container" style="padding-top:2.5rem;padding-bottom:5rem;max-width:900px">

    <div style="text-align:center;margin-bottom:3rem">
      <div class="section-badge section-badge-blue">Global Rankings</div>
      <h2 style="margin-top:0.6rem">Who's on <span class="text-grad">top this week?</span></h2>
      <p style="margin-top:0.75rem">Compete globally. Earn XP. Climb the ranks.</p>
    </div>

    <!-- Top 3 podium -->
    <div id="podium" style="display:flex;align-items:flex-end;justify-content:center;gap:1.5rem;margin-bottom:3rem;min-height:160px">
      ${[1,2,3].map(()=>`<div class="skeleton" style="width:160px;height:130px;border-radius:var(--r-xl)"></div>`).join('')}
    </div>

    <!-- Filters -->
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem">
      <div class="tabs">
        <button class="tab active" data-period="week">This Week</button>
        <button class="tab" data-period="month">This Month</button>
        <button class="tab" data-period="all">All Time</button>
      </div>
      <div style="font-size:0.82rem;color:var(--text-3)" id="totalParticipants">—</div>
    </div>

    <!-- Table -->
    <div id="lbTable">
      ${[1,2,3,4,5,6,7,8].map(()=>`<div class="skeleton" style="height:58px;border-radius:var(--r-lg);margin-bottom:0.5rem"></div>`).join('')}
    </div>
  </div>
</div>`;

    this._setupTabs();
    await this._load();
  },

  _setupTabs() {
    document.querySelector('.tabs')?.addEventListener('click', e=>{
      const tab = e.target.closest('.tab'); if (!tab) return;
      document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
      tab.classList.add('active');
      this._load(tab.dataset.period);
    });
  },

  async _load(period='week') {
    try {
      const res = await API.leaderboard.list({limit:50});
      const entries = res.entries || res;
      const me = Auth.getUser();
      const el = document.getElementById('totalParticipants');
      if (el) el.textContent = `${entries.length} participants`;

      // Podium (top 3)
      const podium = document.getElementById('podium');
      if (podium && entries.length >= 3) {
        const order = [entries[1], entries[0], entries[2]]; // 2nd, 1st, 3rd
        const heights = ['110px','140px','90px'];
        const medals  = ['🥈','🥇','🥉'];
        const colors  = ['rgba(148,163,184,0.2)','rgba(251,191,36,0.15)','rgba(205,127,50,0.15)'];
        const borders = ['rgba(148,163,184,0.3)','rgba(251,191,36,0.4)','rgba(205,127,50,0.3)'];
        podium.innerHTML = order.map((e,i) => `
        <div style="display:flex;flex-direction:column;align-items:center;gap:0.75rem">
          <div style="font-size:1.4rem">${medals[i]}</div>
          <div style="width:48px;height:48px;border-radius:50%;background:var(--grad-brand);display:flex;align-items:center;justify-content:center;font-family:var(--font-head);font-weight:800;color:white">${(e.full_name||'?')[0].toUpperCase()}</div>
          <div style="width:150px;height:${heights[i]};background:${colors[i]};border:1px solid ${borders[i]};border-radius:var(--r-xl) var(--r-xl) 0 0;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;padding:1rem;text-align:center">
            <div style="font-weight:700;font-size:0.875rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:130px">${escHtml(e.full_name)}</div>
            <div style="font-family:var(--font-head);font-weight:800;color:var(--blue-2);font-size:1rem">${(e.total_xp||0).toLocaleString()} XP</div>
          </div>
        </div>`).join('');
      }

      // Table
      const table = document.getElementById('lbTable');
      if (!table) return;
      table.innerHTML = entries.map((e,i) => {
        const medal = ['🥇','🥈','🥉'][i] || null;
        const isMe = me && e.user_id === me.id;
        return `
        <div style="display:flex;align-items:center;gap:1rem;padding:0.875rem 1.1rem;background:${isMe?'rgba(59,130,246,0.06)':'var(--surface)'};border:1px solid ${isMe?'rgba(59,130,246,0.25)':'var(--border)'};border-radius:var(--r-lg);margin-bottom:0.5rem;transition:border-color var(--fast)" onmouseover="this.style.borderColor='var(--border-2)'" onmouseout="this.style.borderColor='${isMe?'rgba(59,130,246,0.25)':'var(--border)'}'" >
          <div style="width:36px;text-align:center;font-size:${medal?'1.1':'0.85'}rem;font-weight:700;color:var(--text-3);flex-shrink:0;font-family:var(--font-mono)">${medal||('#'+(e.rank_position||i+1))}</div>
          <div style="width:36px;height:36px;border-radius:50%;background:var(--grad-brand);display:flex;align-items:center;justify-content:center;font-weight:800;font-family:var(--font-head);font-size:0.85rem;color:white;flex-shrink:0">${(e.full_name||'?')[0].toUpperCase()}</div>
          <div style="flex:1;min-width:0">
            <div style="font-weight:600;font-size:0.9rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
              ${escHtml(e.full_name)}${isMe?` <span style="font-size:0.72rem;color:var(--blue-2);font-weight:800">(you)</span>`:''}
            </div>
            <div style="font-size:0.75rem;color:var(--text-3);margin-top:0.1rem">${e.problems_solved||0} solved · 🔥 ${e.streak_days||0} streak</div>
          </div>
          <div style="display:flex;gap:0.75rem;align-items:center;flex-shrink:0">
            <div style="text-align:right">
              <div style="font-family:var(--font-head);font-weight:800;color:${isMe?'var(--blue-2)':'var(--text)'}">${(e.total_xp||0).toLocaleString()}</div>
              <div style="font-size:0.7rem;color:var(--text-3)">XP</div>
            </div>
          </div>
        </div>`;
      }).join('');
    } catch(e) {
      const table = document.getElementById('lbTable');
      if (table) table.innerHTML = `<p style="text-align:center;color:var(--text-2);padding:3rem">Could not load leaderboard.</p>`;
    }
  }
};
