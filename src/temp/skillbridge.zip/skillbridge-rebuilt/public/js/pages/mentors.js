Pages.Mentors = {
  async render() {
    if (!Auth.isLoggedIn()) { Router.navigate('/auth'); return; }
    const app = document.getElementById('app');
    app.innerHTML = `
<div class="pt-page" style="min-height:100vh">
  <div class="container" style="padding-top:2.5rem;padding-bottom:5rem">

    <div style="display:flex;align-items:flex-end;justify-content:space-between;flex-wrap:wrap;gap:1.5rem;margin-bottom:2.5rem">
      <div>
        <div class="section-badge section-badge-violet">Expert Mentors</div>
        <h2 style="margin-top:0.6rem">Book 1:1 sessions with<br><span class="text-grad">real engineers</span></h2>
      </div>
      <div style="display:flex;gap:0.65rem;align-items:center;flex-wrap:wrap">
        <div class="input-wrap" style="width:260px">
          <svg class="input-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          <input class="input" id="mentorSearch" placeholder="Search by name, skill, company…" oninput="Pages.Mentors._search(this.value)"/>
        </div>
        <div class="filter-bar" id="companyFilter">
          ${['All','FAANG','Startups','Research'].map((f,i)=>`<button class="filter-chip${i===0?' active':''}" data-filter="${f}">${f}</button>`).join('')}
        </div>
      </div>
    </div>

    <!-- Stats -->
    <div class="grid-4" style="margin-bottom:2rem">
      ${[
        {e:'👥',v:'500+',l:'Expert Mentors',c:'stat-icon-blue'},
        {e:'⭐',v:'4.8',l:'Average Rating',c:'stat-icon-amber'},
        {e:'📅',v:'12K+',l:'Sessions Done',c:'stat-icon-violet'},
        {e:'🏢',v:'150+',l:'Companies',c:'stat-icon-green'},
      ].map(s=>`
      <div class="stat-card">
        <div class="stat-icon ${s.c}">${s.e}</div>
        <div><div class="stat-value">${s.v}</div><div class="stat-label">${s.l}</div></div>
      </div>`).join('')}
    </div>

    <div id="mentorGrid" class="grid-3">
      ${[1,2,3,4,5,6].map(()=>`<div class="skeleton" style="height:300px;border-radius:var(--r-xl)"></div>`).join('')}
    </div>
  </div>
</div>

<!-- Booking Modal -->
<div class="modal-overlay" id="bookingModal">
  <div class="modal">
    <div class="modal-header">
      <h4 id="bookingTitle">Book a Session</h4>
      <button class="modal-close" onclick="document.getElementById('bookingModal').classList.remove('open')">✕</button>
    </div>
    <div class="field">
      <label class="label">Preferred Date & Time</label>
      <input type="datetime-local" class="input" id="bookingDate"/>
    </div>
    <div class="field" style="margin-top:1rem">
      <label class="label">What do you want to cover?</label>
      <textarea class="input" id="bookingTopic" placeholder="e.g. System design mock interview, DSA problem solving, career guidance…" style="min-height:80px"></textarea>
    </div>
    <div style="display:flex;gap:0.75rem;margin-top:1.75rem">
      <button class="btn-ghost btn-sm" style="flex:1;justify-content:center" onclick="document.getElementById('bookingModal').classList.remove('open')">Cancel</button>
      <button class="btn-primary btn-sm" style="flex:2;justify-content:center" onclick="Pages.Mentors._confirmBook()" id="confirmBookBtn">Confirm Booking</button>
    </div>
  </div>
</div>`;

    await this._load();
    this._setupFilters();
  },

  _currentMentorId: null,

  async _load(search='', filter='All') {
    try {
      const params = {};
      if (search) params.search = search;
      const mentors = await API.mentors.list(params);
      const grid = document.getElementById('mentorGrid');
      if (!grid) return;
      if (!mentors.length) {
        grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:4rem;color:var(--text-2)">No mentors found. Try a different search.</div>`;
        return;
      }
      grid.innerHTML = mentors.map(m => `
      <div class="mentor-card" style="cursor:default">
        <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:0.75rem">
          <div style="display:flex;align-items:center;gap:0.875rem">
            <div style="width:50px;height:50px;border-radius:50%;background:var(--grad-brand);display:flex;align-items:center;justify-content:center;font-size:1.2rem;font-weight:800;color:white;flex-shrink:0;font-family:var(--font-head)">
              ${(m.full_name||'M')[0].toUpperCase()}
            </div>
            <div>
              <div style="font-weight:700;color:var(--text)">${escHtml(m.full_name)}</div>
              <div style="font-size:0.78rem;color:var(--text-3)">${escHtml(m.company||m.title||'Software Engineer')}</div>
              <div style="display:flex;align-items:center;gap:0.5rem;margin-top:0.25rem">
                <span class="mentor-stars">★ ${(m.rating||4.8).toFixed(1)}</span>
                <span style="color:var(--text-4);font-size:0.72rem">${m.sessions_count||0} sessions</span>
              </div>
            </div>
          </div>
          <div style="text-align:right;flex-shrink:0">
            <div style="font-family:var(--font-head);font-weight:800;color:var(--blue-2)">₹${m.hourly_rate||3500}</div>
            <div style="font-size:0.68rem;color:var(--text-3)">/session</div>
          </div>
        </div>
        <p style="font-size:0.84rem;line-height:1.65;margin:0">${escHtml(m.bio||'Experienced engineer helping developers level up. Specializes in technical interviews and system design.')}</p>
        <div style="display:flex;flex-wrap:wrap;gap:0.35rem">
          ${(m.skills||['System Design','DSA','Backend']).toString().split(',').slice(0,4).map(s=>`<span class="skill-pill">${escHtml(s.trim())}</span>`).join('')}
        </div>
        <div style="display:flex;gap:0.6rem">
          <button class="btn-ghost btn-sm" style="flex:1;justify-content:center">View Profile</button>
          <button class="btn-primary btn-sm" style="flex:2;justify-content:center" onclick="Pages.Mentors._openBooking(${m.id},'${escHtml(m.full_name)}')">Book Session →</button>
        </div>
      </div>`).join('');
    } catch(e) {
      const grid = document.getElementById('mentorGrid');
      if (grid) grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:4rem;color:var(--text-2)">Could not load mentors. Please try again.</div>`;
    }
  },

  _searchTimer: null,
  _search(val) { clearTimeout(this._searchTimer); this._searchTimer = setTimeout(()=>this._load(val), 300); },

  _setupFilters() {
    document.getElementById('companyFilter')?.addEventListener('click', e=>{
      const chip = e.target.closest('.filter-chip'); if (!chip) return;
      e.currentTarget.querySelectorAll('.filter-chip').forEach(c=>c.classList.remove('active'));
      chip.classList.add('active');
      this._load('', chip.dataset.filter);
    });
  },

  _openBooking(mentorId, name) {
    this._currentMentorId = mentorId;
    document.getElementById('bookingTitle').textContent = `Book with ${name}`;
    document.getElementById('bookingModal').classList.add('open');
    const now = new Date(); now.setDate(now.getDate()+1); now.setHours(10,0,0,0);
    document.getElementById('bookingDate').value = now.toISOString().slice(0,16);
  },

  async _confirmBook() {
    const date  = document.getElementById('bookingDate').value;
    const topic = document.getElementById('bookingTopic').value;
    const btn   = document.getElementById('confirmBookBtn');
    if (!date) { showToast('Please select a date and time', 'error'); return; }
    btn.disabled = true; btn.textContent = 'Booking…';
    try {
      const res = await API.mentors.book({ mentor_id: this._currentMentorId, session_date: date, notes: topic });
      document.getElementById('bookingModal').classList.remove('open');
      showToast(`Session booked! Room: ${res.video_room_code || 'Generated'}`, 'success');
    } catch(e) {
      showToast(e.message||'Booking failed', 'error');
    } finally { btn.disabled = false; btn.textContent = 'Confirm Booking'; }
  }
};
