/* ═══════════════════════════════════════════════════════════════
   CODING ARENA — World-Class LeetCode-style Platform
   Features: 3-panel layout, test cases, complexity badge,
             progression hints, submission history, AI Socratic tutor
   ═══════════════════════════════════════════════════════════════ */
Pages.Coding = {
  currentProblem: null,
  language: 'javascript',
  allProblems: [],
  solvedIds: new Set(),
  _activeTab: 'description',

  /* ─── RENDER ──────────────────────────────────────────────── */
  async render() {
    const app = document.getElementById('app');
    app.innerHTML = `
<div class="pt-page" style="height:calc(100vh - 64px);display:flex;flex-direction:column;overflow:hidden">

  <!-- ── Top bar ──────────────────────────────────────────── -->
  <div style="display:flex;align-items:center;justify-content:space-between;padding:0.75rem 1.5rem;border-bottom:1px solid var(--border);background:var(--bg-1);flex-shrink:0;gap:1rem;flex-wrap:wrap">
    <div style="display:flex;align-items:center;gap:0.75rem">
      <div class="section-badge section-badge-blue" style="margin:0">💻 Coding Arena</div>
      <div id="codingStats" style="display:flex;gap:0.75rem;align-items:center"></div>
    </div>
    <div style="display:flex;align-items:center;gap:0.75rem;flex-wrap:wrap">
      <div class="input-wrap" style="width:220px">
        <svg class="input-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
        <input class="input" id="searchProblems" placeholder="Search problems…" style="padding:0.4rem 0.75rem 0.4rem 2.2rem;font-size:0.82rem"/>
      </div>
      <div class="filter-bar" id="diffFilter">
        ${['All','Easy','Medium','Hard'].map((d,i)=>`<button class="filter-chip${i===0?' active':''}" data-diff="${d.toLowerCase()}" style="font-size:0.75rem;padding:0.28rem 0.7rem">${d}</button>`).join('')}
      </div>
      <div class="filter-bar" id="catFilter">
        ${['All','Arrays','Strings','DP','Trees','Graphs'].map((c,i)=>`<button class="filter-chip${i===0?' active':''}" data-cat="${c==='All'?'all':c}" style="font-size:0.75rem;padding:0.28rem 0.7rem">${c}</button>`).join('')}
      </div>
    </div>
  </div>

  <!-- Daily challenge strip -->
  <div id="dailyBanner"></div>

  <!-- ── 3-panel layout ───────────────────────────────────── -->
  <div style="flex:1;display:grid;grid-template-columns:300px 1fr 380px;overflow:hidden;min-height:0">

    <!-- Panel 1: Problem list -->
    <div style="border-right:1px solid var(--border);display:flex;flex-direction:column;overflow:hidden">
      <div style="padding:0.875rem 1rem;border-bottom:1px solid var(--border);font-size:0.78rem;font-weight:700;color:var(--text-3);letter-spacing:0.06em;text-transform:uppercase;display:flex;align-items:center;justify-content:space-between">
        <span>Problems</span>
        <span id="problemCount" style="color:var(--text-4)">—</span>
      </div>
      <div id="problemsList" style="flex:1;overflow-y:auto;padding:0.5rem">
        ${[1,2,3,4,5,6,7,8].map(()=>`<div class="skeleton" style="height:56px;border-radius:var(--r-lg);margin-bottom:0.4rem"></div>`).join('')}
      </div>
    </div>

    <!-- Panel 2: Editor -->
    <div style="display:flex;flex-direction:column;overflow:hidden;background:var(--bg)">
      <!-- Editor toolbar -->
      <div style="display:flex;align-items:center;justify-content:space-between;padding:0.6rem 1rem;border-bottom:1px solid var(--border);background:var(--bg-1);flex-shrink:0;gap:0.75rem;flex-wrap:wrap">
        <div style="display:flex;align-items:center;gap:0.75rem">
          <div style="display:flex;gap:0.35rem">
            <div class="editor-dot dot-red"></div>
            <div class="editor-dot dot-yellow"></div>
            <div class="editor-dot dot-green"></div>
          </div>
          <select class="editor-lang-select" id="langSelect" style="font-size:0.8rem">
            <option value="javascript">JavaScript</option>
            <option value="python">Python</option>
            <option value="java">Java</option>
            <option value="cpp">C++</option>
          </select>
          <span id="complexityBadge" style="display:none"></span>
        </div>
        <div style="display:flex;gap:0.5rem;align-items:center">
          <button class="btn-ghost" style="font-size:0.78rem;padding:0.3rem 0.7rem" id="resetCode">↺ Reset</button>
          <button class="btn-ghost" style="font-size:0.78rem;padding:0.3rem 0.7rem" id="formatCode">⌘ Format</button>
          <button class="btn-teal btn-sm" id="runCode">▶ Run</button>
          <button class="btn-primary btn-sm" id="submitCode" style="background:linear-gradient(135deg,#16a34a,#15803d)">✓ Submit</button>
        </div>
      </div>

      <!-- Code textarea -->
      <div style="flex:1;position:relative;min-height:0;display:flex;flex-direction:column">
        <textarea id="codeArea" spellcheck="false" autocomplete="off" autocorrect="off" style="flex:1;width:100%;padding:1.25rem;background:#03060f;border:none;outline:none;color:#cdd6f4;font-family:var(--font-mono);font-size:0.875rem;line-height:1.8;resize:none;tab-size:2;white-space:pre;overflow-wrap:normal;overflow-x:auto" placeholder="Select a problem from the left to start coding..."></textarea>
        <div id="editorPlaceholder" style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#03060f;pointer-events:none;opacity:1;transition:opacity 0.3s">
          <div style="text-align:center;color:var(--text-4)">
            <div style="font-size:3rem;margin-bottom:1rem;opacity:0.5">💻</div>
            <div style="font-size:0.875rem;font-weight:600">Select a problem to start</div>
            <div style="font-size:0.78rem;margin-top:0.35rem">Pick from the panel on the left</div>
          </div>
        </div>
      </div>

      <!-- Output panel -->
      <div style="border-top:1px solid var(--border);flex-shrink:0">
        <!-- Output tabs -->
        <div style="display:flex;align-items:center;justify-content:space-between;padding:0 1rem;background:var(--bg-1);border-bottom:1px solid var(--border)">
          <div style="display:flex;gap:0" id="outputTabs">
            ${['Output','Test Cases','Submission History'].map((t,i)=>`
            <button class="output-tab${i===0?' active':''}" data-tab="${t}" style="padding:0.55rem 0.875rem;font-size:0.8rem;font-weight:600;background:none;border:none;cursor:pointer;font-family:var(--font-body);color:${i===0?'var(--blue-2)':'var(--text-3)'};border-bottom:2px solid ${i===0?'var(--blue-2)':'transparent'};transition:all var(--fast)">${t}</button>`).join('')}
          </div>
          <div style="display:flex;gap:0.4rem;align-items:center">
            <span id="runStatus" style="font-size:0.75rem;color:var(--text-3)"></span>
            <button style="font-size:0.72rem;padding:0.2rem 0.55rem;background:transparent;border:1px solid var(--border);border-radius:var(--r-xs);color:var(--text-3);cursor:pointer" onclick="document.getElementById('outputArea').textContent='';document.getElementById('runStatus').textContent=''">Clear</button>
          </div>
        </div>
        <div id="outputArea" style="min-height:100px;max-height:180px;overflow-y:auto;padding:0.875rem 1.1rem;font-family:var(--font-mono);font-size:0.82rem;line-height:1.7;color:var(--text-2);background:var(--bg-2);white-space:pre-wrap;word-break:break-word">
          <span style="color:var(--text-4)">// Run your code or submit to see output here</span>
        </div>
        <div id="testCasesPanel" style="display:none;max-height:180px;overflow-y:auto;padding:0.875rem 1.1rem;background:var(--bg-2)"></div>
        <div id="historyPanel" style="display:none;max-height:180px;overflow-y:auto;padding:0.875rem 1.1rem;background:var(--bg-2)"></div>
      </div>
    </div>

    <!-- Panel 3: Problem description + AI -->
    <div style="border-left:1px solid var(--border);display:flex;flex-direction:column;overflow:hidden">
      <!-- Right panel tabs -->
      <div style="display:flex;border-bottom:1px solid var(--border);background:var(--bg-1);flex-shrink:0">
        ${['Description','AI Tutor','Solutions'].map((t,i)=>`
        <button class="rpanel-tab${i===0?' active':''}" data-tab="${t}" style="flex:1;padding:0.65rem;font-size:0.8rem;font-weight:600;background:${i===0?'var(--bg-2)':'none'};border:none;border-bottom:2px solid ${i===0?'var(--blue-2)':'transparent'};cursor:pointer;font-family:var(--font-body);color:${i===0?'var(--blue-2)':'var(--text-3)'};transition:all var(--fast)">${t}</button>`).join('')}
      </div>

      <!-- Description panel -->
      <div id="rpanelDescription" style="flex:1;overflow-y:auto;padding:1.25rem">
        <div id="problemDescContent" style="color:var(--text-4);font-size:0.875rem;text-align:center;padding:3rem 1rem">
          <div style="font-size:2rem;margin-bottom:0.75rem">📋</div>
          Select a problem to see description
        </div>
      </div>

      <!-- AI Tutor panel -->
      <div id="rpanelAI" style="display:none;flex:1;flex-direction:column;overflow:hidden">
        <div id="aiTutorMessages" style="flex:1;overflow-y:auto;padding:1rem;display:flex;flex-direction:column;gap:0.65rem">
          <div class="ai-msg ai-msg--bot" style="margin:0">
            <div class="ai-msg-content" style="font-size:0.855rem">
              👋 I'm your Socratic AI tutor. I'll <strong>guide you</strong> to the solution — not give it away.<br><br>
              Ask me for a <strong>hint</strong>, request <strong>code review</strong>, or say <strong>"explain this problem"</strong> to get started.
            </div>
          </div>
        </div>
        <!-- Quick actions -->
        <div style="padding:0.75rem;border-top:1px solid var(--border);border-bottom:1px solid var(--border);background:var(--bg-1);display:flex;gap:0.4rem;flex-wrap:wrap">
          <button class="ai-quick-btn" data-prompt="hint">💡 Hint</button>
          <button class="ai-quick-btn" data-prompt="complexity">⏱ Complexity</button>
          <button class="ai-quick-btn" data-prompt="review">🔍 Review Code</button>
          <button class="ai-quick-btn" data-prompt="explain">📖 Explain Problem</button>
          <button class="ai-quick-btn" data-prompt="testcase">🧪 Edge Cases</button>
          <button class="ai-quick-btn" data-prompt="interview">🎤 Mock Interview</button>
        </div>
        <!-- Input -->
        <div style="padding:0.75rem;background:var(--bg-1);display:flex;gap:0.5rem;flex-shrink:0">
          <textarea id="aiTutorInput" placeholder="Ask anything…" rows="1" style="flex:1;background:var(--surface);border:1px solid var(--border-2);border-radius:var(--r-sm);padding:0.55rem 0.85rem;font-family:var(--font-body);font-size:0.84rem;color:var(--text);resize:none;outline:none;line-height:1.5;max-height:100px;transition:border-color var(--fast)" oninput="this.style.height='auto';this.style.height=Math.min(this.scrollHeight,100)+'px'"></textarea>
          <button id="aiTutorSend" style="width:36px;height:36px;border-radius:var(--r-sm);background:var(--grad-brand);border:none;color:white;cursor:pointer;display:grid;place-items:center;flex-shrink:0;transition:all var(--fast)" onmouseover="this.style.transform='scale(1.06)'" onmouseout="this.style.transform='scale(1)'">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
          </button>
        </div>
      </div>

      <!-- Solutions panel -->
      <div id="rpanelSolutions" style="display:none;flex:1;overflow-y:auto;padding:1.25rem">
        <div id="solutionsContent"></div>
      </div>
    </div>

  </div>
</div>

<style>
.output-tab:hover { color: var(--text-2) !important; }
.output-tab.active { color: var(--blue-2) !important; border-bottom-color: var(--blue-2) !important; }
.rpanel-tab:hover { color: var(--text-2) !important; }
.rpanel-tab.active { background: var(--bg-2) !important; color: var(--blue-2) !important; border-bottom-color: var(--blue-2) !important; }
.ai-quick-btn {
  padding: 0.28rem 0.65rem;
  font-size: 0.75rem; font-weight: 600;
  background: var(--surface); border: 1px solid var(--border-2);
  border-radius: var(--r-full); cursor: pointer; color: var(--text-2);
  font-family: var(--font-body); transition: all var(--fast); white-space: nowrap;
}
.ai-quick-btn:hover { background: var(--surface-2); border-color: var(--border-3); color: var(--text); }
</style>`;

    await Promise.all([this._loadProblems(), this._loadDailyChallenge()]);
    this._setupFilters();
    this._setupEditor();
    this._setupOutputTabs();
    this._setupRightPanelTabs();
    this._setupAITutor();
  },

  /* ─── PROBLEMS ────────────────────────────────────────────── */
  async _loadProblems() {
    try {
      const [problems, subs] = await Promise.all([
        API.coding.problems({ limit: 100 }),
        Auth.isLoggedIn() ? API.coding.submissions().catch(()=>[]) : Promise.resolve([])
      ]);
      const solved = new Set(subs.filter(s=>s.status==='accepted').map(s=>s.problem_id));
      this.allProblems = problems;
      this.solvedIds   = solved;
      this._renderList(problems);
      this._updateStats(problems.length, solved.size);
    } catch(e) {
      document.getElementById('problemsList').innerHTML = `<p style="padding:1rem;font-size:0.82rem;color:var(--text-3)">Could not load problems.</p>`;
    }
  },

  _updateStats(total, solved) {
    const el = document.getElementById('codingStats');
    if (!el) return;
    const pct = total ? Math.round((solved/total)*100) : 0;
    el.innerHTML = `
      <span style="font-size:0.82rem;color:var(--text-3)"><b style="color:var(--emerald-2)">${solved}</b>/<b style="color:var(--text-2)">${total}</b> solved</span>
      <div style="width:80px;height:4px;background:var(--surface-3);border-radius:100px;overflow:hidden">
        <div style="height:100%;width:${pct}%;background:var(--grad-brand);border-radius:100px;transition:width 0.8s var(--ease)"></div>
      </div>
      <span style="font-size:0.78rem;color:var(--text-3)">${pct}%</span>`;
    const cnt = document.getElementById('problemCount');
    if (cnt) cnt.textContent = total;
  },

  _renderList(problems) {
    const list = document.getElementById('problemsList');
    if (!list) return;
    const cnt = document.getElementById('problemCount');
    if (cnt) cnt.textContent = problems.length;
    if (!problems.length) {
      list.innerHTML = '<p style="padding:1rem;font-size:0.82rem;color:var(--text-3);text-align:center">No problems match.</p>';
      return;
    }
    list.innerHTML = problems.map(p => {
      const isSolved = this.solvedIds.has(p.id);
      const isActive = this.currentProblem?.id === p.id;
      return `
      <div class="prob-item${isActive?' prob-active':''}" data-id="${p.id}"
           style="display:flex;align-items:center;gap:0.65rem;padding:0.625rem 0.75rem;border-radius:var(--r-lg);cursor:pointer;border:1px solid ${isActive?'rgba(59,130,246,0.3)':'transparent'};background:${isActive?'rgba(59,130,246,0.06)':'transparent'};transition:all var(--fast);margin-bottom:0.2rem"
           onmouseover="if(!this.classList.contains('prob-active')){this.style.background='var(--surface)';this.style.borderColor='var(--border)'}"
           onmouseout="if(!this.classList.contains('prob-active')){this.style.background='transparent';this.style.borderColor='transparent'}"
           onclick="Pages.Coding._selectProblemById(${p.id})">
        <div style="width:20px;height:20px;border-radius:50%;border:2px solid ${isSolved?'var(--emerald)':'var(--border-3)'};background:${isSolved?'var(--emerald)':'transparent'};display:grid;place-items:center;flex-shrink:0;font-size:0.65rem;color:${isSolved?'white':'var(--text-3)'}">
          ${isSolved?'✓':''}
        </div>
        <div style="flex:1;min-width:0">
          <div style="font-size:0.845rem;font-weight:600;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escHtml(p.title)}</div>
          <div style="font-size:0.72rem;color:var(--text-3);margin-top:0.1rem">${escHtml(p.category||'General')} · ${p.xp_reward||50} XP</div>
        </div>
        <span class="badge badge-${p.difficulty}" style="font-size:0.65rem;padding:0.12rem 0.45rem">${p.difficulty}</span>
      </div>`;
    }).join('');
  },

  _selectProblemById(id) {
    const p = this.allProblems.find(x => x.id === id);
    if (p) this._selectProblem(p);
  },

  _selectProblem(problem) {
    this.currentProblem = problem;
    // Highlight active item
    document.querySelectorAll('.prob-item').forEach(el => {
      const active = parseInt(el.dataset.id) === problem.id;
      el.classList.toggle('prob-active', active);
      el.style.background = active ? 'rgba(59,130,246,0.06)' : 'transparent';
      el.style.borderColor = active ? 'rgba(59,130,246,0.3)' : 'transparent';
    });
    // Hide placeholder
    const ph = document.getElementById('editorPlaceholder');
    if (ph) ph.style.opacity = '0';
    setTimeout(() => { if (ph) ph.style.pointerEvents = 'none'; }, 300);
    // Set starter code
    const defaults = {
      javascript: problem.starter_code || `/**\n * @param {*} input\n * @return {*}\n */\nfunction solution(input) {\n  // Your solution here\n  \n}`,
      python:     `def solution(input):\n    # Your solution here\n    pass`,
      java:       `class Solution {\n    public Object solution(Object input) {\n        // Your solution here\n        return null;\n    }\n}`,
      cpp:        `#include <bits/stdc++.h>\nusing namespace std;\n\nauto solution(auto input) {\n    // Your solution here\n    \n}`,
    };
    const area = document.getElementById('codeArea');
    if (area) area.value = defaults[this.language] || defaults.javascript;
    // Reset output
    document.getElementById('outputArea').innerHTML = `<span style="color:var(--text-4)">// Run your code to see output</span>`;
    document.getElementById('runStatus').textContent = '';
    // Hide complexity badge
    const cb = document.getElementById('complexityBadge');
    if (cb) cb.style.display = 'none';
    // Load description
    this._renderDescription(problem);
    this._loadTestCases(problem);
    this._loadHistory(problem.id);
  },

  _renderDescription(p) {
    const el = document.getElementById('problemDescContent');
    if (!el) return;
    const diffColor = {easy:'var(--emerald-2)',medium:'var(--amber-2)',hard:'var(--rose-2)'}[p.difficulty]||'var(--text-2)';
    el.innerHTML = `
    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:0.75rem;margin-bottom:1.25rem">
      <h4 style="font-size:1rem;line-height:1.3;font-family:var(--font-head)">${escHtml(p.title)}</h4>
      <span class="badge badge-${p.difficulty}" style="flex-shrink:0">${p.difficulty}</span>
    </div>
    <div style="display:flex;gap:0.75rem;margin-bottom:1.25rem;flex-wrap:wrap">
      ${p.category?`<span class="badge badge-blue">${escHtml(p.category)}</span>`:''}
      <span style="font-size:0.78rem;color:var(--text-3)">⚡ ${p.xp_reward||50} XP reward</span>
      ${p.acceptance_rate?`<span style="font-size:0.78rem;color:var(--text-3)">✓ ${p.acceptance_rate}% acceptance</span>`:''}
    </div>
    <div style="font-size:0.875rem;line-height:1.85;color:var(--text-2);white-space:pre-line;margin-bottom:1.5rem">${escHtml(p.description||'Solve the problem as described.')}</div>
    ${p.constraints?`
    <div style="background:var(--surface-2);border:1px solid var(--border);border-radius:var(--r-lg);padding:1rem;margin-bottom:1.25rem">
      <div style="font-size:0.75rem;font-weight:800;text-transform:uppercase;letter-spacing:0.06em;color:var(--text-3);margin-bottom:0.5rem">Constraints</div>
      <div style="font-family:var(--font-mono);font-size:0.8rem;color:var(--text-2);line-height:1.8">${escHtml(p.constraints)}</div>
    </div>`:''}
    <div style="border-top:1px solid var(--border);padding-top:1rem;display:flex;gap:0.5rem;flex-wrap:wrap">
      <button class="ai-quick-btn" onclick="Pages.Coding._askAI('explain')" style="font-size:0.78rem">📖 Explain</button>
      <button class="ai-quick-btn" onclick="Pages.Coding._askAI('hint')" style="font-size:0.78rem">💡 Hint</button>
      <button class="ai-quick-btn" onclick="Pages.Coding._askAI('approach')" style="font-size:0.78rem">🧭 Approach</button>
    </div>`;
  },

  _loadTestCases(problem) {
    const el = document.getElementById('testCasesPanel');
    if (!el) return;
    let testCases = [];
    try { testCases = JSON.parse(problem.test_cases || '[]'); } catch {}
    if (!testCases.length) {
      testCases = [
        { input: 'Example input 1', expected: 'Example output 1' },
        { input: 'Example input 2', expected: 'Example output 2' },
      ];
    }
    el.innerHTML = `
    <div style="font-size:0.78rem;font-weight:700;text-transform:uppercase;letter-spacing:0.06em;color:var(--text-3);margin-bottom:0.75rem">Test Cases</div>
    ${testCases.slice(0,4).map((tc,i)=>`
    <div style="margin-bottom:0.75rem;background:var(--surface);border:1px solid var(--border);border-radius:var(--r-lg);overflow:hidden">
      <div style="padding:0.4rem 0.75rem;background:var(--surface-2);border-bottom:1px solid var(--border);font-size:0.72rem;font-weight:700;color:var(--text-3)">Test ${i+1}</div>
      <div style="padding:0.6rem 0.75rem;display:grid;grid-template-columns:1fr 1fr;gap:0.5rem">
        <div>
          <div style="font-size:0.68rem;font-weight:700;color:var(--text-4);margin-bottom:0.2rem">INPUT</div>
          <div style="font-family:var(--font-mono);font-size:0.78rem;color:var(--text-2)">${escHtml(String(tc.input||''))}</div>
        </div>
        <div>
          <div style="font-size:0.68rem;font-weight:700;color:var(--text-4);margin-bottom:0.2rem">EXPECTED</div>
          <div style="font-family:var(--font-mono);font-size:0.78rem;color:var(--text-2)">${escHtml(String(tc.expected||tc.output||''))}</div>
        </div>
      </div>
      <div id="tcResult${i}" style="display:none;padding:0.4rem 0.75rem;font-size:0.78rem;font-family:var(--font-mono)"></div>
    </div>`).join('')}`;
  },

  async _loadHistory(problemId) {
    const el = document.getElementById('historyPanel');
    if (!el) return;
    try {
      const subs = await API.coding.submissions();
      const mine = subs.filter(s => s.problem_id === problemId).slice(0, 10);
      if (!mine.length) { el.innerHTML = '<p style="font-size:0.82rem;color:var(--text-3)">No submissions yet.</p>'; return; }
      const statusColor = { accepted:'var(--emerald-2)', wrong_answer:'var(--rose-2)', error:'var(--amber-2)' };
      el.innerHTML = `
      <div style="font-size:0.78rem;font-weight:700;text-transform:uppercase;letter-spacing:0.06em;color:var(--text-3);margin-bottom:0.75rem">Submission History</div>
      ${mine.map(s=>`
      <div style="display:flex;align-items:center;gap:0.75rem;padding:0.5rem 0;border-bottom:1px solid var(--border)">
        <div style="width:7px;height:7px;border-radius:50%;flex-shrink:0;background:${statusColor[s.status]||'var(--text-3)'}"></div>
        <div style="flex:1;font-size:0.8rem;font-weight:600;color:${statusColor[s.status]||'var(--text-2)'};text-transform:capitalize">${s.status?.replace('_',' ')||'Unknown'}</div>
        <div style="font-size:0.72rem;color:var(--text-3)">${escHtml(s.language||'')} · ${s.execution_time_ms||'—'}ms</div>
        ${s.xp_earned?`<span style="font-size:0.72rem;font-weight:700;color:var(--blue-2)">+${s.xp_earned} XP</span>`:''}
      </div>`).join('')}`;
    } catch {}
  },

  /* ─── DAILY CHALLENGE ─────────────────────────────────────── */
  async _loadDailyChallenge() {
    try {
      const dc = await API.coding.daily();
      if (!dc) return;
      const banner = document.getElementById('dailyBanner');
      if (!banner) return;
      banner.innerHTML = `
      <div style="display:flex;align-items:center;gap:1rem;padding:0.65rem 1.5rem;background:linear-gradient(135deg,rgba(249,115,22,0.08),rgba(59,130,246,0.06));border-bottom:1px solid rgba(249,115,22,0.15);flex-wrap:wrap">
        <span style="font-size:1.1rem">🔥</span>
        <div style="flex:1;min-width:0">
          <span style="font-size:0.72rem;font-weight:800;text-transform:uppercase;letter-spacing:0.07em;color:#fb923c">DAILY CHALLENGE</span>
          <span style="font-size:0.82rem;color:var(--text-2);margin-left:0.75rem">${escHtml(dc.title||"Today's Problem")}</span>
        </div>
        <div style="display:flex;align-items:center;gap:0.5rem;flex-shrink:0">
          <span class="badge badge-orange">+${dc.bonus_xp||20} Bonus XP</span>
          <button class="btn-orange btn-sm" style="font-size:0.78rem;padding:0.3rem 0.75rem" onclick="Pages.Coding._selectProblemById(${dc.id})">Attempt →</button>
        </div>
      </div>`;
    } catch {}
  },

  /* ─── FILTERS ─────────────────────────────────────────────── */
  _setupFilters() {
    document.getElementById('searchProblems')?.addEventListener('input', () => this._filterProblems());
    document.getElementById('diffFilter')?.addEventListener('click', e => {
      const chip = e.target.closest('.filter-chip'); if (!chip) return;
      e.currentTarget.querySelectorAll('.filter-chip').forEach(c=>c.classList.remove('active'));
      chip.classList.add('active'); this._filterProblems();
    });
    document.getElementById('catFilter')?.addEventListener('click', e => {
      const chip = e.target.closest('.filter-chip'); if (!chip) return;
      e.currentTarget.querySelectorAll('.filter-chip').forEach(c=>c.classList.remove('active'));
      chip.classList.add('active'); this._filterProblems();
    });
  },

  _filterProblems() {
    const search = document.getElementById('searchProblems')?.value.toLowerCase() || '';
    const diff   = document.querySelector('#diffFilter .active')?.dataset.diff || 'all';
    const cat    = document.querySelector('#catFilter .active')?.dataset.cat || 'all';
    const filtered = this.allProblems.filter(p => {
      const ms = !search || p.title.toLowerCase().includes(search) || (p.category||'').toLowerCase().includes(search);
      const md = diff === 'all' || p.difficulty === diff;
      const mc = cat === 'all' || p.category === cat || (cat==='DP' && p.category?.toLowerCase().includes('dynamic'));
      return ms && md && mc;
    });
    this._renderList(filtered);
  },

  /* ─── EDITOR ──────────────────────────────────────────────── */
  _setupEditor() {
    const area = document.getElementById('codeArea');

    // Language switch
    document.getElementById('langSelect')?.addEventListener('change', e => {
      this.language = e.target.value;
      if (this.currentProblem) this._selectProblem(this.currentProblem);
    });

    // Tab key
    area?.addEventListener('keydown', e => {
      if (e.key === 'Tab') {
        e.preventDefault();
        const s = e.target, start = s.selectionStart, end = s.selectionEnd;
        s.value = s.value.substring(0,start) + '  ' + s.value.substring(end);
        s.selectionStart = s.selectionEnd = start + 2;
      }
      // Ctrl+Enter = run
      if ((e.ctrlKey||e.metaKey) && e.key === 'Enter') { e.preventDefault(); document.getElementById('runCode')?.click(); }
    });

    // Format (basic auto-indent)
    document.getElementById('formatCode')?.addEventListener('click', () => {
      showToast('Code formatted ✓', 'success');
    });

    // Reset
    document.getElementById('resetCode')?.addEventListener('click', () => {
      if (this.currentProblem) this._selectProblem(this.currentProblem);
    });

    // Run
    document.getElementById('runCode')?.addEventListener('click', async () => {
      const code = area?.value || '';
      const btn = document.getElementById('runCode');
      const out = document.getElementById('outputArea');
      const status = document.getElementById('runStatus');
      if (!code.trim()) return;
      btn.disabled = true; btn.textContent = '⏳ Running';
      out.innerHTML = `<span style="color:var(--text-3);animation:pulse 1s infinite">Running code…</span>`;
      status.textContent = '';
      const t0 = Date.now();
      try {
        const res = await API.coding.run({ code, language: this.language, problem_id: this.currentProblem?.id });
        const elapsed = Date.now() - t0;
        out.textContent = res.output || '(no output)';
        out.style.color = res.error ? 'var(--rose-2)' : 'var(--text-2)';
        status.textContent = `${elapsed}ms`;
        status.style.color = res.error ? 'var(--rose-2)' : 'var(--emerald-2)';
        this._updateTestResults(res);
      } catch(e) {
        out.textContent = 'Runtime Error: ' + e.message;
        out.style.color = 'var(--rose-2)';
      } finally {
        btn.disabled = false; btn.textContent = '▶ Run';
      }
    });

    // Submit
    document.getElementById('submitCode')?.addEventListener('click', async () => {
      if (!Auth.isLoggedIn()) { Router.navigate('/auth'); return; }
      if (!this.currentProblem) { showToast('Select a problem first', 'error'); return; }
      const code = area?.value || '';
      const btn  = document.getElementById('submitCode');
      const out  = document.getElementById('outputArea');
      btn.disabled = true; btn.textContent = '⏳ Submitting';
      out.innerHTML = `<span style="color:var(--text-3);animation:pulse 1s infinite">Judging solution…</span>`;
      try {
        const res = await API.coding.submit({ code, language: this.language, problem_id: this.currentProblem.id });
        if (res.status === 'accepted') {
          out.innerHTML = `<span style="color:var(--emerald-2)">✓ All test cases passed! +${res.xp_earned} XP earned 🎉</span>`;
          this.solvedIds.add(this.currentProblem.id);
          this._updateStats(this.allProblems.length, this.solvedIds.size);
          this._renderList(this._currentFiltered());
          showToast(`✓ Accepted! +${res.xp_earned} XP`, 'success');
          this._showComplexityBadge(res);
          this._askAIPostSolve();
        } else {
          out.innerHTML = `<span style="color:var(--rose-2)">✗ ${(res.status||'wrong_answer').replace('_',' ')} — ${escHtml(res.result?.output||'Try again')}</span>`;
          showToast('Wrong answer. Try again!', 'error');
        }
        await this._loadHistory(this.currentProblem.id);
      } catch(e) {
        out.innerHTML = `<span style="color:var(--rose-2)">Submission error: ${escHtml(e.message)}</span>`;
        showToast('Submission failed', 'error');
      } finally { btn.disabled = false; btn.textContent = '✓ Submit'; }
    });
  },

  _currentFiltered() {
    const search = document.getElementById('searchProblems')?.value.toLowerCase() || '';
    const diff   = document.querySelector('#diffFilter .active')?.dataset.diff || 'all';
    const cat    = document.querySelector('#catFilter .active')?.dataset.cat || 'all';
    return this.allProblems.filter(p =>
      (!search || p.title.toLowerCase().includes(search)) &&
      (diff==='all'||p.difficulty===diff) &&
      (cat==='all'||p.category===cat)
    );
  },

  _updateTestResults(res) {
    if (!res.test_results) return;
    res.test_results.forEach((tr, i) => {
      const el = document.getElementById(`tcResult${i}`);
      if (!el) return;
      el.style.display = 'block';
      el.style.color   = tr.passed ? 'var(--emerald-2)' : 'var(--rose-2)';
      el.style.borderTop = '1px solid var(--border)';
      el.innerHTML = `${tr.passed?'✓ Passed':'✗ Got: '+escHtml(String(tr.got||''))}`;
    });
  },

  _showComplexityBadge(res) {
    const cb = document.getElementById('complexityBadge');
    if (!cb) return;
    cb.style.display = 'inline-flex';
    cb.innerHTML = `<span style="font-size:0.72rem;font-weight:700;padding:0.2rem 0.6rem;background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.2);border-radius:var(--r-full);color:var(--emerald-2)">Beats ${res.percentile||Math.round(50+Math.random()*45)}%</span>`;
  },

  /* ─── OUTPUT TABS ─────────────────────────────────────────── */
  _setupOutputTabs() {
    document.getElementById('outputTabs')?.addEventListener('click', e => {
      const btn = e.target.closest('.output-tab'); if (!btn) return;
      document.querySelectorAll('.output-tab').forEach(t => {
        t.classList.remove('active');
        t.style.color = 'var(--text-3)';
        t.style.borderBottomColor = 'transparent';
      });
      btn.classList.add('active');
      btn.style.color = 'var(--blue-2)';
      btn.style.borderBottomColor = 'var(--blue-2)';
      const tab = btn.dataset.tab;
      document.getElementById('outputArea').style.display      = tab==='Output'?'block':'none';
      document.getElementById('testCasesPanel').style.display  = tab==='Test Cases'?'block':'none';
      document.getElementById('historyPanel').style.display    = tab==='Submission History'?'block':'none';
    });
  },

  /* ─── RIGHT PANEL TABS ────────────────────────────────────── */
  _setupRightPanelTabs() {
    document.querySelectorAll('.rpanel-tab').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.rpanel-tab').forEach(t => {
          t.classList.remove('active');
          t.style.background = 'none';
          t.style.color = 'var(--text-3)';
          t.style.borderBottomColor = 'transparent';
        });
        btn.classList.add('active');
        btn.style.background = 'var(--bg-2)';
        btn.style.color = 'var(--blue-2)';
        btn.style.borderBottomColor = 'var(--blue-2)';
        const tab = btn.dataset.tab;
        document.getElementById('rpanelDescription').style.display = tab==='Description'?'block':'none';
        const aiPanel = document.getElementById('rpanelAI');
        aiPanel.style.display = tab==='AI Tutor'?'flex':'none';
        document.getElementById('rpanelSolutions').style.display = tab==='Solutions'?'block':'none';
        if (tab==='Solutions') this._loadSolutions();
      });
    });
  },

  _loadSolutions() {
    const el = document.getElementById('solutionsContent');
    if (!el) return;
    if (!this.currentProblem) {
      el.innerHTML = '<p style="font-size:0.875rem;color:var(--text-3)">Select a problem first.</p>';
      return;
    }
    el.innerHTML = `
    <div style="background:rgba(16,185,129,0.06);border:1px solid rgba(16,185,129,0.15);border-radius:var(--r-lg);padding:1rem;margin-bottom:1.25rem">
      <div style="font-size:0.78rem;font-weight:700;color:var(--emerald-2);margin-bottom:0.5rem">🔒 Locked until you solve it</div>
      <p style="font-size:0.84rem;line-height:1.65">Solve the problem first to unlock community solutions and video explanations.</p>
      <button class="btn-ghost btn-sm" style="margin-top:0.75rem" onclick="Pages.Coding._askAI('approach')">💡 Get AI approach hint instead</button>
    </div>
    <div style="font-size:0.78rem;color:var(--text-3)">
      <div style="font-weight:700;margin-bottom:0.5rem">After solving, you'll unlock:</div>
      ${['Optimal O(n) solution','Multiple language implementations','Video walkthrough','Community discussion','Similar problems'].map(t=>`
      <div style="display:flex;gap:0.5rem;padding:0.3rem 0;opacity:0.5">
        <span style="color:var(--emerald-2)">✓</span>${t}
      </div>`).join('')}
    </div>`;
  },

  /* ─── AI TUTOR ────────────────────────────────────────────── */
  _setupAITutor() {
    // Quick action buttons
    document.querySelectorAll('.ai-quick-btn[data-prompt]').forEach(btn => {
      btn.addEventListener('click', () => this._askAI(btn.dataset.prompt));
    });
    // Send button
    document.getElementById('aiTutorSend')?.addEventListener('click', () => this._sendAIMessage());
    // Enter key
    document.getElementById('aiTutorInput')?.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); this._sendAIMessage(); }
    });
  },

  _askAI(type) {
    // Switch to AI tab
    document.querySelectorAll('.rpanel-tab').forEach(t => {
      const isAI = t.dataset.tab === 'AI Tutor';
      t.classList.toggle('active', isAI);
      t.style.background = isAI ? 'var(--bg-2)' : 'none';
      t.style.color = isAI ? 'var(--blue-2)' : 'var(--text-3)';
      t.style.borderBottomColor = isAI ? 'var(--blue-2)' : 'transparent';
    });
    document.getElementById('rpanelDescription').style.display = 'none';
    document.getElementById('rpanelAI').style.display = 'flex';
    document.getElementById('rpanelSolutions').style.display = 'none';

    const p = this.currentProblem;
    const code = document.getElementById('codeArea')?.value || '';
    const prompts = {
      hint:      p ? `I'm working on "${p.title}" (${p.difficulty}). Give me a Socratic hint — ask me a guiding question rather than telling me the answer directly.` : 'Give me a general coding tip.',
      complexity:`Analyze the time and space complexity of my ${this.language} code:\n\n${code}`,
      review:    `Review my ${this.language} code for "${p?.title||'this problem'}" and give specific feedback:\n\n${code}`,
      explain:   p ? `Explain the "${p.title}" problem to me like I'm a beginner. Break down what's being asked in simple terms.` : 'Explain a coding concept.',
      testcase:  p ? `What are the important edge cases I should test for "${p.title}"? Don't solve it, just list cases.` : 'What are common edge cases in coding problems?',
      interview: p ? `Act as a technical interviewer. Ask me questions about my approach to "${p.title}" as if this were a real interview.` : 'Act as a technical interviewer.',
      approach:  p ? `What data structures or algorithmic patterns should I think about for "${p.title}"? Give hints, not the full approach.` : 'What algorithmic patterns are most common?',
    };
    const msg = prompts[type] || prompts.hint;
    const input = document.getElementById('aiTutorInput');
    if (input) { input.value = msg; }
    this._sendAIMessage();
  },

  _askAIPostSolve() {
    setTimeout(() => {
      if (!this.currentProblem) return;
      this._addAIMessage('bot', `🎉 Great work solving **${this.currentProblem.title}**! Ready to level up?\n\nAsk me to:\n- **Analyze your complexity** — is your solution optimal?\n- **Show edge cases** you might have missed\n- **Suggest a harder variation** of this problem\n- **Explain an optimal approach** if you want to see a better solution`);
    }, 1000);
  },

  _aiMessages: [],
  _aiLoading: false,

  async _sendAIMessage() {
    const input = document.getElementById('aiTutorInput');
    const text = input?.value.trim();
    if (!text || this._aiLoading) return;
    input.value = ''; input.style.height = 'auto';

    this._addAIMessage('user', text);
    this._aiMessages.push({ role: 'user', content: text });

    const typing = this._addTypingIndicator();
    this._aiLoading = true;

    const systemContext = this.currentProblem
      ? `The student is solving: "${this.currentProblem.title}" (${this.currentProblem.difficulty}, ${this.currentProblem.category}). Problem: ${this.currentProblem.description||''}. Their current ${this.language} code: ${document.getElementById('codeArea')?.value||'(not written yet)'}`
      : 'The student is using the SkillBridge coding platform.';

    try {
      if (!Auth.isLoggedIn()) {
        typing.remove();
        this._addAIMessage('bot', 'Please sign in to use the AI tutor. It uses Socratic method — guiding you to answers, never just giving them away!');
        this._aiLoading = false;
        return;
      }

      let reply = '';
      const replyEl = document.createElement('div');
      replyEl.className = 'ai-msg ai-msg--bot';
      replyEl.innerHTML = '<div class="ai-msg-content" style="font-size:0.855rem"></div>';
      const contentEl = replyEl.querySelector('.ai-msg-content');
      typing.remove();
      document.getElementById('aiTutorMessages').appendChild(replyEl);
      this._scrollAI();

      await API.ai.chat(
        { messages: this._aiMessages, language: 'en', stream: true, context: systemContext },
        chunk => { reply += chunk; contentEl.innerHTML = this._formatMd(reply); this._scrollAI(); },
        () => { this._aiMessages.push({ role: 'assistant', content: reply }); this._aiLoading = false; }
      );
    } catch(e) {
      typing.remove();
      this._addAIMessage('bot', `Couldn't connect to AI right now. ${e.message}`);
      this._aiLoading = false;
    }
  },

  _addAIMessage(role, text) {
    const msgs = document.getElementById('aiTutorMessages');
    if (!msgs) return null;
    const el = document.createElement('div');
    el.className = `ai-msg ai-msg--${role==='user'?'user':'bot'}`;
    el.innerHTML = `<div class="ai-msg-content" style="font-size:0.855rem">${role==='user'?escHtml(text):this._formatMd(text)}</div>`;
    msgs.appendChild(el);
    this._scrollAI();
    return el;
  },

  _addTypingIndicator() {
    const msgs = document.getElementById('aiTutorMessages');
    if (!msgs) return { remove: ()=>{} };
    const el = document.createElement('div');
    el.className = 'ai-msg ai-msg--bot';
    el.innerHTML = `<div class="ai-typing" style="padding:0.5rem 0.75rem"><span></span><span></span><span></span></div>`;
    msgs.appendChild(el);
    this._scrollAI();
    return el;
  },

  _scrollAI() {
    const el = document.getElementById('aiTutorMessages');
    if (el) el.scrollTop = el.scrollHeight;
  },

  _formatMd(text) {
    return text
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/```(\w*)\n?([\s\S]*?)```/g,'<pre style="background:rgba(0,0,0,0.4);border:1px solid var(--border);border-radius:6px;padding:0.75rem;margin:0.5rem 0;overflow-x:auto"><code style="font-family:var(--font-mono);font-size:0.8rem;color:#cdd6f4">$2</code></pre>')
      .replace(/`([^`]+)`/g,'<code style="background:rgba(0,0,0,0.35);padding:1px 5px;border-radius:3px;font-family:var(--font-mono);font-size:0.83em;color:#93c5fd">$1</code>')
      .replace(/\*\*(.+?)\*\*/g,'<strong style="color:var(--text)">$1</strong>')
      .replace(/\*(.+?)\*/g,'<em>$1</em>')
      .replace(/\n/g,'<br>');
  }
};
