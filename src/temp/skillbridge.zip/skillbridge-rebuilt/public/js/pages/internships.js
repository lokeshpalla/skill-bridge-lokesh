Pages.Internships = {
  async render() {
    if (!Auth.isLoggedIn()) { Router.navigate('/auth'); return; }
    const app = document.getElementById('app');
    app.innerHTML = `
<div class="pt-page" style="min-height:100vh">
  <div class="container" style="padding-top:2.5rem;padding-bottom:5rem">
    <div style="display:flex;align-items:flex-end;justify-content:space-between;flex-wrap:wrap;gap:1.5rem;margin-bottom:2.5rem">
      <div>
        <div class="section-badge section-badge-green">Internships</div>
        <h2 style="margin-top:0.6rem">AI-matched <span class="text-grad">opportunities</span><br>just for you</h2>
      </div>
      <div style="display:flex;gap:0.65rem">
        <button class="btn-ghost btn-sm" onclick="Pages.Internships._showTracker()">📋 My Applications →</button>
        <button class="btn-primary btn-sm" onclick="Pages.Internships._aiMatch()">🤖 AI Match Me</button>
      </div>
    </div>

    <div class="grid-4" style="margin-bottom:2rem">
      ${[
        {e:'💼',v:'1,200+',l:'Open Positions',c:'stat-icon-blue'},
        {e:'🏢',v:'450+',l:'Companies',c:'stat-icon-violet'},
        {e:'💰',v:'₹25K+',l:'Avg Stipend',c:'stat-icon-green'},
        {e:'🎯',v:'89%',l:'Match Rate',c:'stat-icon-amber'},
      ].map(s=>`
      <div class="stat-card">
        <div class="stat-icon ${s.c}">${s.e}</div>
        <div><div class="stat-value">${s.v}</div><div class="stat-label">${s.l}</div></div>
      </div>`).join('')}
    </div>

    <div style="display:flex;gap:0.65rem;margin-bottom:1.5rem;flex-wrap:wrap">
      <div class="input-wrap" style="flex:1;max-width:320px">
        <svg class="input-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
        <input class="input" placeholder="Search role, company, skill…" oninput="Pages.Internships._search(this.value)"/>
      </div>
      <div class="filter-bar">
        ${['All','Remote','On-site','Hybrid','GSoC','MLH','LFX'].map((f,i)=>`<button class="filter-chip${i===0?' active':''}" data-type="${f}">${f}</button>`).join('')}
      </div>
    </div>

    <div id="internshipList" style="display:flex;flex-direction:column;gap:0.75rem">
      ${[1,2,3,4,5].map(()=>`<div class="skeleton" style="height:96px;border-radius:var(--r-xl)"></div>`).join('')}
    </div>
  </div>
</div>

<!-- Tracker Modal -->
<div class="modal-overlay" id="trackerModal">
  <div class="modal" style="max-width:600px">
    <div class="modal-header">
      <h4>My Applications</h4>
      <button class="modal-close" onclick="document.getElementById('trackerModal').classList.remove('open')">✕</button>
    </div>
    <div id="trackerContent"><div class="skeleton" style="height:200px;border-radius:var(--r-lg)"></div></div>
  </div>
</div>`;

    await this._load();
  },

  _searchTimer: null,
  _search(val) { clearTimeout(this._searchTimer); this._searchTimer = setTimeout(()=>this._load(val),300); },

  async _load(search='') {
    try {
      const list = await API.internships.list(search?{search}:{});
      const el = document.getElementById('internshipList');
      if (!el) return;
      if (!list.length) { el.innerHTML=`<div style="text-align:center;padding:4rem;color:var(--text-2)">No internships found.</div>`; return; }
      const typeColors = {Remote:'blue',GSoC:'violet','On-site':'green',Hybrid:'cyan',MLH:'orange',LFX:'amber'};
      el.innerHTML = list.map(i=>`
      <div class="card" style="display:flex;align-items:center;gap:1.25rem;flex-wrap:wrap;transition:all var(--mid)" onmouseover="this.style.borderColor='var(--border-2)'" onmouseout="this.style.borderColor='var(--border)'">
        <div style="width:48px;height:48px;border-radius:var(--r);background:var(--surface-2);border:1px solid var(--border-2);display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0">
          ${{Technology:'💻',Design:'🎨',Marketing:'📣',Finance:'💹',Research:'🔬'}[i.type]||'💼'}
        </div>
        <div style="flex:1;min-width:200px">
          <div style="font-weight:700;font-size:0.95rem;margin-bottom:0.2rem">${escHtml(i.title)}</div>
          <div style="font-size:0.82rem;color:var(--text-3)">${escHtml(i.company)} · ${escHtml(i.location||'Remote')} · ${escHtml(i.duration||'3 months')}</div>
          <div style="display:flex;gap:0.4rem;margin-top:0.4rem;flex-wrap:wrap">
            <span class="badge badge-${typeColors[i.location]||'blue'}">${escHtml(i.location||'Remote')}</span>
            ${i.is_paid?`<span class="badge badge-green">Paid</span>`:''}
            ${i.ai_matched?`<span class="badge badge-violet">AI Matched</span>`:''}
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:1rem;flex-shrink:0">
          ${i.stipend?`<div style="text-align:center"><div style="font-family:var(--font-head);font-weight:800;color:var(--emerald-2);font-size:1.05rem">${escHtml(i.stipend)}</div><div style="font-size:0.7rem;color:var(--text-3)">/month</div></div>`:''}
          <div style="display:flex;flex-direction:column;gap:0.4rem">
            <button class="btn-primary btn-sm apply-btn" onclick="Pages.Internships._apply(${i.id},this)">Apply →</button>
            ${i.deadline?`<div style="font-size:0.7rem;color:var(--text-3);text-align:center">Due ${new Date(i.deadline).toLocaleDateString('en-IN',{day:'numeric',month:'short'})}</div>`:''}
          </div>
        </div>
      </div>`).join('');
    } catch {
      const el = document.getElementById('internshipList');
      if (el) el.innerHTML=`<div style="text-align:center;padding:4rem;color:var(--text-2)">Could not load internships.</div>`;
    }
  },

  async _apply(id, btn) {
    btn.disabled = true; btn.textContent = 'Applying…';
    try {
      await API.internships.apply(id);
      showToast('Application submitted! 🎉', 'success');
      btn.textContent = '✓ Applied';
    } catch(e) { showToast(e.message||'Application failed','error'); btn.disabled=false; btn.textContent='Apply →'; }
  },

  async _showTracker() {
    document.getElementById('trackerModal').classList.add('open');
    try {
      const apps = await API.internships.tracker();
      const content = document.getElementById('trackerContent');
      if (!apps.length) { content.innerHTML=`<p style="color:var(--text-2);text-align:center;padding:2rem">No applications yet.</p>`; return; }
      const statusColors = {pending:'amber',reviewed:'blue',interview:'violet',offered:'green',rejected:'rose'};
      content.innerHTML = apps.map(a=>`
      <div style="display:flex;align-items:center;gap:1rem;padding:0.75rem;background:var(--bg-2);border-radius:var(--r-lg);margin-bottom:0.5rem">
        <div style="flex:1">
          <div style="font-weight:600">${escHtml(a.internship_title||a.title)}</div>
          <div style="font-size:0.78rem;color:var(--text-3)">${escHtml(a.company_name||a.company)}</div>
        </div>
        <span class="badge badge-${statusColors[a.status]||'blue'}">${a.status||'Pending'}</span>
      </div>`).join('');
    } catch { document.getElementById('trackerContent').innerHTML=`<p style="color:var(--text-2);text-align:center;padding:2rem">Could not load applications.</p>`; }
  },

  _aiMatch() { showToast('AI matching in progress… 🤖', 'info'); setTimeout(()=>showToast('Found 12 perfect matches for your profile!', 'success'), 2000); }
};
