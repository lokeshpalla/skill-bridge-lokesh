// navbar.js — Navbar interactions only (bootstrap moved to app.js)
const Navbar = (() => {
  const init = () => {
    // Mobile hamburger
    document.getElementById('hamburger')?.addEventListener('click', () => {
      document.getElementById('navLinks')?.classList.toggle('open');
    });

    // Close mobile menu on nav link click
    document.getElementById('navLinks')?.querySelectorAll('.nav-link').forEach(l => {
      l.addEventListener('click', () => document.getElementById('navLinks').classList.remove('open'));
    });

    // Scroll shadow
    window.addEventListener('scroll', () => {
      document.getElementById('navbar')?.classList.toggle('scrolled', window.scrollY > 20);
    }, { passive: true });

    // Logout
    document.getElementById('logoutBtn')?.addEventListener('click', () => Auth.logout());

    // React to auth state changes
    Auth.onChange(user => _updateNav(user));
  };

  const _updateNav = (user) => {
    const authBtn  = document.getElementById('navAuthBtn');
    const avatar   = document.getElementById('navAvatar');
    const streak   = document.getElementById('navStreak');
    const initial  = document.getElementById('navAvatarInitial');
    const streakEl = document.getElementById('navStreakNum');
    const xpEl     = document.getElementById('navXpNum');

    if (user) {
      authBtn?.style.setProperty('display', 'none');
      avatar?.style.removeProperty('display');
      streak?.style.removeProperty('display');
      if (initial) initial.textContent = (user.full_name || user.email || 'U')[0].toUpperCase();
      if (streakEl) streakEl.textContent = user.streak_days || 0;
      if (xpEl)     xpEl.textContent     = (user.total_xp || 0).toLocaleString() + ' XP';
    } else {
      authBtn?.style.removeProperty('display');
      avatar?.style.setProperty('display', 'none');
      streak?.style.setProperty('display', 'none');
    }
  };

  return { init };
})();
