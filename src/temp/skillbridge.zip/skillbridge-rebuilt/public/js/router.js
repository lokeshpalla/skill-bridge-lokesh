// public/js/router.js — Client-side SPA router
const Router = (() => {
  const routes = {};
  const app = () => document.getElementById('app');
  const loader = () => document.getElementById('pageLoader');

  const register = (path, handler) => { routes[path] = handler; };

  const navigate = (path, push = true) => {
    if (push) history.pushState({}, '', path);
    render(path);
    updateNavActive(path);
    window.scrollTo(0, 0);
  };

  const render = async (path) => {
    const appEl = app();
    const loaderEl = loader();

    // Extract dynamic segments  /video/:roomCode
    const match = matchRoute(path);
    if (!match) { renderNotFound(); return; }

    appEl.innerHTML = '';
    appEl.appendChild(loaderEl || createLoader());
    loaderEl?.style?.setProperty?.('display', 'grid');

    try {
      await match.handler(match.params);
    } catch (err) {
      console.error('Router error:', err);
      appEl.innerHTML = `<div style="text-align:center;padding:4rem;color:var(--text-2)"><h2>Something went wrong</h2><p>${err.message}</p></div>`;
    } finally {
      if (loaderEl) loaderEl.style.display = 'none';
    }
  };

  const matchRoute = (path) => {
    // Exact match first
    if (routes[path]) return { handler: routes[path], params: {} };

    // Pattern match
    for (const [pattern, handler] of Object.entries(routes)) {
      const regexStr = pattern.replace(/:([^/]+)/g, '([^/]+)');
      const m = path.match(new RegExp(`^${regexStr}$`));
      if (m) {
        const keys = [...pattern.matchAll(/:([^/]+)/g)].map(x => x[1]);
        const params = Object.fromEntries(keys.map((k, i) => [k, m[i + 1]]));
        return { handler, params };
      }
    }
    return null;
  };

  const createLoader = () => {
    const d = document.createElement('div');
    d.id = 'pageLoader';
    d.className = 'page-loader';
    d.innerHTML = '<div class="loader-ring"></div>';
    return d;
  };

  const renderNotFound = () => {
    app().innerHTML = `
      <div class="pt-page" style="min-height:calc(100vh - 64px);display:flex;align-items:center;justify-content:center;flex-direction:column;gap:1.5rem;text-align:center;padding:2rem">
        <div style="font-size:5rem;font-family:var(--font-head);font-weight:800;color:var(--text-3)">404</div>
        <h2>Page not found</h2>
        <p>The page you're looking for doesn't exist.</p>
        <a href="/" class="btn-primary" onclick="Router.navigate('/');return false">Go Home</a>
      </div>`;
  };

  const updateNavActive = (path) => {
    document.querySelectorAll('.nav-link').forEach(l => {
      l.classList.toggle('active', l.getAttribute('href') === path || (path.startsWith(l.getAttribute('href')) && l.getAttribute('href') !== '/'));
    });
  };

  // Intercept all internal link clicks
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href]');
    if (!a) return;
    const href = a.getAttribute('href');
    if (!href || href.startsWith('http') || href.startsWith('mailto') || href.startsWith('#')) return;
    e.preventDefault();
    navigate(href);
  });

  window.addEventListener('popstate', () => render(location.pathname));

  return { register, navigate, render };
})();
